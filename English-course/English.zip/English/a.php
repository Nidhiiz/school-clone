<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found - Oxford School of English</title>
    <meta name="description" content="The page you were looking for on Oxford School of English could not be found.">
    <link rel="icon" href="/assets/icons/favicon.ico" type="image/x-icon">

    <!-- Optional: JSON-LD Schema for SEO -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "404 Error",
      "description": "The requested page could not be found on Oxford School of English.",
      "url": "https://www.oxfordschoolofenglish.in/404.php"
    }
    </script>

    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            text-align: center;
        }
        .text-center {
            text-align: center;
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }
        .section .error {
            font-size: 100px;
            color: #f26c36;
            text-shadow: 
                1px 1px 1px #d54608,
                2px 2px 1px #d54608,
                3px 3px 1px #d54608,
                4px 4px 1px #d54608,
                5px 5px 1px #d54608,
                6px 6px 1px #d54608,
                7px 7px 1px #d54608,
                8px 8px 1px #d54608,
                25px 25px 8px rgba(0,0,0, 0.2);
            margin-bottom: 30px;
        }
        .page {
            margin: 1.5rem 0;
            font-size: 20px;
            font-weight: 600;
            color: #444;
        }
        .back-home {
            display: inline-block;
            border: 2px solid #222;
            color: #fff;
            background: #222;
            text-transform: uppercase;
            font-weight: 600;
            padding: 0.75rem 1rem 0.6rem;
            transition: all 0.2s linear;
            box-shadow: 0 15px 15px -11px rgba(0,0,0, 0.4);
            border-radius: 6px;
            text-decoration: none;
            margin-top: 20px;
        }
        .back-home:hover {
            background: #333;
            color: #eee;
        }
        @media (max-width: 600px) {
            .section .error {
                font-size: 80px;
            }
            .page {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <div class="section text-center">
        <h1 class="error">404</h1>
        <div class="page">Ooops!!! The page you are looking for is not found.</div>
        <p>It might have been moved or removed, or you might have typed the address incorrectly.</p>
        <a class="back-home" href="/">Back to Home</a>

        <p style="margin-top: 30px;">You might find these pages helpful:</p>
        <ul style="list-style: none; padding: 0;">
            <li style="margin-bottom: 10px;"><a href="english-speaking-course.php" style="color: #f26c36; text-decoration: underline;">Explore Our Courses</a></li>
            <li style="margin-bottom: 10px;"><a href="/" style="color: #f26c36; text-decoration: underline;">Admissions Information</a></li>
            <li style="margin-bottom: 10px;"><a href="contact-us.php" style="color: #f26c36; text-decoration: underline;">Contact Us</a></li>
        </ul>
    </div>
</body>
</html>