
const storyData = [
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/women1-desktop-big.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
];

  
const storyData3 = [
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "to popular belief, Lorem Ipsum",
        text2: " are many variations of passages",
        text3: " standard chunk of Lorem",
        text4: " ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
  {
    title: "Women green",
    images: [
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
      {
        img: "./assets/visual-story/red-frame.webp",
        text1: "Contrary to popular belief, Lorem Ipsum",
        text2: "There are many variations of passages",
        text3: "The standard chunk of Lorem",
        text4: "Sed ut perspiciatis unde omnis iste natus",
      },
    ],
  },
];
  
  function openStory(index) {
    localStorage.setItem("storyData", JSON.stringify(storyData[index]));
    localStorage.setItem("storyType", "1");
    window.open("visual-story.html", "_blank");
  }
  
  function openStory3(index) {
    localStorage.setItem("storyData", JSON.stringify(storyData3[index]));
    localStorage.setItem("storyType", "2");
    window.open("visual-story.html", "_blank");
  }
  
  