<!DOCTYPE html>
<html lang="en">
<head>
    <title>Job Registration – Secure a Career with Top Companies</title>
    <meta name="description" content="Register now for admin, client relations & operations job placements. Get trained and hired by top companies. Start your career today!">
    
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"/>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

<link href="css/style.css" rel="stylesheet" />

<link href="css/css190425/header.css" rel="stylesheet"/>
<link href="css/css190425/common.css" rel="stylesheet"/>
<link href="css/css190425/default-banner.css" rel="stylesheet"/>

<link href="css/combined-global.css" rel="stylesheet" />

<link href="css/adib-css/adib4.css" rel="stylesheet"/>
<link href="css/adib-css/adib5.css" rel="stylesheet"/>
<link href="css/adib-css/adib6.css" rel="stylesheet"/>
<link href="css/adib-css/adib9.css" rel="stylesheet"/>
<link href="css/adib-css/adib10.css" rel="stylesheet"/>
<link href="css/adib-css/adib11.css" rel="stylesheet"/>
<link href="css/css190425/section41.css" rel="stylesheet"/>

 <link href="./banners/css/home-banner03.css" rel="stylesheet" />
<link href="css/css190425/footer.css" rel="stylesheet"/>


<link href="css/floating-buttons.css" rel="stylesheet"/>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"/>

   <link rel="stylesheet" type="text/css"
  href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"  rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  rel="stylesheet"/>

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '489625390408393');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=489625390408393&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->


<!-- Fallback Open Graph (OG) Tags -->
<meta property="og:title" content="Oxford School of English – Best English Speaking Courses in Delhi" />
<meta property="og:description" content="Join Oxford School of English. English Speaking Courses in Pitampura, Rajouri Garden, South Extension and Laxmi Nagar since 1997." />
<meta property="og:image"content="https://www.oxfordschoolofenglish.in/images/og/english-course.jpg" />
<meta property="og:url" content="https://www.oxfordschoolofenglish.in/" />
<meta property="og:type" content="website" />


<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="/oxford-school-of-english-icon.png">
<link rel="apple-touch-icon" href="/oxford-english-apple-icon.png">

<!-- Google tag (gtag.js) for GA4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6VXK325WCQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-6VXK325WCQ');
</script>
    <link rel="canonical" href="https://oxfordschoolofenglish.in/job-for-freshers-in-delhi.php" />
   <link rel="stylesheet" href="./banners/css/placement-banner02.css">
   <link rel="stylesheet" href="./banners/css/placement-banner01.css">

</head>
<body>
    

<header>
   <!--Desktop Navbar Header Code Start-->
   <div class="d-lg-block d-none">
    <div class="desktop-navbar">
     <nav class="navbar navbar-expand-lg navbar-light fixed-top">
         <a href="/">
            <img loading="lazy" class="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp" alt="oxford school of english delhi logo"/>
         </a>
      <button aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbar" data-toggle="collapse" type="button">
       <span class="navbar-toggler-icon">
       </span>
      </button>
      <div class="collapse navbar-collapse" id="navbar">
       <ul class="navbar-nav m-auto">
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Home
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="index.php">
           Home
          </a>
          <a class="dropdown-item" href="about.php">
           About
          </a>
          <a class="dropdown-item" href="gallery-fun-learning.php">
           Gallery
          </a>
          <a class="dropdown-item" href="english-blogs.php">
          English Blogs
          </a>
          <a class="dropdown-item" target="_blank" href="lms">
           LMS
          </a>
          <a class="dropdown-item" href="franchise-opportunity.php">
           Franchise
          </a>
         </div>
        </li>
        <li class="nav-item dropdown megamenu-li large-li">
         <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
          Courses
         </a>
         <div aria-labelledby="dropdown01" class="dropdown-menu megamenu">
          <div class="row">
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course.php">
             All Courses
            </a>
            <a class="dropdown-item" href="advance-english-speaking-course.php">
             Interchange  Advance Level-3
            </a>
            <a class="dropdown-item" href="online-english-speaking-course.php">
             Online English Classes
            </a>
            <a class="dropdown-item" href="pte-coaching-online.php">
             PTE Online Coaching
            </a>
            <a class="dropdown-item" href="personalised-english-classes.php">
             Personalised Classes
            </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course-for-beginners.php">
             Interchange  Beginners 
            </a>
            <a class="dropdown-item" href="ielts-coaching-near-me.php">
             IELTS Course
            </a>
            <a class="dropdown-item" href="online-ielts-coaching.php">
             IELTS Online Coaching
            </a>
            <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">
             IELTS and English
            </a>
            <a class="dropdown-item" href="personality-development-course.php"> Personality Development </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">
             Interchange  Intermediate Level-2
            </a>
            <a class="dropdown-item" href="basic-spoken-english-course.php">
             Basic Spoken English Course
            </a>
            <a class="dropdown-item" href="pte-coaching-near-me.php">
             PTE Course
            </a>
            <a class="dropdown-item" href="english-and-pte-coaching-classes.php"> PTE and English </a>
            <a class="dropdown-item" href="competitive-exam-english-classes.php"> Competitive Exams </a>
           </div>
          </div>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Placement
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="hire-fresher.php">
           Employer
          </a>
          <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
           Student
          </a>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Contact
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="contact-us.php"> All Centers </a>
          <a class="dropdown-item" href="contact-us-pitampura.php"> Pitampura </a>
          <a class="dropdown-item" href="contact-us-laxmi-nagar.php"> Laxmi Nagar </a>
          <a class="dropdown-item" href="contact-us-rajouri-garden.php"> Rajouri Garden </a>
          <a class="dropdown-item" href="contact-us-south-extension.php"> South Extension </a>
         </div>
        </li>
       </ul>
      </div>
      <div class="d-flex flex-row justify-content-end">
       <button class="pay-online-button"> <a href="https://rzp.io/l/OSEDELHI" target="_blank"> Pay Online </a> </button>
       
       <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      
      </div>
     </nav>
    </div>
    <div class="top-navbar d-lg-block d-none">
     <div class="container-fluid">
      <div class="d-flex flex-row justify-content-between">
       <button class="btn-year" type="btn">
        Since 1997 | 4 Branches
       </button>
       <div class="d-flex flex-row justify-content-center">
        <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           LEARN
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SPEAK
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SUCCEED
          </p>
         </div>
        </div>
       </div>
       <button class="btn-year" type="btn">
        One Lakh Students Trained
       </button>
      </div>
     </div>
    </div>
   </div>
   <!--Desktop Navbar Header Code End-->
   <!--Mobile Navbar Header Code Start-->
   <div class="d-block d-lg-none">
    <div class="top-navbar">
     <div class="d-flex flex-row justify-content-center">
      <div class="d-flex flex-row m-auto">
          <a href="index.php">
              <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
          </a>

       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          LEARN
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SPEAK
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SUCCEED
         </p>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div class="mobile-navbar">
     <div class="d-flex flex-row justify-content-between">
      <!--<button class="call-us-button" type="btn">-->
      <!-- <i class="fa fa-solid fa-phone mr-1">-->
      <!-- </i>-->
      <!-- Call Us-->
      <!--</button>-->
      <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      <a href="index.php">
          <img loading="lazy" alt="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp"/>
      </a>
      <button class="call-us-button" type="button" onclick="openSidebar()">
       Menu
       <i class="fa fa-solid fa-bars ml-1" >
       </i>
      </button>
      <div id="backdrop-sidebar"></div>
      <div class="sidebar" id="sidebar">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="navbar-collapse collapse show" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="menu-nav">
                    <a  class="nav-link mobile-navlink01">
                        MENU
                    </a>
                    <i class="fa fa-solid fa-circle-xmark close-icon" onclick="closeSidebar()">
                    </i>
            </li>
          <li class="nav-item dropdown">
            <a  class="nav-link mobile-navlink01" href="index.php">
             HOME
            </a>
           </li>
            <li>
                <a class="nav-link mobile-navlink01" href="about.php">
                    About 
                </a>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                English Courses
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="english-speaking-course.php">All English Courses</a>
                        <a class="dropdown-item" href="basic-spoken-english-course.php">Basic English Course</a>
                        <a class="dropdown-item" href="english-speaking-course-for-beginners.php">English Speaking Course for <br> Beginners - Level 1</a>
                        <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">Intermediate English Course - Level 2</a>
                        <a class="dropdown-item" href="advance-english-speaking-course.php">Advanced English Course - Level 3</a>
                        <a class="dropdown-item" href="online-english-speaking-course.php">Online English Speaking Course </a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                IELTS
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="ielts-coaching-near-me.php">IELTS Coaching</a>
                        <a class="dropdown-item" href="online-ielts-coaching.php">IELTS Online One-on-One</a>
                        <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">IELTS & English Course</a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PTE
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="pte-coaching-near-me.php">PTE Coaching</a>
                        <a class="dropdown-item" href="english-and-pte-coaching-classes.php">PTE & English Course</a>
                        <a class="dropdown-item" href="pte-coaching-online.php">PTE Online One-on-One</a>
                </div>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personality-development-course.php">
                    Personality Development
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="competitive-exam-english-classes.php">
                    Competitive Exam Classes
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personalised-english-classes.php">
                    Personalised English Classes
                </a>
            </li>
            <li class="nav-item dropdown megamenu-li">
                <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
                    CONTACT US
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="contact-us.php">
                    All Centers
                    </a>
                    <a class="dropdown-item" href="contact-us-south-extension.php">
                    South Extension
                    </a>
                    <a class="dropdown-item" href="contact-us-rajouri-garden.php">
                    Rajouri Garden
                    </a>
                    <a class="dropdown-item" href="contact-us-pitampura.php">
                    Pitampura
                    </a>
                    <a class="dropdown-item" href="contact-us-laxmi-nagar.php">
                    Laxmi Nagar
                    </a>
                </div>
            </li>
            <li>
                <a class="nav-link mobile-navlink01" href="gallery-fun-learning.php">
                    Gallery
                </a>
            </li>
              <li>
                <a class="nav-link mobile-navlink01" href="english-blogs.php">
                    English Blogs
                </a>
            </li>
            <li class="nav-item dropdown">
            <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PLACEMENT
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="hire-fresher.php">
                Employer
                </a>
                <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
                Student
                </a>
            </div>
            </li>
         </ul>
        </div>
       </nav>
      </div>
     </div>
    </div>

    <div class="top-navbar d-lg-none d-block">
      <div class="d-flex flex-row justify-content-center">
        <button class="navbar-button">Since 1997 | 4 Branches | One Lakh Students Trained</button>
      </div>
    </div>
   </div>
   <!--Mobile Navbar Header Code End-->
  </header>
  
  
<!--floating buttons start-->

    <a class="fa-brands fa-whatsapp fa-beat fa-xl m-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"></a>
    <div class="w-numbers m-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
            
    <a class="fa-brands fa-whatsapp fa-beat fa-xl d-flex d-md-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"> <span> Whatsapp</span></a>

    <div class="w-numbers web-d-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
      
    <a class="floatingss fa fa-phone-volume fa-beat d-md-block d-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
      
    <a class="floatingss fa fa-phone-volume fa-beat d-flex d-md-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"><span> Phone</span></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
<!--floating buttons end-->    
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Placement</li>
        <li class="breadcrumb-item active" aria-current="page">Students</li>
      </ol>
    </nav>

    <section>
  <div class="placement-banner02">
    <div class="row m-0">
      <div class="col-12 p-0 col-lg-7 d-flex flex-column justify-content-center order-2 order-lg-1" >
        <div class="placement-banner02-text-box">
          <h1 class="placement-banner02-heading" > Get <span class="gray-color-span">Hired </span> – Register <br> for  <span class="gray-color-span">Job Placement! </span>  </h1> 

          <div class="d-flex flex-row justify-content-xl-center justify-content-end">
            <img loading="lazy" src="./banners/banner-images/placement/mobile/get-hired-register-for-job-placement-mobile.webp" class="img-fluid mobile-placement-banner02-image d-lg-none d-block" alt="Register for Placement" title="Job Opportunities" >
          </div>
          
          <div class="mobile-alignment-box">
            <div class="oxford-email-container">
             <div class="placement-banner02-row01">
               <img loading="lazy" alt="contact us via email" src="./banners/banner-images/banners-icons/email-icon.webp" class="email-icon">
               <h6 class="oxford-email">oxfordplacem@gmail.com</h6>
             </div>
            </div>
           </div>
        </div>
      </div>

      <div class="col-12 col-lg-5 order-1 order-lg-2 d-none d-lg-block pr-0">
        <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" src="./banners/banner-images/placement/desktop/get-hired-register-for-job-placement.webp" class="placement-banner02-image" alt="Register for Placement" title="Job Opportunities" >
        </div>
       
      </div>
    </div>
  </div>
</section>

    
   
    <section id="section15">
   <!--best-speaking-in-delhi-container section Code Start-->
   <div class="best-speaking-in-delhi-container py-standard mt-standard">
    <div class="container text-center">
     <h2 class="best-speaking-in-delhi-container-button">
       Start Your Career – Get Placed with Top Companies!  
     </h2>
     <div class="d-flex flex-row justify-content-center">
      <div class="best-speaking-in-delhi-description-container text-justify p-standard-inner">
       <div class="d-lg-block d-none">
        <p class="m-0">
        You have completed your training—now step confidently into the professional world! At Oxford School of English, we connect skilled candidates with top companies seeking trained freshers. We offer placement opportunities in Administration, Client Relations, Customer Service, Corporate Coordination, Business Support, Operations, and Executive Assistance. With 28+ years of experience, we have helped our trained students build successful careers in reputed organisations across industries. Your training has equipped you with the right skills—now let us guide you to the perfect job. Please register with us for direct access to exclusive job opportunities, seamless placement guidance, and the best launchpad for your career. You’re ready—get hired today!
        </p>
       </div>
       <div class="d-block d-lg-none">
        <p class="m-0">
         You have completed your training—now step confidently into the professional world! At Oxford School of English, we connect skilled candidates with top companies seeking trained freshers.
         <span class="span05 hidden" id="hidden-content10">
        We offer placement opportunities in Administration, Client Relations, Customer Service, Corporate Coordination, Business Support, Operations, and Executive Assistance. With 28+ years of experience, we have helped our trained students build successful careers in reputed organisations across industries. Your training has equipped you with the right skills—now let us guide you to the perfect job. Please register with us for direct access to exclusive job opportunities, seamless placement guidance, and the best launchpad for your career. You’re ready—get hired today!
         </span>
        </p>
       </div>
       <div class="d-block d-lg-none">
        <div class="d-flex flex-row justify-content-end">
         <button class="read-more-btn" id="read-more-btn10" type="btn">
          Read More
         </button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--best-speaking-in-delhi-container section Code End-->
  </section>
  
  <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Student Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="./form-code/css/student-form.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

</head>

<body>

    <section class="student-form-main">
        <h1 class="main-tittle">Student Details</h1>
        <div class="form-container">
            <form id="studentForm" method="post">
                <div class="group-content select-content-group">
                    <select name="centre" required>
                        <option value="Select a Center">Select a Center *</option>
                        <option value="Center 1">Laxmi Nagar </option>
                        <option value="Center 2">Pitampura </option>
                        <option value="Center 2">Rajouri Garden </option>
                        <option value="Center 2">South Extension </option>
                    </select>
                </div>
                <div class="group-content">

                    <input type="text" name="roll" placeholder="" required class="inputfield">
                    <label for="">Roll no <span>*</span></label>
                </div>

                <div class="group-content">
                    <input type="text" name="fullname" required class="inputfield">
                    <label for="">Full Name <span>*</span></label>
                </div>

                <div class="group-content">
                    <input type="tel" name="mobile" pattern="^\d{10}$" maxlength="10" required class="inputfield">
                    <label for="">Mobile Number <span>*</span></label>
                </div>
                <div class="group-content">
                    <input type="email" name="email" required class="inputfield">
                    <label for="">Email <span>*</span></label>
                </div>
                <div class="group-content">
                    <input type="text" name="course" required class="inputfield">
                    <label for="">Course <span>*</span></label>
                </div>

                <div class="group-content">
                    <input type="text" name="faculty" required class="inputfield">
                    <label for="">Faculty <span>*</span></label>
                </div>
                <div class="group-content">
                <label for="completionDate" class="input-label">Course Finish Date</label>
                <input type="text" id="completionDate" name="completionDate" class="inputfield" placeholder="Course Finish Date" readonly />
                </div>
                <div class="group-content select-content-group">
                    <select name="lastQualification" required>
                        <option value="Last Qualification">Last Qualification *</option>
                        <option value="High School">Under Matric</option>
                        <option value="Diploma">10 th</option>
                        <option value="Graduation">12 th</option>
                        <option value="Post-Graduation">Undergraduate</option>
                        <option value="Post-Graduation">Graduate</option>
                        <option value="Post-Graduation">Post Graduate</option>
                    </select>
                </div>

                <div class="group-content">
                    <input type="text" name="otherQualification" class="inputfield">
                    <label for="">Other Qualification</label>
                </div>
                <div class="group-content">
                    <input type="text" name="experience" class="inputfield">
                    <label for="">Experience (If any)</label>
                </div>
                <div class="group-content">
                    <input type="text" name="jobPreferences" required class="inputfield">
                    <label for="">Job Preferences <span>*</span></label>
                </div>
                <div class="msg-group-content">
                    <textarea name="about" placeholder="Brief Detail About Yourself"></textarea>
                    <textarea name="address" placeholder="Address"></textarea>
                </div>

                <button type="submit" name="submitStudent" class="submit-btn">Submit</button>
            </form>
        </div>
    </section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        function validateForm() {
            const form = document.getElementById('applicationForm');
            if (!form.checkValidity()) {
                alert("Please fill in all required fields correctly.");
                return false;
            }
            alert("Form submitted successfully!");
            return true;
        }

        $(document).ready(function () {
            $('.inputfield').on('input', function () {
                if ($(this).val().length > 0) {
                    $(this).siblings('label').addClass('hide');
                } else {
                    $(this).siblings('label').removeClass('hide');
                }
            });

            flatpickr("#completionDate", {
                dateFormat: "d-M-Y", // e.g., 21-Feb-2025
                allowInput: false,   // disables typing
            });
        });
    </script>

</body>

</html>
<!--<h3 class="text-center">-->
<!--   Section 20-->
<!--  </h3>-->
  <!-- Companies section start-->
  <section id="section20">
   <div class="mt-standard">
    <div class="d-flex flex-row flex-wrap">
     <div class="orange-color-container pt-md-5 pt-1 pb-5 d-flex flex-column justify-content-center">
      <div class="d-flex flex-row justify-content-end">
       <div class="ending-text-container pt-3 pb-2">
        <div class="container-fluid">
         <div class="d-flex flex-row justify-content-end">
          <h5 class="ending-text-container-heading">
           Names of the Top Companies Where Our Star Alumni Are Working
          </h5>
         </div>
        </div>
       </div>
      </div>
     </div>
     <div class="logo-container p-md-5 p-4 pt-5">
      <div class="container-fluid">
       <div class="row">
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/accenture.webp" alt="Working in accenture"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/adecco.webp" alt="Working in adecco"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/airtel.webp" alt="working in airtel"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/dd-news.webp" alt="working in DD-News"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/dish-tv.webp" alt="Working in Dish-TV"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/ht-media.webp" alt="Working in HT-Media"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/icici-bank.webp" alt="Working in ICICI-Bank"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/kotak-bank.webp" alt="Working in Kotak-Bank"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/lohia.webp" alt="Working in Lohia"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/tech-mahindra.webp" alt="Working in Tech-Mahindra"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/times-of-india.webp" alt="Working in Times-of-India"/>
        </div>
        <div class="col-4 col-lg-3 mb-3">
         <img loading="lazy" class="company-logo" src="./assets/20-company-logo/webtel.webp" alt="Working in Webtel"/>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  <!-- Companies section end-->

  <!--section 20 end-->

  

    <link href="./css/bootstrap.css" rel="stylesheet"/>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/adib-css/adib-common.css">

<!--<h3 class="text-center">-->
<!--     Section 17-->
<!--  </h3>-->
  <section class="oxford-branches mt-standard" id="section17">
    <div class="d-flex flex-row justify-content-center">
    <h3 class="new-abc-button mb-0">
      Oxford School of English Branches
    </h3>
    </div>
       <!--english-speaking-classes-section Code Start-->
       <div class="new-branches-container pt-5 py-standard">
        <div class="container-fluid">
         <div class="grid grid-cols-3 grid-cols-2-17 g-gap card-scroll">
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Pitampura Branch </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  365 Kohat Enclave, Near Kohat Metro Station Gate No. 3, North Delhi -110034 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127373"> 9540127373</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:45680574"> 011 - 45680574</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-pitampura.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6981337,77.1372723,17z/data=!3m1!4b1!4m5!3m4!1s0x390d03da0abc6ac3:0xe4642d10ca8d8fbf!8m2!3d28.698129!4d77.139461?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Laxmi Nagar</h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  E 354, Nirman Vihar, Adjacent to Nirman Vihar Metro Station Gate Number 2, East Delhi -110092 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127878"> 9540127878</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 40159334</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-laxmi-nagar.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6372579,77.2865177,17z/data=!4m5!3m4!1s0x390cfb56b6843fff:0xbd5d17737bc80438!8m2!3d28.6372532!4d77.2887064?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> South Extension </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> E 10, Part-I, Near South Extension Metro Station, South Extension, South Delhi -110049 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9810735296"> 9810735296 </a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255102"> 011 - 41255102</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-south-extension.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute+South+Extention/@28.5706783,77.219955,17z/data=!3m1!4b1!4m6!3m5!1s0x390ce25d0ac35f11:0x3125b97033cf142f!8m2!3d28.5706783!4d77.219955!16s%2Fg%2F1th0wr3f?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Rajouri Garden </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> A 4, Vishal Enclave, opposite Metro Pillar No. 411, West Delhi -110027 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9319608182"> 9319608182</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 41255104 </a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-rajouri-garden.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute+Rajouri+Garden/@28.6880275,77.1244528,12z/data=!4m6!3m5!1s0x390d0372a62dafe3:0x5e55587ff09b2755!8m2!3d28.6478906!4d77.1190374!16s%2Fg%2F11bxc5l07v?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <!--english-speaking-classes-section Code End-->
  </section>
  
  
  <footer>
   <div class="">
    <div class="mobile-footer-container px-3 py-standard">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Quick Links
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="/">
           Home
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="about.php">
           About 
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-blogs.php">
           English Blogs
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="gallery-fun-learning.php">
           Gallery
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="hire-fresher.php">
           Placement Employer
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="job-for-freshers-in-delhi.php">
           Placement Student
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="contact-us.php">
           Contact Us
          </a>
         </li>
          <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms/inquiry.php">
           Enquiry Form
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms">
           LMS
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-course-faqs.php">
           English Course FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-exam-faqs.php">
           IELTS Exam FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-exam-faqs.php">
           PTE Exam FAQ
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="spoken-english-classes-near-me.php">
           English Classes Near Me
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Courses
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon01">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks01" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course.php">
           All Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course-for-beginners.php">
           Interchange Beginners Level-1
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="intermediate-level-english-speaking-course.php">
           Interchange Intermediate Level-2
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="advance-english-speaking-course.php">
           Interchange Advance Level-3
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-coaching-near-me.php">
           IELTS Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="basic-spoken-english-course.php">
           Basic Spoken English Course
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-english-speaking-course.php">
           Online English Classes
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-ielts-coaching.php">
           IELTS Online Coaching
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-coaching-near-me.php">
           PTE Course
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="pte-coaching-online.php">
           PTE Online Coaching
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         About 
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <p class="footer-about-us-description">
         Oxford School of English, with four branches since 1997, stands as Delhi’s leading English-speaking Institute and offers the best English-speaking course (also called English talking course by many) from basic to advanced levels. If you are searching for English-speaking classes near me, Oxford is the best choice, with branches in all directions of Delhi, having trained over one lakh students as an NSDC training partner.
        </p>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         Course Enquiry
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <form action="" method="post" name="frm">
            <!--<input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />-->
            <input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />
            <input class="footer-form-control" name="mobile" placeholder="Enter your Number" type="text" required />
            <input class="footer-form-control" name="course" placeholder="Course" type="text" required />
            <select class="footer-form-control" name="centre" required>
                <option value="" selected> Select Center</option>
                <option value="Pitampura"> Pitampura</option>
                <option value="Laxmi Nagar"> Laxmi Nagar</option>
                <option value="Rajouri Garden"> Rajouri Garden</option>
                <option value="South Extension"> South Extension</option>
            </select>
         <!--<input class="footer-form-control" placeholder="Enter Your Name" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Enter Your Number" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Select Center" type="text"/>-->
         <div class="d-flex flex-row justify-content-center">
          <button class="footer-form-submit-btn" type="submit" name="submitQuick">
           Submit
          </button>
         </div>
        </form>
       </div>
      </div>
     </div>
    </div>
    <div class="footer-border-bottom-line">
    </div>
    <div class="mobile-footer-container pt-4 pb-4 px-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Proud Associations
        </p>
        <div class="row">
         <div class="col-7 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/oxford-nsdc-partner.webp" alt="Oxford is a Proud Partner of NSDC" />
         </div>
         <div class="col-5 col-lg-2 mb-3">
          <img loading="lazy" class="partner-image" src="./assets/footer/skill-courses.webp" alt="We Offer Skill Courses for Better Employment" />
         </div>
         <div class="col-12 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/cambridge-partner.webp" alt="Oxford School of English Offers Cambridge University Press Courses" />
         </div>
        </div>
       </div>
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Connect with Us
        </p>
        <div class="d-flex flex-row justify-content-between justify-content-md-start">
         <a href="https://www.facebook.com/delhioxfordenglish">
          <img loading="lazy" alt="Facebook Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-facebook.webp"/>
         </a>
         <a href="#">
          <img loading="lazy" alt="x-icon" class="social-icon" src="./assets/footer/x-oxford-english.webp"/>
         </a>
         <a href="https://www.instagram.com/oxfordschoolofenglish.in">
          <img loading="lazy" alt="Instagram Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-instagram.webp"/>
         </a>
         <a href="https://www.youtube.com/channel/UC50IGGpwAuCGcVzP6Tx2TPg">
          <img loading="lazy" alt="YouTube Channel of Oxford School of India" class="social-icon" src="./assets/footer/oxford-english-youtube.webp"/>
         </a>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      English Speaking Institute Near You
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Kohat Enclave
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near nangloi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Paschim Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Shalimar Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Punjabi Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Rani Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rohini.php">
          English Speaking Course in Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Narela
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Bawana
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Uttam Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Shahdara
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Preet Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Nirman Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Krishna Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Geeta Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Patparganj
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Vaishali
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Kaushambi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in Kotla
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Defence Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Kalkaji
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Green Park
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Hauz Khas
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="spoken-english-classes-near-me.php">
          English Classes Near Me
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-classes-delhi.php">
          English Speaking Course in Delhi
         </a>
        </li>
       </ul>
      </div>
     </div>
    </div>
   </div>

   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      IELTS Coaching Institute Near You In Delhi
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-pitampura.php">
          IELTS Coaching in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rohini.php">
         IELTS Coaching near  Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching   in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching   in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching  near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>

     </div>
    </div>
   </div>

   <div class="copyright-container pt-4 pb-2">
    <div class="container-fluid">
     <h5 class="copyright-heading">
      Copyright &copy; 1997 - 2025 Hindustan Soft Education Limited, New Delhi || All the logos and images are the copyright of their respective owners
     </h5>
     <div class="d-flex flex-row justify-content-center">
      <p class="copyright-paragraph">
       *Privacy Policy : We do not distribute your email or contact information to other websites or sources and will be kept confidential. We do not accept or host any advertisement on this website. We do collect visitor data and asses the user traffic on our website and various pages which helps us to improvise. We do not collect any personal information on visitors. Any information which is considered to have ethnic or gender bias, derogatory or lewd will be removed by owner of this website at their discretion without any notice. By using our website, you agree to our privacy policy as mentioned above. Our privacy policy may get updated without any notice, hence users are suggested to review it before they plan to submit any personal information to our website.
      </p>
     </div>
    </div>
   </div>
  </footer>
  <div class="popup" id="videoPopup">
   <div class="popup-content">
    <span class="close-btn" onclick="hidePopup()">
     &times;
    </span>
    <video controls="" id="popupVideo">
     <source src="" type="video/mp4"/>
     Your browser does not support the video tag.
    </video>
   </div>
  </div>
  <div class="video-overlay" id="videoOverlay">
   <div class="video-container">
    <div class="embed-responsive embed-responsive-16by9">
     <iframe allowfullscreen="" class="embed-responsive-item" id="videoIframe" src="">
     </iframe>
    </div>
    <span class="close-btn01" id="closeBtn01">
     <img loading="lazy" src="./assets/icons/cross.webp" width="40" height="40" alt="cross">
    </span>
   </div>
  </div>
  <!-- <script src="banners/js/aos.js"></script> -->
  <script>
  
  </script>
  <script src="js/common.js" defer></script>

  <script src="js/custom-carousel.js" defer></script> 

  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" defer ></script>

  <script  src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" defer ></script>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" defer></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"  defer></script>

  <script src="./js/adib-script.js" defer></script>

  <!-- Ashutosh's code start - 16-04-2025
     Code to reload images that did not load the first time -->

  <script>
//     $(document).ready(function() {
//       $('img').each(function () {
//         if (!this.complete || typeof this.naturalWidth === "undefined" || this.naturalWidth === 0) {
//           var src = $(this).attr('src');
//           $(this).attr('src', src); // Force reload
//         }
//       });
//     });
 </script>
  <!-- Ashutosh's code end -->
  <!--banner script-->
  
 </body>
</html>  
  </body>
    </html>