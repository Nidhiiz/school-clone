<!DOCTYPE html>
<html lang="en">
<head>
    <title>PTE Academic | PTE General, Call for PTE Coaching </title>
    <meta name="description" content="PTE course tailored to achieve your desired score. Visit the nearest Oxford centre for the best PTE coaching.">
    <meta name="keywords" content="pte classes near me,pte coaching near me,pte course,pte classes,pte institute near me,pte coaching,pte coaching centre near me">
    
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"/>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

<link href="css/style.css" rel="stylesheet" />

<link href="css/css190425/header.css" rel="stylesheet"/>
<link href="css/css190425/common.css" rel="stylesheet"/>
<link href="css/css190425/default-banner.css" rel="stylesheet"/>

<link href="css/combined-global.css" rel="stylesheet" />

<link href="css/adib-css/adib4.css" rel="stylesheet"/>
<link href="css/adib-css/adib5.css" rel="stylesheet"/>
<link href="css/adib-css/adib6.css" rel="stylesheet"/>
<link href="css/adib-css/adib9.css" rel="stylesheet"/>
<link href="css/adib-css/adib10.css" rel="stylesheet"/>
<link href="css/adib-css/adib11.css" rel="stylesheet"/>
<link href="css/css190425/section41.css" rel="stylesheet"/>

 <link href="./banners/css/home-banner03.css" rel="stylesheet" />
<link href="css/css190425/footer.css" rel="stylesheet"/>


<link href="css/floating-buttons.css" rel="stylesheet"/>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"/>

   <link rel="stylesheet" type="text/css"
  href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"  rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  rel="stylesheet"/>

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '489625390408393');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=489625390408393&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->


<!-- Fallback Open Graph (OG) Tags -->
<meta property="og:title" content="Oxford School of English – Best English Speaking Courses in Delhi" />
<meta property="og:description" content="Join Oxford School of English. English Speaking Courses in Pitampura, Rajouri Garden, South Extension and Laxmi Nagar since 1997." />
<meta property="og:image"content="https://www.oxfordschoolofenglish.in/images/og/english-course.jpg" />
<meta property="og:url" content="https://www.oxfordschoolofenglish.in/" />
<meta property="og:type" content="website" />


<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="/oxford-school-of-english-icon.png">
<link rel="apple-touch-icon" href="/oxford-english-apple-icon.png">

<!-- Google tag (gtag.js) for GA4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6VXK325WCQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-6VXK325WCQ');
</script>

    <meta property="og:title" content="PTE Academic | PTE General, Call for PTE Coaching" />
    <meta property="og:description" content="PTE course tailored to achieve your desired score. Visit the nearest Oxford centre for the best PTE coaching." />
    <meta property="og:image" content="https://oxfordschoolofenglish.in/og/pte-coaching.jpg" />
    <meta property="og:url" content="https://oxfordschoolofenglish.in/pte-coaching-near-me.php" />
    <meta property="og:type" content="website" />

    <link rel="canonical" href="https://oxfordschoolofenglish.in/pte-coaching-near-me.php" />
    <link rel="stylesheet" href="./banners/css/banner6.css">
    <link rel="stylesheet" href="./banners/css/banner5.css">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Course",
      "name": "PTE Coaching",
      "description": "The PTE course is tailored to achieve your desired score. Visit the nearest Oxford center for the best PTE coaching and mock tests.",
      "url": "https://oxfordschoolofenglish.in/pte-coaching-near-me.php",
      "teaches": "PTE Test Preparation",
      "keywords": [
        "Best PTE coaching in Delhi",
        "PTE coaching in Delhi NCR",
        "PTE coaching",
        "PTE exam coaching",
        "PTE classes",
        "PTE institute",
        "PTE coaching center",
        "best PTE coaching",
        "PTE coaching classes",
        "best PTE coaching in Laxmi Nagar"
      ],
      "provider": {
        "@type": "EducationalOrganization",
        "name": "Oxford School of English",
        "url": "https://oxfordschoolofenglish.in",
        "areaServed": "Delhi, India",
        "contactPoint": [
          {
            "@type": "ContactPoint",
            "telephone": "+91-9540127878",
            "contactType": "customer service",
            "areaServed": "Laxmi Nagar, Delhi"
          },
          {
            "@type": "ContactPoint",
            "telephone": "+91-9540127373",
            "contactType": "customer service",
            "areaServed": "Pitampura, Delhi"
          },
          {
            "@type": "ContactPoint",
            "telephone": "+91-9319608182",
            "contactType": "customer service",
            "areaServed": "Rajouri Garden, Delhi"
          },
          {
            "@type": "ContactPoint",
            "telephone": "+91-9810735296",
            "contactType": "customer service",
            "areaServed": "South Extension, Delhi"
          }
        ],
        "address": [
          {
            "@type": "PostalAddress",
            "streetAddress": "E 354, Nirman Vihar, Adjacent to Nirman Vihar Metro Station Gate Number 2, Opposite V3S Mall",
            "addressLocality": "Laxmi Nagar",
            "addressRegion": "East Delhi",
            "postalCode": "110092",
            "addressCountry": "IN"
          },
          {
            "@type": "PostalAddress",
            "streetAddress": "365 Kohat Enclave, Near Kohat Metro Station Gate No. 3",
            "addressLocality": "Pitampura",
            "addressRegion": "North Delhi",
            "postalCode": "110034",
            "addressCountry": "IN"
          },
          {
            "@type": "PostalAddress",
            "streetAddress": "A 4, Vishal Enclave, Opposite Metro Pillar No. 411",
            "addressLocality": "Rajouri Garden",
            "addressRegion": "West Delhi",
            "postalCode": "110027",
            "addressCountry": "IN"
          },
          {
            "@type": "PostalAddress",
            "streetAddress": "E 10, Part-I, Near South Extension Metro Station",
            "addressLocality": "South Extension",
            "addressRegion": "South Delhi",
            "postalCode": "110049",
            "addressCountry": "IN"
          }
        ]
      },
      "hasCourseInstance": {
        "@type": "CourseInstance",
        "courseMode": "Offline",
        "startDate": "2025-06-15",
        "endDate": "2025-08-15",
        "location": {
          "@type": "Place",
          "name": "Oxford School of English – All Branches",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Delhi",
            "addressCountry": "IN"
          }
        },
        "offers": {
          "@type": "Offer",
          "price": "12000",
          "priceCurrency": "INR",
          "availability": "https://schema.org/InStock",
          "validFrom": "2025-06-01",
          "url": "https://oxfordschoolofenglish.in/pte-coaching-near-me.php"
        }
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.5",
        "reviewCount": "1500",
        "bestRating": "5",
        "worstRating": "1"
      }
    }
    </script>

</head>
<body>
    

<header>
   <!--Desktop Navbar Header Code Start-->
   <div class="d-lg-block d-none">
    <div class="desktop-navbar">
     <nav class="navbar navbar-expand-lg navbar-light fixed-top">
         <a href="/">
            <img loading="lazy" class="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp" alt="oxford school of english delhi logo"/>
         </a>
      <button aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbar" data-toggle="collapse" type="button">
       <span class="navbar-toggler-icon">
       </span>
      </button>
      <div class="collapse navbar-collapse" id="navbar">
       <ul class="navbar-nav m-auto">
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Home
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="index.php">
           Home
          </a>
          <a class="dropdown-item" href="about.php">
           About
          </a>
          <a class="dropdown-item" href="gallery-fun-learning.php">
           Gallery
          </a>
          <a class="dropdown-item" href="english-blogs.php">
          English Blogs
          </a>
          <a class="dropdown-item" target="_blank" href="lms">
           LMS
          </a>
          <a class="dropdown-item" href="franchise-opportunity.php">
           Franchise
          </a>
         </div>
        </li>
        <li class="nav-item dropdown megamenu-li large-li">
         <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
          Courses
         </a>
         <div aria-labelledby="dropdown01" class="dropdown-menu megamenu">
          <div class="row">
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course.php">
             All Courses
            </a>
            <a class="dropdown-item" href="advance-english-speaking-course.php">
             Interchange  Advance Level-3
            </a>
            <a class="dropdown-item" href="online-english-speaking-course.php">
             Online English Classes
            </a>
            <a class="dropdown-item" href="pte-coaching-online.php">
             PTE Online Coaching
            </a>
            <a class="dropdown-item" href="personalised-english-classes.php">
             Personalised Classes
            </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course-for-beginners.php">
             Interchange  Beginners 
            </a>
            <a class="dropdown-item" href="ielts-coaching-near-me.php">
             IELTS Course
            </a>
            <a class="dropdown-item" href="online-ielts-coaching.php">
             IELTS Online Coaching
            </a>
            <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">
             IELTS and English
            </a>
            <a class="dropdown-item" href="personality-development-course.php"> Personality Development </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">
             Interchange  Intermediate Level-2
            </a>
            <a class="dropdown-item" href="basic-spoken-english-course.php">
             Basic Spoken English Course
            </a>
            <a class="dropdown-item" href="pte-coaching-near-me.php">
             PTE Course
            </a>
            <a class="dropdown-item" href="english-and-pte-coaching-classes.php"> PTE and English </a>
            <a class="dropdown-item" href="competitive-exam-english-classes.php"> Competitive Exams </a>
           </div>
          </div>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Placement
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="hire-fresher.php">
           Employer
          </a>
          <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
           Student
          </a>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Contact
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="contact-us.php"> All Centers </a>
          <a class="dropdown-item" href="contact-us-pitampura.php"> Pitampura </a>
          <a class="dropdown-item" href="contact-us-laxmi-nagar.php"> Laxmi Nagar </a>
          <a class="dropdown-item" href="contact-us-rajouri-garden.php"> Rajouri Garden </a>
          <a class="dropdown-item" href="contact-us-south-extension.php"> South Extension </a>
         </div>
        </li>
       </ul>
      </div>
      <div class="d-flex flex-row justify-content-end">
       <button class="pay-online-button"> <a href="https://rzp.io/l/OSEDELHI" target="_blank"> Pay Online </a> </button>
       
       <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      
      </div>
     </nav>
    </div>
    <div class="top-navbar d-lg-block d-none">
     <div class="container-fluid">
      <div class="d-flex flex-row justify-content-between">
       <button class="btn-year" type="btn">
        Since 1997 | 4 Branches
       </button>
       <div class="d-flex flex-row justify-content-center">
        <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           LEARN
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SPEAK
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SUCCEED
          </p>
         </div>
        </div>
       </div>
       <button class="btn-year" type="btn">
        One Lakh Students Trained
       </button>
      </div>
     </div>
    </div>
   </div>
   <!--Desktop Navbar Header Code End-->
   <!--Mobile Navbar Header Code Start-->
   <div class="d-block d-lg-none">
    <div class="top-navbar">
     <div class="d-flex flex-row justify-content-center">
      <div class="d-flex flex-row m-auto">
          <a href="index.php">
              <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
          </a>

       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          LEARN
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SPEAK
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SUCCEED
         </p>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div class="mobile-navbar">
     <div class="d-flex flex-row justify-content-between">
      <!--<button class="call-us-button" type="btn">-->
      <!-- <i class="fa fa-solid fa-phone mr-1">-->
      <!-- </i>-->
      <!-- Call Us-->
      <!--</button>-->
      <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      <a href="index.php">
          <img loading="lazy" alt="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp"/>
      </a>
      <button class="call-us-button" type="button" onclick="openSidebar()">
       Menu
       <i class="fa fa-solid fa-bars ml-1" >
       </i>
      </button>
      <div id="backdrop-sidebar"></div>
      <div class="sidebar" id="sidebar">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="navbar-collapse collapse show" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="menu-nav">
                    <a  class="nav-link mobile-navlink01">
                        MENU
                    </a>
                    <i class="fa fa-solid fa-circle-xmark close-icon" onclick="closeSidebar()">
                    </i>
            </li>
          <li class="nav-item dropdown">
            <a  class="nav-link mobile-navlink01" href="index.php">
             HOME
            </a>
           </li>
            <li>
                <a class="nav-link mobile-navlink01" href="about.php">
                    About 
                </a>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                English Courses
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="english-speaking-course.php">All English Courses</a>
                        <a class="dropdown-item" href="basic-spoken-english-course.php">Basic English Course</a>
                        <a class="dropdown-item" href="english-speaking-course-for-beginners.php">English Speaking Course for <br> Beginners - Level 1</a>
                        <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">Intermediate English Course - Level 2</a>
                        <a class="dropdown-item" href="advance-english-speaking-course.php">Advanced English Course - Level 3</a>
                        <a class="dropdown-item" href="online-english-speaking-course.php">Online English Speaking Course </a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                IELTS
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="ielts-coaching-near-me.php">IELTS Coaching</a>
                        <a class="dropdown-item" href="online-ielts-coaching.php">IELTS Online One-on-One</a>
                        <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">IELTS & English Course</a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PTE
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="pte-coaching-near-me.php">PTE Coaching</a>
                        <a class="dropdown-item" href="english-and-pte-coaching-classes.php">PTE & English Course</a>
                        <a class="dropdown-item" href="pte-coaching-online.php">PTE Online One-on-One</a>
                </div>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personality-development-course.php">
                    Personality Development
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="competitive-exam-english-classes.php">
                    Competitive Exam Classes
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personalised-english-classes.php">
                    Personalised English Classes
                </a>
            </li>
            <li class="nav-item dropdown megamenu-li">
                <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
                    CONTACT US
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="contact-us.php">
                    All Centers
                    </a>
                    <a class="dropdown-item" href="contact-us-south-extension.php">
                    South Extension
                    </a>
                    <a class="dropdown-item" href="contact-us-rajouri-garden.php">
                    Rajouri Garden
                    </a>
                    <a class="dropdown-item" href="contact-us-pitampura.php">
                    Pitampura
                    </a>
                    <a class="dropdown-item" href="contact-us-laxmi-nagar.php">
                    Laxmi Nagar
                    </a>
                </div>
            </li>
            <li>
                <a class="nav-link mobile-navlink01" href="gallery-fun-learning.php">
                    Gallery
                </a>
            </li>
              <li>
                <a class="nav-link mobile-navlink01" href="english-blogs.php">
                    English Blogs
                </a>
            </li>
            <li class="nav-item dropdown">
            <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PLACEMENT
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="hire-fresher.php">
                Employer
                </a>
                <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
                Student
                </a>
            </div>
            </li>
         </ul>
        </div>
       </nav>
      </div>
     </div>
    </div>

    <div class="top-navbar d-lg-none d-block">
      <div class="d-flex flex-row justify-content-center">
        <button class="navbar-button">Since 1997 | 4 Branches | One Lakh Students Trained</button>
      </div>
    </div>
   </div>
   <!--Mobile Navbar Header Code End-->
  </header>
  
  
<!--floating buttons start-->

    <a class="fa-brands fa-whatsapp fa-beat fa-xl m-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"></a>
    <div class="w-numbers m-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
            
    <a class="fa-brands fa-whatsapp fa-beat fa-xl d-flex d-md-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"> <span> Whatsapp</span></a>

    <div class="w-numbers web-d-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
      
    <a class="floatingss fa fa-phone-volume fa-beat d-md-block d-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
      
    <a class="floatingss fa fa-phone-volume fa-beat d-flex d-md-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"><span> Phone</span></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
<!--floating buttons end-->    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Courses</li>
        <li class="breadcrumb-item active" aria-current="page">PTE Course</li>
      </ol>
    </nav>

    <section id="course-banner06">
  <div class="cousre-banner06">
    <div class="container-fluid">
      <div class="row m-0">
        <div class="col-12 col-lg-7 mb-3 d-flex flex-column justify-content-center order-2 order-lg-1" >

          <div class="course-banner06-text-box">
            <h1 class="course-banner05-heading" > Best <span class="gray-color-span">PTE </span> Coaching <br> in <span class="gray-color-span">Delhi </span></h1> 
            <img src="./banners/banner-images/courses/Mobile-Webp/best-pte-coaching-in-delhi.webp" class="img-fluid course-banner06-image-mobile d-lg-none d-block" alt="Best PTE Coaching in Delhi with experienced trainers" title="Pte Coaching" >
          
            <div class="d-flex flex-row justify-content-center">
              <div class="course-banner06-duration-box">
             
                      <h5 class="course-banner06-duration-heading">Duration: </h5>
                      <div class="course-banner06-time-box d-flex flex-column justify-content-center">
                        <h6 class="course-banner06-time">1.5 Months</h6>
                      </div>
                 
              </div>
            </div>
          </div>
          
         
        </div>

        <div class="col-12 col-lg-5 order-1 order-lg-2 d-none d-lg-block">
          <div class="d-flex flex-row justify-content-center">
            <img src="./banners/banner-images/courses/Desktop-Webp/best-pte-coaching-in-delhi.webp" class="img-fluid course-banner06-image" alt="Best PTE Coaching in Delhi with experienced trainers" title="Pte Coaching" >
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

    <section id="section1">
   <!--Google Review Container Section Code Start-->
   <div class="google-review-container mt-standard">
    <div class="container-fluid">
     <div class="d-flex flex-row justify-content-center">
      <h2 class="h4">
       Best
       <span class="span03">
        PTE Coaching
       </span>
        Institute 
      </h2>
     </div>
     <div class="d-flex flex-row justify-content-center">
      <div class="google-rating-container py-standard">
       <div class="container">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <img src="./assets/more-images/1-google-rating.webp" alt="Google rating of Oxford School of English">
         <h3>
          4.3
         </h3>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Google Review Container Section Code End-->
  </section>

  <section class="new-online-container" id="section9">
   <!--Online english classes Section Start-->
   <div class="">
    <div class="new-english-container mt-standard">
     <div class="row m-0">
     <div class="col-12 col-lg-6 d-flex align-items-center pl-0 relative">
          <div class="bg-Image">
              <img class="" src="./assets/pte-courses/pte-course/9-best-pte-classes.webp" alt="Best PTE Institute in Delhi for All Levels">
          </div>
      </div>
      <div class="col-12 col-lg-6 mb-3 mb-md-3 d-flex flex-column justify-content-center">
       <h2 class="new-courses-button">
        PTE Coaching Classes 
       </h2>
       <div class="new-courses-inner">
        <p class="new-courses-paragraph">
            <b>What is the PTE Exam?</b><br>
        The Pearson Test of English (PTE) is a globally recognised English proficiency test that assesses non-native speakers' communication skills for academic, professional, or everyday use. It is accepted by universities, employers, and immigration authorities worldwide.
        </p>
      
        <span class="span05 xs-hidden" id="content-part01">
         <p class="new-courses-paragraph">
             <b>Skills Tested in PTE</b><br>
          PTE evaluates four essential English skills: Listening, Reading, Writing, and Speaking. The exam is computer-based and scored using AI technology, ensuring quick, unbiased, and highly accurate results for candidates across different proficiency levels.
         </p>
         <p class="new-courses-paragraph">
             <b>Looking for PTE Coaching?</b><br>
         Oxford School of English offers proven training programs if you are searching for expert PTE coaching in Delhi NCR. With personalized practice, AI-powered mock tests, and experienced trainers, we help you achieve your desired PTE score for study, work, or migration.
         </p>
        </span>
        <div class=" text-right md-hidden">
         <button class="read-more-btn" id="read-more-btn01" type="btn">
          Read More
         </button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Online english classes Section End-->
  </section>
  

  <section id="section15">
   <!--best-speaking-in-delhi-container section Code Start-->
   <div class="best-speaking-in-delhi-container py-standard mt-standard">
    <div class="container text-center">
     <h3 class="best-speaking-in-delhi-container-button">
     Types of PTE Exams
     </h3>
     <div class="d-flex flex-row justify-content-center">
      <div class="best-speaking-in-delhi-description-container text-justify p-standard-inner">
       <div class="d-block">
        <p class="m-0">
        The Pearson Test of English (PTE) offers various exams based on your study, work, or migration goals. Choosing the right exam ensures you meet specific university, employer, or visa requirements.
        <p class="my-2"><b>PTE Academic:</b></p>
        PTE Academic is suitable for students applying for higher education abroad and individuals seeking permanent residency in countries like Australia, New Zealand, Canada, the UK, and the USA. The test assesses English proficiency in academic environments through real-life university tasks. Universities, colleges, and immigration authorities worldwide accept PTE Academic scores
        
        </p>
       </div>
       <div class="">
        <p class="m-0">
         <div class="span05 hidden" id="hidden-content10">
             
          <p class="m-0"> 
           <p class="my-2"><b>PTE Academic UKVI:</b></p>
            PTE Academic is suitable for students applying for higher education abroad and individuals seeking permanent residency in countries like Australia, New Zealand, Canada, the UK, and the USA. The test assesses English proficiency in academic environments through real-life university tasks. Universities, colleges, and immigration authorities worldwide accept PTE Academic scores
           <p class="my-2"><b>PTE General:</b></p>
           PTE General assesses general English language skills for career growth and personal development. Employers and institutions recognize it, but it is not valid for immigration or university admissions. The test includes a written component (reading, writing, listening) and a spoken interview focusing on practical communication
           
           <p class="my-2"><b>PTE Home:</b></p>
           PTE Home (A1, A2, B1 levels) is designed for UK family visas, spouse visas, settlement, and citizenship applications. It tests only speaking and listening skills, offering a simple and quick assessment. The UK Home Office approves PTE Home results, usually within 48 hours.
           
            <p class="my-2"><b>Choosing the Right PTE Exam:</b></p>
            Select your exam based on your goal. Choose PTE Academic or PTE Academic UKVI for study or migration. You should opt for PTE Home for UK family or settlement visas. Take the PTE General if you aim to prove your everyday English skills for work or personal reasons. Always confirm requirements with your university, employer, or immigration authority before registering.
            
           
          </p>
        
         </div>
        </p>
       </div>
       <div class="d-block">
        <div class="d-flex flex-row justify-content-end">
         <button class="read-more-btn" id="read-more-btn10" type="btn">
          Read More
         </button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--best-speaking-in-delhi-container section Code End-->
  </section>


  <section id="section6">
   <!--Contact Us Container Section Code Start-->
   <div class="contact-us-container mt-standard">
    <div class="container-fluid">
     <div class="contact-us-main-cntainer py-standard px-standard">
      <div class="container-fluid p-0">
       <div class="d-flex flex-row justify-content-center">
        <h4 class="contact-us-button">
         Contact Us
        </h4>
       </div>
       <!--<h6 class="heading01">Visit or Call Your Nearest Branch for English Speaking Classes</h6>-->
       <div class="row">
        <div class="col-12 col-lg-6  custom-mb">
            <div class="contact-card-container p-standard-inner">
    <div class="">
        <h5>
        QUICK  ENQUIRY
        </h5>
        <p>
        We're happy to help you on your journey towards a brighter career.
        </p>
        <form action="" method="post" name="frm">
            <div class="d-flex flex-row mb-3">
                <input class="form-control01" name="studentName" placeholder="Enter your Name" type="text" required />
            </div>
            <div class="d-flex flex-row mb-3">
                <input class="form-control01" name="mobile" placeholder="Enter your Number" type="text" required />
            </div>
            <div class="d-flex flex-row mb-3">
                <input class="form-control01" name="course" placeholder="Course" type="text" required />
            </div>
            <div class="d-flex flex-row mb-3">
                <select class="form-control01" name="centre" required>
                    <option value="" selected> Select Center</option>
                    <option value="Pitampura"> Pitampura</option>
                    <option value="Laxmi Nagar"> Laxmi Nagar</option>
                    <option value="Rajouri Garden"> Rajouri Garden</option>
                    <option value="South Extension"> South Extension</option>
                </select>
            </div>
            <input class="d-none" type="hidden" name="form_submitted" value="1"> 
            <div class="d-flex flex-row">
                <button class="submit-btn" type="submit" name="submitQuick"> Submit </button>
            </div>
        </form>
        
        <!-- <div class="modal fade" id="modalthanks" role="dialog">-->
        <!--    <div class="modal-dialog">-->
        <!--        <div class="modal-content" style="padding: 20px 0 10px 0;background:#fff">-->
        <!--            <div class="modal-body text-center">-->
        <!--                <p style="font-size: 18px; margin-bottom: 20px; color: #000;">Thanks for showing interest, Our Counselor will contact you</p>-->
        <!--                <button type="button" class="btn btn-default" data-dismiss="modal"-->
        <!--                        style="padding: 10px 20px;">Close-->
        <!--                </button>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>
</div>        </div>
        <div class="col-12 col-lg-6  custom-mb custom-mb-0 d-flex flex-column justify-content-center">
         <div class="contact-card-container p-standard-inner">
          <div class="">
           <div class="d-flex flex-row mb-4">
            <div class="location-box d-flex flex-column justify-content-center">
             <div class="d-flex flex-row justify-content-center">
              <i class="fa fa-solid fa-location-dot location-icon">
              </i>
             </div>
            </div>
            <div class="margin-box">
             <p class="location-paragraph">
              South Extension
              <span class="span04">
               (South Delhi)
              </span>
             </p>
             <h6 class="contact-number-heading">
              9810735296
             </h6>
            </div>
           </div>
           <div class="d-flex flex-row mb-4">
            <div class="location-box d-flex flex-column justify-content-center">
             <div class="d-flex flex-row justify-content-center">
              <i class="fa fa-solid fa-location-dot location-icon">
              </i>
             </div>
            </div>
            <div class="margin-box">
             <p class="location-paragraph">
              Rajouri Garden
              <span class="visible01">
               ....
              </span>
              <span class="span04">
               (West Delhi)
              </span>
             </p>
             <h6 class="contact-number-heading">
              9319608182
             </h6>
            </div>
           </div>
           <div class="d-flex flex-row mb-4">
            <div class="location-box d-flex flex-column justify-content-center">
             <div class="d-flex flex-row justify-content-center">
              <i class="fa fa-solid fa-location-dot location-icon">
              </i>
             </div>
            </div>
            <div class="margin-box">
             <p class="location-paragraph">
              Pitampura
              <span class="visible01">
               ...........
              </span>
              <span class="span04">
               (North Delhi)
              </span>
             </p>
             <h6 class="contact-number-heading">
              9540127373
             </h6>
            </div>
           </div>
           <div class="d-flex flex-row mb-4">
            <div class="location-box d-flex flex-column justify-content-center">
             <div class="d-flex flex-row justify-content-center">
              <i class="fa fa-solid fa-location-dot location-icon">
              </i>
             </div>
            </div>
            <div class="margin-box">
             <p class="location-paragraph">
              Laxmi Nagar
              <span class="visible01">
               .........
              </span>
              <span class="span04">
               (East Delhi)
              </span>
             </p>
             <h6 class="contact-number-heading">
              9540127878
             </h6>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <div class="d-flex flex-row justify-content-center mt-3">
        <button class="download-brochure-button" type="btn">
            <a href="./assets/oxford-english-brochure.pdf" target="_blank">
                Download Brochure
            </a>
        </button>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Contact Us Container Section Code End-->
  </section>
  

  <section id="section24">
      <div class="d-flex flex-row justify-content-center">
   <h4 class="new-fun-button mt-standard">
    Complete Guide to PTE Academic, PTE General, and PTE Home Exams
   </h4>
  </div>
  <section>
   <div class="new-abc-fun-container pt-5 pb-standard">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-lg-5 d-flex align-items-center">
       <img class="english-with-fun-image" src="./assets/pte-courses/pte-course/24-who-should-join.webp" alt="Best English Classes">
      </div>
      <div class="col-12 col-lg-7">
       <div class="updated-video-content-description p-standard-inner">
        <div class="">
         <h4 class="updated-video-description-heading">
          Updated Description:
         </h4>
         <div class="d-block">
          <p class="m-0">
           <ol class="mx-2">
            <li class="mx-2"><b>PTE Academic</b>
                <ul class="mx-0" type="disc"><b>Purpose:</b>
                   <li class="mx-3">Required for university admissions and immigration applications in Australia, New Zealand, Canada, the UK, and the USA.</li> 
                   <li class="mx-3">Used by students and professionals to prove English proficiency.</li>
                </ul>
            </li>
          </p>
         </div>
         <div class="">
          <p class="m-0">
           <div class="hidden" id="content03">
            <p class="m-0">
           
                <ul class="mx-3" type="disc"><b>Exam Pattern:</b>
                   <li class="mx-3">Duration: 2 hours</li> 
                   <li class="mx-3">Format: Computer-based test, AI-scored</li>
                   <li class="mx-3">Sections:
                    <ol class="mx-3">
                        <li><b>Speaking & Writing (54–67 mins)</b> &ndash; Read Aloud, Repeat Sentence, Describe Image, Essay Writing, etc.</li>
                        <li><b>Reading (29–30 mins)</b> &ndash; Multiple Choice, Fill in the Blanks, Reorder Paragraphs.</li>
                        <li><b>Listening (30–43 mins)</b> &ndash; Summarize Spoken Text, Write from Dictation, Multiple-Choice Questions.</li>
                    </ol>
                   </li>
                   
                </ul>
                
                <ul class="mx-3" type="disc">
                    <li class="mx-3">Score Range: 10–90</li>
                    <li class="mx-3">Results available within 24–48 hours</li>
                </ul>
            
           </ol>
           
           <ol start="2" class="mx-2">
            <li class="mx-2"><b>PTE General</b>
                <ul class="mx-0 mt-2" type="disc"><b>Purpose:</b>
                   <li class="mx-3">Designed to assess general English skills for personal, professional, and academic growth.</li> 
                   <li class="mx-3">Often used for job applications and English learning, but not for visas or university admissions.</li>
                </ul>
                <ul class="mx-0 mt-2" type="disc"><b>Exam Pattern:</b>
                   <li class="mx-3">Duration: Varies based on the level</li> 
                   <li class="mx-3"class="mx-3">Format: Two parts &ndash;
                    <ol class="mx-3">
                        <li ><b>Written Test </b>(Reading, Writing, Listening)</li>
                        <li ><b>Spoken Test </b>(Face-to-face interview)</li>
                    </ol>
                   </li>
                </ul>
                <ul class="mx-0 mt-2" type="disc"><b>Levels:</b><br>PTE General offers six levels (A1 to C2), mapped to the Common European Framework of Reference (CEFR)</ul>
                <ul class="mx-0 mt-2" type="disc"><b>Scoring:</b>
                    <li class="mx-3">No fixed score; the results are graded as Pass, Merit, or Distinction</li>
                    <li class="mx-3">Results take up to 6 weeks</li>
                </ul>
            </li>
            </ol>
            
            <ol start="3" class="mx-2">
            <li class="mx-2"><b>PTE Home</b>
                <ul class="mx-0 mt-2" type="disc"><b>Purpose:</b>
                   <li class="mx-3">Designed for UK visa applications (family, work, and settlement visas).</li> 
                   <li class="mx-3">Accepted by the UK Home Office.</li>
                </ul>
                <ul class="mx-0 mt-2" type="disc"><b>Exam Pattern:</b>
                   <li class="mx-3">Duration: 22 minutes</li> 
                   <li class="mx-3">Format: Computer-based Speaking and Listening test only &ndash;
                   <li class="mx-3">
                       Test Levels:
                    <ol class="mx-3">
                        <li >PTE Home A1 – Required for Spouse/Partner Visa</li>
                        <li >PTE Home A2 – For visa extensions (after 2.5 years)</li>
                        <li>PTE Home B1 – For Indefinite Leave to Remain (ILR) or UK Citizenship</li>
                    </ol>
                   </li>
                </ul>
                <ul class="mx-0 mt-2" type="disc"><b>Scoring:</b>
                    <li class="mx-3">Pass/Fail (No numerical score)</li>
                    <li class="mx-3">Results available within 24 hours</li>
                </ul>
            </li>
            </ol>
            <b>Which PTE Exam is Right for You?</b><br>
            The suitable PTE exam depends on the purpose of taking the test. 
          </p>
           </div>
          </p>
         </div>
        </div>
        <div class="d-block">
         <div class="d-flex flex-row justify-content-end">
          <button class="read-more-btn12" id="read-more-btn13" type="btn">
           Read More
          </button>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  </section>
  

  
  <section id="section15">
   <!--best-speaking-in-delhi-container section Code Start-->
   <div class="best-speaking-in-delhi-container py-standard mt-standard">
    <div class="container text-center">
     <h4 class="best-speaking-in-delhi-container-button">
      Our PTE Training Methodology    
     </h4>
     <div class="d-flex flex-row justify-content-center">
      <div class="best-speaking-in-delhi-description-container text-justify p-standard-inner">
       <div class="d-block">
        <p class="m-0">
            <p class="mb-2">At Oxford School of English, we follow a structured and result-oriented approach to ensure students achieve their desired score. Our PTE Exam coaching curriculum is constantly updated to match the latest PTE patterns.</p>
          <p><b>1. Initial Assessment & Orientation</b></p>
            <ul class="mx-4">
              <li><b>Mock Test & Skill Analysis</b> – A diagnostic test to assess students' strengths and weaknesses.</li>
              <li><b>Introduction to PTE Format</b> – Explain each section's test structure, scoring, and strategies.</li>
            </ul>
        
            </p>
           </div>
           <div class="">
            <p class="m-0">
            <div class="span05 hidden" id="content04">
            <p><b>2. Section-Wise Training Approach</b></p>
            <p><b>A. Speaking & Writing</b></p>
            <ul class="mx-4">
              <li><b>Read Aloud</b> – Pronunciation, fluency, and intonation exercises.</li>
              <li><b>Repeat Sentence</b> – Listening drills, chunking method.</li>
              <li><b>Describe Image</b> – Structured responses using templates.</li>
              <li><b>Re-tell Lecture</b> – Note-taking techniques, summarization strategies.</li>
              <li><b>Answer short questions</b> – Quick thinking and vocabulary drills.</li>
              <li><b>Summarise Written Text</b> – Paraphrasing and structuring answers concisely.</li>
              <li><b>Essay Writing</b> – Template-based approach, idea generation, coherence.</li>
            </ul>
        
            <p><b>B. Reading</b></p>
            <ul class="mx-4">
              <li><b>Fill in the Blanks (Reading & Writing)</b> – Contextual vocabulary, collocations.</li>
              <li><b>Multiple Choice (Single & Multiple Answers)</b> – Skimming, scanning, elimination techniques.</li>
              <li><b>Reorder Paragraphs</b> – Logical sequencing, connectors, sentence structure.</li>
              <li><b>Fill in the Blanks (Reading Only)</b> – Grammar-based techniques, collocations.</li>
            </ul>
        
            <p><b>C. Listening</b></p>
            <ul class="mx-4">
              <li><b>Summarise Spoken Text</b> – Active listening, note-taking skills.</li>
              <li><b>Multiple Choice (Single & Multiple Answers)</b> – Keyword identification.</li>
              <li><b>Fill in the Blanks</b> – Predictive listening, spelling focus.</li>
              <li><b>Highlight Correct Summary</b> – Main idea recognition.</li>
              <li><b>Select Missing Word</b> – Contextual understanding.</li>
              <li><b>Highlight Incorrect Words</b> – Focus on phonetics and pronunciation.</li>
              <li><b>Write from Dictation</b> – Short-term memory training, spelling drills.</li>
            </ul>
        
            <p><b>3. Practice & Mock Tests</b></p>
            <ul class="mx-4">
              <li><b>Daily Practice Sessions</b> – Individual and group practice for each section.</li>
              <li><b>Full-Length Mock Tests</b> – Simulated test environment, adaptive scoring.</li>
              <li><b>Time Management Strategies</b> – Skipping unproductive sections, improving speed.</li>
              <li><b>Instant Feedback & Performance Tracking</b> – AI-based score analysis and teacher evaluation.</li>
            </ul>
        
            <p><b>4. Personalised Coaching & Doubt Resolution</b></p>
            <ul class="mx-4">
              <li><b>One-on-one sessions</b> for students who need extra help.</li>
              <li><b>Error Analysis & Correction</b> – Identify weak areas and provide targeted exercises.</li>
            </ul>
        
            <p><b>5. Exam Day Strategies & Confidence Building</b></p>
            <ul class="mx-4">
              <li><b>Stress Management & Relaxation Techniques</b> before the exam.</li>
              <li><b>Time-Saving Tips</b> – Efficient answering techniques.</li>
              <li><b>Last-Minute Strategy Sessions</b> – Quick revision of templates and rules.</li>
            </ul>
        
            <p><b>6. Post-Training Support</b></p>
            <ul class="mx-4">
              <li><b>Reassessment Tests</b> – To check improvement.</li>
              <li><b>Retake Guidance</b> – If needed, providing strategies to score higher.</li>
            </ul>
         </div>
        </p>
       </div>
       <div class="d-block ">
        <div class="d-flex flex-row justify-content-end">
         <button class="read-more-btn" id="read-more-btn14" type="btn">
          Read More
         </button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--best-speaking-in-delhi-container section Code End-->
  </section>

  
  <section id="section8">
   <!--Why Choose Us Section Code Start-->
   <div class="why-choose-us-container mt-standard">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-md-4 col-lg-3 d-flex  custom-mb">
       <img alt="Which Is the Best PTE and English Coaching Class for You?" class="why-choose-us-image" src="./assets/pte-courses/pte-course/8-why-us.webp">
      </div>
      <div class="col-12 col-md-8 col-lg-9  custom-mb d-flex flex-column justify-content-center">
       <div class="text-content-container p-standard-inner">
        <div class="">
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            27+ Years of Excellence  -
           </b>
           Established in 1997, we are a trusted name in English language training.
          </p>
         </div>
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
           Recognised & Certified   -
           </b>
            NSDC training partner, offering Cambridge University Press courses.
          </p>
         </div>

         <span class="xs-hidden d-md-block" id="hidden-content">
            <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
              <b>
                Affordable Fees -
              </b>
              Over 100,000 students trained in different courses, excelling in communication and career growth.
              </p>
            </div>
            <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
              <b>
                Flexible & Affordable  -
              </b>
                Multiple course formats with budget-friendly fees.
              </p>
            </div>
            <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
              <b>
              Expertise in Both Offline & Online Learning  -
              </b>
              Flexible options for convenience
              </p>
            </div>
        </span>

        <div class="d-md-none text-right">
          <button class="read-more-btn" id="read-more-btn" type="btn">
            Read More
          </button>
        </div>
        
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Why Choose Us Section Code End-->
  </section>
  

  <section id="section12">
   <!--online-english-coaching-outcome-section Code Start-->
   <div class="new-courses-section-container mt-standard py-standard">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-lg-5 mb-3 mb-md-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
       <h4 class="text-center h4">
        Outcome of Our PTE Coaching Program
       </h4>
       <div class="white-text-container pt-3 pb-1">
        <div class="container-fluid">
         <p class="coaching-outcome-description">
          Our PTE classes help you build the skills needed to score high in all four modules—Speaking, Writing, Reading, and Listening. You gain speed, accuracy, and confidence with personalised training, regular mock tests, and proven strategies. We also provide guidance on exam format, time management, and scoring criteria. Our training prepares you to succeed in your PTE exam, whether for study, work, or migration.
         </p>
        </div>
       </div>
      </div>
      <div class="col-12 col-lg-7 mb-3 mb-md-0 order-1 order-lg-2">
       <img alt="Achieve Your Target Score with a Top PTE Training Institute" src="./assets/pte-courses/pte-course/12-outcome.webp">
      </div>
     </div>
    </div>
   </div>
   <!--online-english-coaching-outcome-section Code Start-->
  </section>
  
  

  <section id="section14">
   <!--students-testimonial-container section Code Start-->
   <div class="students-testimonial-container mt-standard">
    <div class="container-fluid">
     <!--<h6>-->
     <!-- Listen From Our Proud Students-->
     <!--</h6>-->
     <div class="footer-before-container py-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-12">
        <h5 class="text-center"> Listen From Our Proud Students</h5>
       </div>
      </div>
     </div>
    </div>
    
     <!--<h4 class="new-courses-button"> Listen From Our Proud Students </h4>-->
    </div>
    <div class="container-fluid01">
     <div class="owl-carousel owl-theme" id="owl-carousel02">
         
      <!-- item 1 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="expressing satisfaction with spoken English training" class="testimonial-image" src="./assets/section-14-text-review/harsha-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Harsha </p>
         <p class="review-description">
          I really enjoy coming to Oxford because of my teacher, Amanpreet Ma'am, and her amazing teaching. The classroom atmosphere is very good and full of learning.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 1 end -->
      
      <!-- item 2 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Student review of the english-speaking course at oxford school of english in delhi, sharing a." class="testimonial-image" src="./assets/section-14-text-review/abhijai-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Abhijai </p>
         <p class="review-description">
          It has been an amazing journey till now. I have learned many new things, and I am still enjoying the experience of learning something new.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 2 end -->
      
      <!-- item 3 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Paridhi appreciates interactive activities and caring teachers at oxford." class="testimonial-image" src="./assets/section-14-text-review/paridhi-aggarwal.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Paridhi Aggarwal </p>
         <p class="review-description">
            Oxford is the best place to learn English. Activities like role plays, debates, and extempore are helpful. The study material and LMS are great. My faculty is very supportive. Highly recommended!
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 3 end -->
      
      <!-- item 4 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Recommending Oxford after a great learning experience" class="testimonial-image" src="./assets/section-14-text-review/simarjeet-kaur.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Simarjeet Kaur </p>
         <p class="review-description">
            The faculty is very helpful, and activity classes improve our confidence and fluency. I joined at level 2 and am now pursuing level 3 to enhance my skills.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 4 end -->
      
      <!-- item 5 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Shalu highlights useful study material and interactive sessions at oxford." class="testimonial-image" src="./assets/section-14-text-review/shalu-sharma.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Shalu Sharma </p>
         <p class="review-description">
            I'm pursuing Level 2 at Oxford. The faculty is approachable, and activities like GDs, role plays, and discussions are very engaging. Highly recommend for improving English skills!
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 5 end -->
      
      <!-- item 6 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Rashi praises the supportive teachers and engaging classroom methods." class="testimonial-image" src="./assets/section-14-text-review/rashi-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Rashi </p>
         <p class="review-description">
            I love the institute's environment and activities. Ruby Ma'am's polite behavior and clear explanations made learning enjoyable. This has been my best learning experience. Thank you, Oxford!
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 6 end -->
      
      <!-- item 7 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Aakash praises oxford for its expert training and great learning experience." class="testimonial-image" src="./assets/section-14-text-review/aakash-patel.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Aakash Patel </p>
         <p class="review-description">
            There is a great mentor and helpful facilities that support students in their careers. This is really good for every learner. My overall experience is good.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 7 end -->
      
      <!-- item 8 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Giving feedback after course completion." class="testimonial-image" src="./assets/section-14-text-review/shweta-kumari.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Shweta Kumari </p>
         <p class="review-description">
            She has taught us many valuable lessons and motivated us to become the best speakers of the language. Her guidance has truly helped us improve.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 8 end -->
      
      <!-- item 9 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Dilshad thanks oxford for improving speaking skills and confidence." class="testimonial-image" src="./assets/section-14-text-review/dilshad-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Dilshad </p>
         <p class="review-description">
            I joined Oxford to improve my English. My speaking, vocabulary, and grammar have improved. Activity classes and Amanpreet Ma'am's simple teaching method helped me a lot.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 9 end -->
      
      <!-- item 10 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Gaurav praises the course for improving his speaking and writing skills." class="testimonial-image" src="./assets/section-14-text-review/gaurav-chopra.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Gaurav Chopra </p>
         <p class="review-description">
            I joined Oxford to improve my spoken and written English. The result is clear now. The faculty is great, and I'm grateful to be part of this institute.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 10 end -->
      
      <!-- item 11 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Gulfam praises the teachers and learning environment at oxford." class="testimonial-image" src="./assets/section-14-text-review/gulfam-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Gulfam </p>
         <p class="review-description">
            Oxford is a great institute. I have learned many new things here. The teachers are very supportive, and the atmosphere is good. I really enjoy my time here.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 11 end -->
      
      <!-- item 12 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Shail praises ruby ma’am and the helpful learning experience at oxford." class="testimonial-image" src="./assets/section-14-text-review/shail-mishra.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Shail Mishra </p>
         <p class="review-description">
            It's been an amazing experience with Ruby Ma'am. Oxford is a great platform to learn English, and I highly recommend it.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 12 end -->
      
      <!-- item 13 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Ishaan shares a good learning experience at oxford near his location." class="testimonial-image" src="./assets/section-14-text-review/ishaan-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Ishan </p>
         <p class="review-description">
            My journey at Oxford has been amazing. I have learned many new things and gained valuable knowledge. It's been a great experience so far.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 13 end -->
      
      <!-- item 14 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Mukund highlights skill-building and positive learning at oxford." class="testimonial-image" src="./assets/section-14-text-review/mukund-bansal.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Mukund </p>
         <p class="review-description">
            The classes at Oxford are excellent. They help me gain skills, knowledge, and interact with new people. The institute's environment is friendly and peaceful.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 14 end -->
      
      <!-- item 14 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Sharing a positive review about English course" class="testimonial-image" src="./assets/section-14-text-review/utkarsh-rana.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Utkarsh Rana </p>
         <p class="review-description">
            My friend suggested joining Oxford to improve fluency and grammar. The fees are affordable, and the faculty is great. The study materials and vocabulary help a lot.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 14 end -->

     </div>
    </div>
   </div>
   <!--students-testimonial-container section Code End-->
  </section>
  
  
  <section id="section19">
      <div class="hear-student-container">
   <div class="container-fluid">
    <h4 class="hear-student-container-heading">
     <span class="span06"> H</span>ear It from Our Students
    </h4>
    <p class="hear-student-container-description">
     Listen to our students share their learning experiences, growth, and feedback about our courses!
    </p>
   </div>
  </div>
  <section>
   <!--hear-it-student-container-section Code Start-->
   <div class="hear-it-student-container-section pb-standard pt-5">
    <div class="container-fluid01">
     <div class="owl-carousel owl-theme pt-2" id="owl-carousel04">
        <!--item 1 start-->
        <div class="item">
       <div class="hear-it-box-container py-standard-inner">
        <div class="container-fluid">
         <div class="d-flex flex-row justify-content-center">
          <img alt="Ganjeena from Afghanistan shares feedback on her English course experience" class="student-image" src="./assets/19-video-review/ganjeena-video-review.webp">
         </div>
         <h6 class="student-name-heading">
          Ganjeena
         </h6>
         <div class="d-flex flex-row justify-content-center">
          <button class="play-video-button" data-video="https://www.youtube.com/embed/WuzDMDcmhis">
           <i class="fa fa-solid fa-play">
           </i>
           Play Video
          </button>
         </div>
        </div>
       </div>
      </div>
        <!--item 1 end-->
        
        <!--item 2 start-->
        <div class="item">
       <div class="hear-it-box-container py-standard-inner">
        <div class="container-fluid">
         <div class="d-flex flex-row justify-content-center">
          <img alt="Jaspreet is a happy students of our English classes" class="student-image" src="./assets/19-video-review/jaspreet-video-review.webp">
         </div>
         <h6 class="student-name-heading">
          Jaspreet
         </h6>
         <div class="d-flex flex-row justify-content-center">
          <button class="play-video-button" data-video="https://www.youtube.com/embed/HDIBe2SOLE4">
           <i class="fa fa-solid fa-play">
           </i>
           Play Video
          </button>
         </div>
        </div>
       </div>
      </div>
        <!--item 2 end-->
        
        <!--item 3 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Sarpreet confidently presenting during an English speaking class at Oxford" class="student-image" src="./assets/19-video-review/sarpreet-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Sarpreet
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/jpzTZZvGbnw">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 3 end-->
        
        <!--item 4 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Kanika shares her positive review of english coaching at oxford." class="student-image" src="./assets/19-video-review/kanika-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Kanika
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/iLi3GhptGo8">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 4 end-->
        
        <!--item 5 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Deepak giving a student review of Oxford&acirc;&#128;&#153;s English coaching in Delhi" class="student-image" src="./assets/19-video-review/deepak-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Deepak
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/Avjbj6BZUGk">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 5 end-->
        
        <!--item 6 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
                  <img alt="Aanchal explains how English coaching helped build her confidence" class="student-image" src="./assets/19-video-review/anchal-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Aanchal
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/NrVEyg8JVZA">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 6 end-->
        
        <!--item 7 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Geetika explains how English coaching helped build her confidence" class="student-image" src="./assets/19-video-review/geetika-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Geetika
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/6DmCIO-aEDg?feature=share">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 7 end-->
        
        
        <!--item 8 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Mukund sharing feedback about his English speaking course at Oxford School of English in Delhi" class="student-image" src="./assets/19-video-review/mukund-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Mukund
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/S7Uf4iaammE?feature=shareA">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 8 end-->
        
        <!--item 9 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Isha reflects on her beginner journey through English speaking classes" class="student-image" src="./assets/19-video-review/isha-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Isha
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/DHfFvVUoFAY">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 9 end-->
        
        <!--item 10 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Priyanshu talks about learning English at Oxford&acirc;&#128;&#153;s English speaking course" class="student-image" src="./assets/19-video-review/priyanshu-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Priyanshu
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/eEpa4Hj7Rzk?feature=share">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 10 end-->
        
        <!--item 11 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Sumaira from Afghanistan shares feedback on her English course experience" class="student-image" src="./assets/19-video-review/sumaira-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Sumaira
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/bpTHNAShsmM">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 11 end-->
        
        <!--item 12 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Shail shares her journey of improving communication with Oxford&acirc;&#128;&#153;s English course" class="student-image" src="./assets/19-video-review/shail-video-review.webp">
             </div>
             <h6 class="student-name-heading">
              Shail
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/P_MSqh0xtGM">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 12 end-->
        
     </div>
    </div>
   </div>
   <!--hear-it-student-container-section Code End-->
  </section>
  </section>
  
  
  <section id="section21">
      <div class="d-flex flex-row justify-content-center">
   <h4 class="our-branches-button-container mb-3 mt-standard">
    Our Branches
   </h4>
  </div>
  <section class="branches-section">
   <div class="owl-carousel owl-theme singleItemSlider" id="owl-carousel08">
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-pitampura.webp" alt="Best English Speaking Institute in North Delhi" title="Oxford English Pitampura" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
         Pitampura Branch
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         365 Kohat Enclave, Near Kohat Metro Station Gate No. 3, North Delhi -110034 
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9540127373
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 -45680574
         </p>
        </div>
        <button class="view-more-btn01">
         <a target="_blank" href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6981337,77.1372723,17z/data=!3m1!4b1!4m5!3m4!1s0x390d03da0abc6ac3:0xe4642d10ca8d8fbf!8m2!3d28.698129!4d77.139461?shorturl=1">
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-laxmi-nagar.webp" alt="Best English Speaking Institute in East Delhi" title="Oxford English Laxmi Nagar" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
         Laxmi Nagar
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         E 354, Nirman Vihar, Near Nirman Vihar Metro Station, East Delhi-110092 
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9540127878
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 - 41255104
         </p>
        </div>
        <button class="view-more-btn01">
         <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6372579,77.2865177,17z/data=!4m5!3m4!1s0x390cfb56b6843fff:0xbd5d17737bc80438!8m2!3d28.6372532!4d77.2887064?shorturl=1" target="_blank">
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-south-extension.webp" alt="Best English Speaking Institute in South Delhi" title="Oxford English South Extension" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
         South Extension
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         E 10, Part-I, Near South Extension Metro Station, South Delhi -110049. 
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9810735296
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 -41255102
         </p>
        </div>
        <button class="view-more-btn01">
         <a target="_blank" href="https://www.google.com/maps/place/Oxford+Software+Institute+South+Extention/@28.5706783,77.219955,17z/data=!3m1!4b1!4m6!3m5!1s0x390ce25d0ac35f11:0x3125b97033cf142f!8m2!3d28.5706783!4d77.219955!16s%2Fg%2F1th0wr3f?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D">
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-rajouri-garden.webp" alt="Best English Speaking Institute in West Delhi" title="Oxford English Rajouri Garden" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
        Rajouri Garden 
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         A 4, Vishal Enclave, opposite Metro Pillar No. 411, West Delhi -110027
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9319608182
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 -41255104
         </p>
        </div>
        <button class="view-more-btn01">
         <a href="https://www.google.com/maps/place/Oxford+Software+Institute+Rajouri+Garden/@28.6880275,77.1244528,12z/data=!4m6!3m5!1s0x390d0372a62dafe3:0x5e55587ff09b2755!8m2!3d28.6478906!4d77.1190374!16s%2Fg%2F11bxc5l07v?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
         
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>

  </section>
  
<section id="section30" >
   <div class="new-coaching-container classroom-section pt-standard mt-standard mt-3">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-lg-5 mb-3 d-flex flex-column justify-content-center heading-img-section">
          <img src="./assets/30-class/oxford-classrooms.webp" alt="Students engaged in interactive classroom activities">
       <!--<h4 class="text-center online-coaching-button">-->
       <!-- See Our Classroom <br /> in Action-->
       <!--</h4>-->
      </div>
      <div class="col-12 col-lg-7 mb-3">
       <div class="owl-carousel owl-theme" id="owl-carousel06">
            <!--item 1 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/girls-in-festive-mood.webp" alt="Students celebrate in ethnic wear, enjoying festive learning moments" title="">
              <div class="">
               <p class="online-text"> Group of spoken English female students striking poses in colorful ethnic attire, smiling and celebrating cultural diversity </p>
              </div>
             </div>
            </div>
            <!--item 1 end-->
            
            <!--item 2 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/boys-after-festivel-celebration.webp" alt="English course students posing in colorful ethnic attire, smiling together and celebrating culture" title="">
              <div class="">
               <p class="online-text"> Indian students proudly showcase their cultural heritage in vibrant ethnic attire, celebrating tradition with smiles and unity. </p>
              </div>
             </div>
            </div>
            <!--item 2 end-->
            
            <!--item 3 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/mock-interview-ready.webp" alt="Students prepare confidently for a mock interview to improve spoken english" title="">
              <div class="">
               <p class="online-text">Students dressed in formals gear up for a mock interview, enhancing their confidence and communication skills</p>
              </div>
             </div>
            </div>
            <!--item 3 end-->
            
            <!--item 4 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/cosplay-in-class.webp" alt="Spoken english students striking poses post-performance in a costume play party" title="">
              <div class="">
               <p class="online-text">Excited students showcase their creative costumes, capturing joyful memories after a fantastic costume play party.</p>
              </div>
             </div>
            </div>
            <!--item 4 end-->
            
            <!--item 5 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-classroom.webp" alt="Students pose happily for a group photo after their english class" title="">
              <div class="">
               <p class="online-text">Enthusiastic students showcase their confidence and teamwork after completing a spoken English session.</p>
              </div>
             </div>
            </div>
            <!--item 5 end-->
            
            <!--item 6 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-class-selfie.webp" alt="Students and trainer smile together for a cheerful classroom selfie." title="">
              <div class="">
               <p class="online-text">Happy students and their trainer capture a fun classroom moment, celebrating progress in spoken English.</p>
              </div>
             </div>
            </div>
            <!--item 6 end-->
            
            <!--item 7 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-qa-session.webp" alt="Student leads a q&a session while classmates participate with questions" title="">
              <div class="">
               <p class="online-text">Students engage in an interactive Q&amp;A session, building confidence and communication skills in spoken English.</p>
              </div>
             </div>
            </div>
            <!--item 7 end-->
            
            <!--item 8 end-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-roleplay-fun.webp" alt="Students perform a fun english roleplay as classmates and trainer watch" title="">
              <div class="">
               <p class="online-text">Students bring learning to life with an engaging roleplay, making English practice fun and interactive.</p>
              </div>
             </div>
            </div>
            <!--item 8 end-->
            
            <!--item 9 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-students-celebrations.webp" alt="Students cheer together for a fun group photo after class" title="">
              <div class="">
               <p class="online-text">Excited students come together, celebrating their spoken English journey with energy and enthusiasm.</p>
              </div>
             </div>
            </div>
            <!--item 9 end-->
            
            <!--item 10 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/extra-activity-class.webp" alt="Students perform a hygiene skit to promote good habits and cleanliness" title="">
              <div class="">
               <p class="online-text">Students creatively present a skit emphasizing hygiene, promoting awareness through engaging performances.</p>
              </div>
             </div>
            </div>
            <!--item 10 end-->
            
            <!--item 11 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/formal-english-success.webp" alt="Students in formal wear pose confidently after completing their session" title="">
              <div class="">
               <p class="online-text">Students dressed in formals proudly showcase their confidence and enthusiasm after a spoken English class..</p>
              </div>
             </div>
            </div>
            <!--item 11 end-->
            
            <!--item 12 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/group-discussion.webp" alt="Spoken english students in a group discussion, sharing ideas to improve fluency." title="">
              <div class="">
               <p class="online-text">Students actively participate in a group discussion, enhancing their spoken English fluency and confidence.</p>
              </div>
             </div>
            </div>
            <!--item 12 end-->
            
            <!--item 13 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/mock-presentation-success.webp" alt="Students pose with trainers after a successful mock presentation" title="">
              <div class="">
               <p class="online-text">Confident students and trainers capture a proud moment after a successful mock presentation session.</p>
              </div>
             </div>
            </div>
            <!--item 13 end-->
            
            <!--item 14 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/senior-student-participant.webp" alt="A senior spoken English student reading aloud in class while holding a mic with confidence." title="">
              <div class="">
               <p class="online-text">Confidently reading aloud, a senior student practices spoken English skills in a formal classroom setting.</p>
              </div>
             </div>
            </div>
            <!--item 14 end-->
            
            <!--item 15 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/spoken-english-group.webp" alt="Students pose joyfully at the english center, celebrating their progress" title="">
              <div class="">
               <p class="online-text">Happy students come together for a memorable group photo, showcasing their progress in spoken English.</p>
              </div>
             </div>
            </div>
            <!--item 15 end-->
            
            <!--item 16 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/spoken-english-success.webp" alt="Students celebrate their progress joyfully after english class" title="">
              <div class="">
               <p class="online-text">Happy students express their excitement and achievement after an engaging spoken English session.</p>
              </div>
             </div>
            </div>
            <!--item 16 end-->
            
            <!--item 17 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-course-certification.webp" alt="Students proudly show certificates after completing their english course" title="">
              <div class="">
               <p class="online-text">Students showcase their hard-earned certifications, marking their success in spoken English learning.</p>
              </div>
             </div>
            </div>
            <!--item 17 end-->
            
            <!--item 18 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/class-room.webp" alt="Trainer teaches in a smart classroom while students listen attentively" title="">
              <div class="">
               <p class="online-text">Our dedicated English trainer guiding students through English lessons, making learning interactive and engaging.</p>
              </div>
             </div>
            </div>
            <!--item 18 end-->
            
            <!--item 19 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/section-30-classrooms/activity-based-learning-english-speaking-oxford.webp" alt="Students Learning Through Activity-based Methods" title="Deep Dive Lesson">
              <div class="">
               <p class="online-text">Students actively engage in classroom activities, enjoying the learning process through interactive, fun, and effective activity-based methods.</p>
              </div>
             </div>
            </div>
            <!--item 19 end-->
            
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  
  
  <section class="mt-standard new-english-section" id="section33">
   <!--<div class="d-lg-block d-none">-->
   <div class="">
    <div class="footer-before-container py-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-12">
        <h5 class="text-center"> Beyond Books and Classrooms </h5>
       </div>
      </div>
     </div>
    </div>
   </div>
    <div class="container">
        <div class="owl-carousel owl-theme threeItemSlider light-icons" id="owl-carousel08">
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Welcoming students for alumni meet at our english study center laxmi nagar" class="last-card-image" src="./assets/33-activities/alumni-welcome.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Alumni Welcome
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Diwali Celebration at our English speaking center pitampura" class="last-card-image" src="./assets/33-activities/diwali-celebrations.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Diwali Celebations 
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Talent show participants in full zeal at  english class" class="last-card-image" src="./assets/33-activities/talent-show.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Talent  Show Participants
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Fashion show preparations in full swing" class="last-card-image" src="./assets/33-activities/fashion-show-preparations.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Fashion Show Zeal
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Fashion show by english course students" class="last-card-image" src="./assets/33-activities/fashion-show.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Fashion Festivities Fun
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="English course students showing their acting prowess with macbeth" class="last-card-image" src="./assets/33-activities/scenes-from-macbeth.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Staging Shakespeare's Macbeth
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Face paint and loads of masti" class="last-card-image" src="./assets/33-activities/face-paint-masti.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Face Paint Activity 
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Students organized a blood donation camp with Lions Club to support the society" class="last-card-image" src="./assets/33-activities/blood-donation-camp.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Community Blood Donation 
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt=" Students staging scenes from ramayana " class="last-card-image" src="./assets/33-activities/ramleela-play.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Post Performance Masti
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="English speaking course students ready to give mock interviews" class="last-card-image" src="./assets/33-activities/mock-interviews.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Mock Interviews
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Students enjoying after receving awards" class="last-card-image" src="./assets/33-activities/award-ceremony.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Award Distribution Ceremony
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Learning English by outdoor activity" class="last-card-image" src="./assets/33-activities/outdoor-fun-learning.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Outdoor Talk Show
                </h5>
               </div>
              </div>
            </div>
            
        </div>
       </div>
  </section>

    

<section section="38">
    <div class="call-section-container mt-standard py-standard">
        <div class="">
         <div class="row m-0 align-items-center justify-content-center">
            <div class="col-lg-6 text-right">
                <h5> Frequently Asked Questions </h5>
            </div>
          <div class="col-lg-6">
              <a href="pte-exam-faqs.php" class=" justify-content-center"> 
                  <img src="./assets/icons/magnify.webp" alt="email" style="margin-right: 5px;">
                  Know More </a>
                </div>
         </div>
        </div>
       </div>
</section>

      <section id="section35" class="mt-standard">
    <!-- Adib 2 -->
    <div class="bg-overlay">
      <div class="container p-0">
        <div class="bg-banner banner2 m-0 row align-items-center text-center text-xl-left text-xl-start ">
          <!-- Text Section -->
          <div class="col-xl-6 mb-md-0 pl-text pr-40">
            <h2>
              Best PTE
              <br>
              Coaching in Delhi
              <br>
              Since 1997
            </h2>
            <div class="direction grid grid-cols-4 grid-cols-2 mt-3">
              <a href="contact-us-pitampura.php">North Delhi</a> 
              <a href="contact-us-south-extension.php">South Delhi</a> 
              <a href="contact-us-laxmi-nagar.php">East Delhi</a> 
              <a href="contact-us-rajouri-garden.php">West Delhi</a> 
            </div>
          </div>

          <div class="col-xl-6 pl-40">
            <div class="enquiry">
    <h3>QUICK ENQUIRY</h3>
    <form method="post">
        <input type="text" name="studentName" required placeholder="Enter your Name">
        <input type="tel" name="mobile" maxlength="10" required placeholder="Enter your Number">
        <input type="text" name="course" placeholder="Course">
        <select name="centre" name="centre" required>
            <option value="Select a Center">Select a Center *</option>
            <option value="Center 1">Laxmi Nagar </option>
            <option value="Center 2">Pitampura </option>
            <option value="Center 2">Rajouri Garden </option>
            <option value="Center 2">South Extension </option>
        </select>
    
        <input class="d-none" type="hidden" name="form_submitted" value="1"> 
        <button class="btn-red" type="submit" name="submitQuick">Submit</button>
    </form>
        
</div>          </div>

           <div class="d-flex flex-row justify-content-center w-100 mt-4">
              <a href="./assets/oxford-english-brochure.pdf" target="_blank" class="download-brochure-button01 btn-brocher mt-3 mb-0 brochure-35" type="button">
                <img loading="lazy" width="30" height="30" src="./assets/icons/download.webp" alt="email" style="margin-right: 5px;">
                Download Brochure
              </a>
            </div>
        </div>
      </div>
    </div>
  </section>
  
  

    <link href="./css/bootstrap.css" rel="stylesheet"/>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/adib-css/adib-common.css">

<!--<h3 class="text-center">-->
<!--     Section 17-->
<!--  </h3>-->
  <section class="oxford-branches mt-standard" id="section17">
    <div class="d-flex flex-row justify-content-center">
    <h3 class="new-abc-button mb-0">
      Oxford School of English Branches
    </h3>
    </div>
       <!--english-speaking-classes-section Code Start-->
       <div class="new-branches-container pt-5 py-standard">
        <div class="container-fluid">
         <div class="grid grid-cols-3 grid-cols-2-17 g-gap card-scroll">
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Pitampura Branch </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  365 Kohat Enclave, Near Kohat Metro Station Gate No. 3, North Delhi -110034 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127373"> 9540127373</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:45680574"> 011 - 45680574</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-pitampura.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6981337,77.1372723,17z/data=!3m1!4b1!4m5!3m4!1s0x390d03da0abc6ac3:0xe4642d10ca8d8fbf!8m2!3d28.698129!4d77.139461?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Laxmi Nagar</h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  E 354, Nirman Vihar, Adjacent to Nirman Vihar Metro Station Gate Number 2, East Delhi -110092 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127878"> 9540127878</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 40159334</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-laxmi-nagar.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6372579,77.2865177,17z/data=!4m5!3m4!1s0x390cfb56b6843fff:0xbd5d17737bc80438!8m2!3d28.6372532!4d77.2887064?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> South Extension </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> E 10, Part-I, Near South Extension Metro Station, South Extension, South Delhi -110049 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9810735296"> 9810735296 </a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255102"> 011 - 41255102</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-south-extension.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute+South+Extention/@28.5706783,77.219955,17z/data=!3m1!4b1!4m6!3m5!1s0x390ce25d0ac35f11:0x3125b97033cf142f!8m2!3d28.5706783!4d77.219955!16s%2Fg%2F1th0wr3f?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Rajouri Garden </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> A 4, Vishal Enclave, opposite Metro Pillar No. 411, West Delhi -110027 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9319608182"> 9319608182</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 41255104 </a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-rajouri-garden.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute+Rajouri+Garden/@28.6880275,77.1244528,12z/data=!4m6!3m5!1s0x390d0372a62dafe3:0x5e55587ff09b2755!8m2!3d28.6478906!4d77.1190374!16s%2Fg%2F11bxc5l07v?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <!--english-speaking-classes-section Code End-->
  </section>
  
  
  <footer>
   <div class="">
    <div class="mobile-footer-container px-3 py-standard">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Quick Links
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="/">
           Home
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="about.php">
           About 
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-blogs.php">
           English Blogs
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="gallery-fun-learning.php">
           Gallery
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="hire-fresher.php">
           Placement Employer
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="job-for-freshers-in-delhi.php">
           Placement Student
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="contact-us.php">
           Contact Us
          </a>
         </li>
          <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms/inquiry.php">
           Enquiry Form
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms">
           LMS
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-course-faqs.php">
           English Course FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-exam-faqs.php">
           IELTS Exam FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-exam-faqs.php">
           PTE Exam FAQ
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="spoken-english-classes-near-me.php">
           English Classes Near Me
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Courses
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon01">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks01" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course.php">
           All Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course-for-beginners.php">
           Interchange Beginners Level-1
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="intermediate-level-english-speaking-course.php">
           Interchange Intermediate Level-2
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="advance-english-speaking-course.php">
           Interchange Advance Level-3
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-coaching-near-me.php">
           IELTS Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="basic-spoken-english-course.php">
           Basic Spoken English Course
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-english-speaking-course.php">
           Online English Classes
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-ielts-coaching.php">
           IELTS Online Coaching
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-coaching-near-me.php">
           PTE Course
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="pte-coaching-online.php">
           PTE Online Coaching
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         About 
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <p class="footer-about-us-description">
         Oxford School of English, with four branches since 1997, stands as Delhi’s leading English-speaking Institute and offers the best English-speaking course (also called English talking course by many) from basic to advanced levels. If you are searching for English-speaking classes near me, Oxford is the best choice, with branches in all directions of Delhi, having trained over one lakh students as an NSDC training partner.
        </p>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         Course Enquiry
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <form action="" method="post" name="frm">
            <!--<input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />-->
            <input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />
            <input class="footer-form-control" name="mobile" placeholder="Enter your Number" type="text" required />
            <input class="footer-form-control" name="course" placeholder="Course" type="text" required />
            <select class="footer-form-control" name="centre" required>
                <option value="" selected> Select Center</option>
                <option value="Pitampura"> Pitampura</option>
                <option value="Laxmi Nagar"> Laxmi Nagar</option>
                <option value="Rajouri Garden"> Rajouri Garden</option>
                <option value="South Extension"> South Extension</option>
            </select>
         <!--<input class="footer-form-control" placeholder="Enter Your Name" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Enter Your Number" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Select Center" type="text"/>-->
         <div class="d-flex flex-row justify-content-center">
          <button class="footer-form-submit-btn" type="submit" name="submitQuick">
           Submit
          </button>
         </div>
        </form>
       </div>
      </div>
     </div>
    </div>
    <div class="footer-border-bottom-line">
    </div>
    <div class="mobile-footer-container pt-4 pb-4 px-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Proud Associations
        </p>
        <div class="row">
         <div class="col-7 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/oxford-nsdc-partner.webp" alt="Oxford is a Proud Partner of NSDC" />
         </div>
         <div class="col-5 col-lg-2 mb-3">
          <img loading="lazy" class="partner-image" src="./assets/footer/skill-courses.webp" alt="We Offer Skill Courses for Better Employment" />
         </div>
         <div class="col-12 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/cambridge-partner.webp" alt="Oxford School of English Offers Cambridge University Press Courses" />
         </div>
        </div>
       </div>
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Connect with Us
        </p>
        <div class="d-flex flex-row justify-content-between justify-content-md-start">
         <a href="https://www.facebook.com/delhioxfordenglish">
          <img loading="lazy" alt="Facebook Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-facebook.webp"/>
         </a>
         <a href="#">
          <img loading="lazy" alt="x-icon" class="social-icon" src="./assets/footer/x-oxford-english.webp"/>
         </a>
         <a href="https://www.instagram.com/oxfordschoolofenglish.in">
          <img loading="lazy" alt="Instagram Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-instagram.webp"/>
         </a>
         <a href="https://www.youtube.com/channel/UC50IGGpwAuCGcVzP6Tx2TPg">
          <img loading="lazy" alt="YouTube Channel of Oxford School of India" class="social-icon" src="./assets/footer/oxford-english-youtube.webp"/>
         </a>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      English Speaking Institute Near You
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Kohat Enclave
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near nangloi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Paschim Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Shalimar Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Punjabi Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Rani Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rohini.php">
          English Speaking Course in Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Narela
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Bawana
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Uttam Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Shahdara
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Preet Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Nirman Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Krishna Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Geeta Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Patparganj
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Vaishali
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Kaushambi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in Kotla
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Defence Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Kalkaji
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Green Park
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Hauz Khas
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="spoken-english-classes-near-me.php">
          English Classes Near Me
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-classes-delhi.php">
          English Speaking Course in Delhi
         </a>
        </li>
       </ul>
      </div>
     </div>
    </div>
   </div>

   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      IELTS Coaching Institute Near You In Delhi
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-pitampura.php">
          IELTS Coaching in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rohini.php">
         IELTS Coaching near  Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching   in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching   in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching  near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>

     </div>
    </div>
   </div>

   <div class="copyright-container pt-4 pb-2">
    <div class="container-fluid">
     <h5 class="copyright-heading">
      Copyright &copy; 1997 - 2025 Hindustan Soft Education Limited, New Delhi || All the logos and images are the copyright of their respective owners
     </h5>
     <div class="d-flex flex-row justify-content-center">
      <p class="copyright-paragraph">
       *Privacy Policy : We do not distribute your email or contact information to other websites or sources and will be kept confidential. We do not accept or host any advertisement on this website. We do collect visitor data and asses the user traffic on our website and various pages which helps us to improvise. We do not collect any personal information on visitors. Any information which is considered to have ethnic or gender bias, derogatory or lewd will be removed by owner of this website at their discretion without any notice. By using our website, you agree to our privacy policy as mentioned above. Our privacy policy may get updated without any notice, hence users are suggested to review it before they plan to submit any personal information to our website.
      </p>
     </div>
    </div>
   </div>
  </footer>
  <div class="popup" id="videoPopup">
   <div class="popup-content">
    <span class="close-btn" onclick="hidePopup()">
     &times;
    </span>
    <video controls="" id="popupVideo">
     <source src="" type="video/mp4"/>
     Your browser does not support the video tag.
    </video>
   </div>
  </div>
  <div class="video-overlay" id="videoOverlay">
   <div class="video-container">
    <div class="embed-responsive embed-responsive-16by9">
     <iframe allowfullscreen="" class="embed-responsive-item" id="videoIframe" src="">
     </iframe>
    </div>
    <span class="close-btn01" id="closeBtn01">
     <img loading="lazy" src="./assets/icons/cross.webp" width="40" height="40" alt="cross">
    </span>
   </div>
  </div>
  <!-- <script src="banners/js/aos.js"></script> -->
  <script>
  
  </script>
  <script src="js/common.js" defer></script>

  <script src="js/custom-carousel.js" defer></script> 

  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" defer ></script>

  <script  src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" defer ></script>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" defer></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"  defer></script>

  <script src="./js/adib-script.js" defer></script>

  <!-- Ashutosh's code start - 16-04-2025
     Code to reload images that did not load the first time -->

  <script>
//     $(document).ready(function() {
//       $('img').each(function () {
//         if (!this.complete || typeof this.naturalWidth === "undefined" || this.naturalWidth === 0) {
//           var src = $(this).attr('src');
//           $(this).attr('src', src); // Force reload
//         }
//       });
//     });
 </script>
  <!-- Ashutosh's code end -->
  <!--banner script-->
  
 </body>
</html>