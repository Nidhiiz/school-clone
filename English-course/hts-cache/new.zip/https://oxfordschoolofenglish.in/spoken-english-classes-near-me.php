<!DOCTYPE html>
<html lang="en">
<head>
    <title>English Speaking Course Near Me | 4 Branches | Since 1997</title>
    <meta name="description" content="Join Oxford School of English for expert-led classes! Over 1 lakh students trained with Cambridge University Press English-speaking courses.">
    <meta name="keywords" content="english speaking classes near me, english speaking course near me, english classes near by me, english spoken classes near me, english speaking course near me with fees, english coaching near me, spoken english classes near to me, english speaking institute near me, best english speaking institute near me, near english speaking course, near by english speaking course, english coaching centre near me, best english speaking course near me, offline english speaking course near me, best spoken english classes near me, british english speaking course near me, spoken english institute near mea">
    
    <meta property="og:title" content="Best English Speaking Course Near you – Trusted by 1 Lakh+ Students" />
    <meta property="og:description" content="Join Oxford’s expert-led English classes with 28+ years of experience. Boost fluency, grammar, and confidence in 1–9 month courses." />
    <meta property="og:image" content="https://oxfordschoolofenglish.in/og/english-course.jpg" />
    <meta property="og:url" content="https://oxfordschoolofenglish.in/spoken-english-classes-near-me.php"/>
    <meta property="og:type" content="website" />

    
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"/>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

<link href="css/style.css" rel="stylesheet" />

<link href="css/css190425/header.css" rel="stylesheet"/>
<link href="css/css190425/common.css" rel="stylesheet"/>
<link href="css/css190425/default-banner.css" rel="stylesheet"/>

<link href="css/combined-global.css" rel="stylesheet" />

<link href="css/adib-css/adib4.css" rel="stylesheet"/>
<link href="css/adib-css/adib5.css" rel="stylesheet"/>
<link href="css/adib-css/adib6.css" rel="stylesheet"/>
<link href="css/adib-css/adib9.css" rel="stylesheet"/>
<link href="css/adib-css/adib10.css" rel="stylesheet"/>
<link href="css/adib-css/adib11.css" rel="stylesheet"/>
<link href="css/css190425/section41.css" rel="stylesheet"/>

 <link href="./banners/css/home-banner03.css" rel="stylesheet" />
<link href="css/css190425/footer.css" rel="stylesheet"/>


<link href="css/floating-buttons.css" rel="stylesheet"/>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"/>

   <link rel="stylesheet" type="text/css"
  href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"  rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  rel="stylesheet"/>

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '489625390408393');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=489625390408393&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->


<!-- Fallback Open Graph (OG) Tags -->
<meta property="og:title" content="Oxford School of English – Best English Speaking Courses in Delhi" />
<meta property="og:description" content="Join Oxford School of English. English Speaking Courses in Pitampura, Rajouri Garden, South Extension and Laxmi Nagar since 1997." />
<meta property="og:image"content="https://www.oxfordschoolofenglish.in/images/og/english-course.jpg" />
<meta property="og:url" content="https://www.oxfordschoolofenglish.in/" />
<meta property="og:type" content="website" />


<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="/oxford-school-of-english-icon.png">
<link rel="apple-touch-icon" href="/oxford-english-apple-icon.png">

<!-- Google tag (gtag.js) for GA4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6VXK325WCQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-6VXK325WCQ');
</script>

    <link rel="stylesheet" href="./banners/css/banner12.css">
    <link rel="canonical" href="https://oxfordschoolofenglish.in/spoken-english-classes-near-me.php" />
    <!--schema start-->

    <!-- LocalBusiness Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Oxford School of English - Near You",
      "image": "https://oxfordschoolofenglish.in/images/banner/english-speaking-course-near-me.webp",
      "url": "https://oxfordschoolofenglish.in/spoken-english-classes-near-me.php",
      "logo": "https://oxfordschoolofenglish.in/images/logo.webp",
      "description": "Join Oxford School of English near you – a trusted institute with 4 Delhi branches. Learn grammar, fluency & personality development.",
      "telephone": "+91-9540127878",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Multiple Centers Across Delhi",
        "addressLocality": "Delhi",
        "addressRegion": "Delhi",
        "postalCode": "110000",
        "addressCountry": "IN"
      },
      "contactPoint": [
        {
          "@type": "ContactPoint",
          "telephone": "+91-9540127373",
          "contactType": "Customer Service",
          "areaServed": "Pitampura, Delhi"
        },
        {
          "@type": "ContactPoint",
          "telephone": "+91-9540127878",
          "contactType": "Customer Service",
          "areaServed": "Laxmi Nagar, Delhi"
        },
        {
          "@type": "ContactPoint",
          "telephone": "+91-9319608182",
          "contactType": "Customer Service",
          "areaServed": "Rajouri Garden, Delhi"
        },
        {
          "@type": "ContactPoint",
          "telephone": "+91-9810735296",
          "contactType": "Customer Service",
          "areaServed": "South Extension, Delhi"
        }
      ],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.6",
        "reviewCount": "1500"
      },
      "priceRange": "₹₹"
    }
    </script>

    <!-- Course Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Course",
      "name": "English Speaking Course Near Me",
      "description": "Practical spoken English course at Oxford centres in Delhi. Includes grammar, fluency, personality & public speaking.",
      "provider": {
        "@type": "LocalBusiness",
        "name": "Oxford School of English",
        "sameAs": "https://oxfordschoolofenglish.in"
      },
      "hasCourseInstance": {
        "@type": "CourseInstance",
        "courseMode": "Offline",
        "startDate": "2025-06-10",
        "endDate": "2025-09-10",
        "location": {
          "@type": "Place",
          "name": "Oxford School of English - Any Delhi Branch",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Delhi",
            "addressCountry": "IN"
          }
        },
        "offers": {
          "@type": "Offer",
          "url": "https://oxfordschoolofenglish.in/spoken-english-classes-near-me.php",
          "priceCurrency": "INR",
          "price": "7500",
          "availability": "https://schema.org/InStock",
          "validFrom": "2025-05-31"
        }
      }
    }
    </script>

    <!--schema end-->

</head>
<body>
    

<header>
   <!--Desktop Navbar Header Code Start-->
   <div class="d-lg-block d-none">
    <div class="desktop-navbar">
     <nav class="navbar navbar-expand-lg navbar-light fixed-top">
         <a href="/">
            <img loading="lazy" class="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp" alt="oxford school of english delhi logo"/>
         </a>
      <button aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbar" data-toggle="collapse" type="button">
       <span class="navbar-toggler-icon">
       </span>
      </button>
      <div class="collapse navbar-collapse" id="navbar">
       <ul class="navbar-nav m-auto">
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Home
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="index.php">
           Home
          </a>
          <a class="dropdown-item" href="about.php">
           About
          </a>
          <a class="dropdown-item" href="gallery-fun-learning.php">
           Gallery
          </a>
          <a class="dropdown-item" href="english-blogs.php">
          English Blogs
          </a>
          <a class="dropdown-item" target="_blank" href="lms">
           LMS
          </a>
          <a class="dropdown-item" href="franchise-opportunity.php">
           Franchise
          </a>
         </div>
        </li>
        <li class="nav-item dropdown megamenu-li large-li">
         <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
          Courses
         </a>
         <div aria-labelledby="dropdown01" class="dropdown-menu megamenu">
          <div class="row">
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course.php">
             All Courses
            </a>
            <a class="dropdown-item" href="advance-english-speaking-course.php">
             Interchange  Advance Level-3
            </a>
            <a class="dropdown-item" href="online-english-speaking-course.php">
             Online English Classes
            </a>
            <a class="dropdown-item" href="pte-coaching-online.php">
             PTE Online Coaching
            </a>
            <a class="dropdown-item" href="personalised-english-classes.php">
             Personalised Classes
            </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course-for-beginners.php">
             Interchange  Beginners 
            </a>
            <a class="dropdown-item" href="ielts-coaching-near-me.php">
             IELTS Course
            </a>
            <a class="dropdown-item" href="online-ielts-coaching.php">
             IELTS Online Coaching
            </a>
            <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">
             IELTS and English
            </a>
            <a class="dropdown-item" href="personality-development-course.php"> Personality Development </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">
             Interchange  Intermediate Level-2
            </a>
            <a class="dropdown-item" href="basic-spoken-english-course.php">
             Basic Spoken English Course
            </a>
            <a class="dropdown-item" href="pte-coaching-near-me.php">
             PTE Course
            </a>
            <a class="dropdown-item" href="english-and-pte-coaching-classes.php"> PTE and English </a>
            <a class="dropdown-item" href="competitive-exam-english-classes.php"> Competitive Exams </a>
           </div>
          </div>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Placement
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="hire-fresher.php">
           Employer
          </a>
          <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
           Student
          </a>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Contact
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="contact-us.php"> All Centers </a>
          <a class="dropdown-item" href="contact-us-pitampura.php"> Pitampura </a>
          <a class="dropdown-item" href="contact-us-laxmi-nagar.php"> Laxmi Nagar </a>
          <a class="dropdown-item" href="contact-us-rajouri-garden.php"> Rajouri Garden </a>
          <a class="dropdown-item" href="contact-us-south-extension.php"> South Extension </a>
         </div>
        </li>
       </ul>
      </div>
      <div class="d-flex flex-row justify-content-end">
       <button class="pay-online-button"> <a href="https://rzp.io/l/OSEDELHI" target="_blank"> Pay Online </a> </button>
       
       <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      
      </div>
     </nav>
    </div>
    <div class="top-navbar d-lg-block d-none">
     <div class="container-fluid">
      <div class="d-flex flex-row justify-content-between">
       <button class="btn-year" type="btn">
        Since 1997 | 4 Branches
       </button>
       <div class="d-flex flex-row justify-content-center">
        <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           LEARN
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SPEAK
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SUCCEED
          </p>
         </div>
        </div>
       </div>
       <button class="btn-year" type="btn">
        One Lakh Students Trained
       </button>
      </div>
     </div>
    </div>
   </div>
   <!--Desktop Navbar Header Code End-->
   <!--Mobile Navbar Header Code Start-->
   <div class="d-block d-lg-none">
    <div class="top-navbar">
     <div class="d-flex flex-row justify-content-center">
      <div class="d-flex flex-row m-auto">
          <a href="index.php">
              <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
          </a>

       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          LEARN
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SPEAK
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SUCCEED
         </p>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div class="mobile-navbar">
     <div class="d-flex flex-row justify-content-between">
      <!--<button class="call-us-button" type="btn">-->
      <!-- <i class="fa fa-solid fa-phone mr-1">-->
      <!-- </i>-->
      <!-- Call Us-->
      <!--</button>-->
      <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      <a href="index.php">
          <img loading="lazy" alt="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp"/>
      </a>
      <button class="call-us-button" type="button" onclick="openSidebar()">
       Menu
       <i class="fa fa-solid fa-bars ml-1" >
       </i>
      </button>
      <div id="backdrop-sidebar"></div>
      <div class="sidebar" id="sidebar">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="navbar-collapse collapse show" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="menu-nav">
                    <a  class="nav-link mobile-navlink01">
                        MENU
                    </a>
                    <i class="fa fa-solid fa-circle-xmark close-icon" onclick="closeSidebar()">
                    </i>
            </li>
          <li class="nav-item dropdown">
            <a  class="nav-link mobile-navlink01" href="index.php">
             HOME
            </a>
           </li>
            <li>
                <a class="nav-link mobile-navlink01" href="about.php">
                    About 
                </a>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                English Courses
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="english-speaking-course.php">All English Courses</a>
                        <a class="dropdown-item" href="basic-spoken-english-course.php">Basic English Course</a>
                        <a class="dropdown-item" href="english-speaking-course-for-beginners.php">English Speaking Course for <br> Beginners - Level 1</a>
                        <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">Intermediate English Course - Level 2</a>
                        <a class="dropdown-item" href="advance-english-speaking-course.php">Advanced English Course - Level 3</a>
                        <a class="dropdown-item" href="online-english-speaking-course.php">Online English Speaking Course </a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                IELTS
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="ielts-coaching-near-me.php">IELTS Coaching</a>
                        <a class="dropdown-item" href="online-ielts-coaching.php">IELTS Online One-on-One</a>
                        <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">IELTS & English Course</a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PTE
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="pte-coaching-near-me.php">PTE Coaching</a>
                        <a class="dropdown-item" href="english-and-pte-coaching-classes.php">PTE & English Course</a>
                        <a class="dropdown-item" href="pte-coaching-online.php">PTE Online One-on-One</a>
                </div>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personality-development-course.php">
                    Personality Development
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="competitive-exam-english-classes.php">
                    Competitive Exam Classes
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personalised-english-classes.php">
                    Personalised English Classes
                </a>
            </li>
            <li class="nav-item dropdown megamenu-li">
                <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
                    CONTACT US
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="contact-us.php">
                    All Centers
                    </a>
                    <a class="dropdown-item" href="contact-us-south-extension.php">
                    South Extension
                    </a>
                    <a class="dropdown-item" href="contact-us-rajouri-garden.php">
                    Rajouri Garden
                    </a>
                    <a class="dropdown-item" href="contact-us-pitampura.php">
                    Pitampura
                    </a>
                    <a class="dropdown-item" href="contact-us-laxmi-nagar.php">
                    Laxmi Nagar
                    </a>
                </div>
            </li>
            <li>
                <a class="nav-link mobile-navlink01" href="gallery-fun-learning.php">
                    Gallery
                </a>
            </li>
              <li>
                <a class="nav-link mobile-navlink01" href="english-blogs.php">
                    English Blogs
                </a>
            </li>
            <li class="nav-item dropdown">
            <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PLACEMENT
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="hire-fresher.php">
                Employer
                </a>
                <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
                Student
                </a>
            </div>
            </li>
         </ul>
        </div>
       </nav>
      </div>
     </div>
    </div>

    <div class="top-navbar d-lg-none d-block">
      <div class="d-flex flex-row justify-content-center">
        <button class="navbar-button">Since 1997 | 4 Branches | One Lakh Students Trained</button>
      </div>
    </div>
   </div>
   <!--Mobile Navbar Header Code End-->
  </header>
  
  
<!--floating buttons start-->

    <a class="fa-brands fa-whatsapp fa-beat fa-xl m-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"></a>
    <div class="w-numbers m-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
            
    <a class="fa-brands fa-whatsapp fa-beat fa-xl d-flex d-md-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"> <span> Whatsapp</span></a>

    <div class="w-numbers web-d-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
      
    <a class="floatingss fa fa-phone-volume fa-beat d-md-block d-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
      
    <a class="floatingss fa fa-phone-volume fa-beat d-flex d-md-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"><span> Phone</span></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
<!--floating buttons end-->    
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">English Speaking Institute Near You</li>
        <li class="breadcrumb-item active" aria-current="page">English Classes Near Me</li>
      </ol>
    </nav>
    

    <section id="course-banner12">
  <div class="cousre-banner12">
    <div class="container-fluid">
      <div class="row m-0">
        <div class="col-12 col-lg-7 mb-3 d-flex flex-column justify-content-center order-2 order-lg-1" >
          <div class="course-banner12-text-box">
            <h1 class="course-banner12-heading" > <span class="gray-color-span">English</span> Speaking <br> Course <span class="gray-color-span">Near Me</span> </h1>
            
            <div class="d-flex flex-row justify-content-center">
              <img src="./banners/banner-images/courses/Desktop-Webp/english-speaking-course-near-me.webp" class="img-fluid course-banner12-image d-lg-none d-block" alt="searching English Speaking Course Near Me, oxford is the best institute" title="English Classes Near Me"  >
            </div>

            <div class="d-lg-block d-none">
              
                <div class="banner12-since-1997-container d-flex flex-column justify-content-center">
                  <h6 class="since-1997-heading">Since 1997</h6>
              </div>
  
              
                <div class="banner12-since-1997-container01 d-flex flex-column justify-content-center">
                  <h6 class="since-1997-heading">4 Branches</h6>
                </div>
              
                <div class="banner12-since-1997-container02 d-flex flex-column justify-content-center">
                  <h6 class="since-1997-heading">One Lakh Students Trained</h6>
              </div>
            </div>


            <div class="d-block d-lg-none">
             <div class="mobiie-text-box">
              <div class="row">
                <div class="col-6">
                  <div class="banner12-since-1997-container d-flex flex-column justify-content-center">
                    <h6 class="since-1997-heading">Since 1997</h6>
                  </div>
                </div>
                <div class="col-6">
                  <div class="banner12-since-1997-container d-flex flex-column justify-content-center">
                    <h6 class="since-1997-heading">4 Branches</h6>
                  </div>
                </div>

                <div class="col-12">
                  <div class="banner12-since-1997-container d-flex flex-column justify-content-center">
                    <h6 class="since-1997-heading">One Lakh Students Trained</h6>
                  </div>
                </div>
              </div>
             </div>
            </div>
          </div>
          
        </div>

        <div class="col-12 col-lg-5 order-1 order-lg-2 flex-column justify-content-center d-none d-lg-flex">
          <div class="d-flex flex-row justify-content-center">
            <img src="./banners/banner-images/courses/Desktop-Webp/english-speaking-course-near-me.webp" class="img-fluid course-banner12-image" alt="searching English Speaking Course Near Me, oxford is the best institute" title="English Classes Near Me" >
          </div>
        </div>
      </div>
    </div>
  </div>
</section>





    <section id="section1">
   <!--Google Review Container Section Code Start-->
   <div class="google-review-container mt-standard">
    <div class="container-fluid">
     <div class="d-flex flex-row justify-content-center">
      <h2 class="h4">
       Best
       <span class="span03">
        English Conversation
       </span>
        Classes near me
      </h2>
     </div>
     <div class="d-flex flex-row justify-content-center">
      <div class="google-rating-container py-standard">
       <div class="container">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <img src="./assets/more-images/1-google-rating.webp" alt="Google rating of Oxford School of English">
         <h3>
          4.3
         </h3>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Google Review Container Section Code End-->
  </section>
  
      <section id="section53a" class="my-standard">
      <div class="speed-bg red">
        <div class="container">
          <h3 class="sTitle">English Speaking Course Fees</h3>
          <div class="grid grid-cols-3">
            <div class="discount-card green">
                <h3 class="discount-title white">Fees & Duration</h3>
                <div class="discount-details">
                    <p>Fees: Rs. 7500 <br> Duration: 3 Months</p>
                </div>
            </div>
             <div class="discount-card green">
                <h3 class="discount-title white">Early Bird Discount</h3>
                <div class="discount-details">
                    <p>Grab Early Bird  Offer <br> Few Seats left</p>
                </div>
            </div>
             <div class="discount-card green">
                <h3 class="discount-title white">Fresh Batches Starting</h3>
                <div class="discount-details">
                    <div class="enroll-today">
                        <p>Enroll today</p>
                        <div class="enroll-call">
                            
                            <p>For Confidence Ahead</p>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  <section id="section9">
   <!--Online english classes Section Start-->
   <div class="">
    <div class="new-english-container mt-standard">
     <div class="row m-0">
     <div class="col-12 col-lg-6 d-flex align-items-center pl-0 relative">
          <div class="bg-Image">
              <img class="" src="./assets/areawise-english/rajouri-english/9-best-english-classes.webp" alt="Best English-Speaking Course Near Me – Enroll Today">
          </div>
      </div>
      <div class="col-12 col-lg-6 mt-3 d-flex flex-column justify-content-center">
       <h3 class="new-courses-button mb-sm-0 px-2">
        Join the Best English-Speaking Classes Near You in Delhi
       </h3>
       <div class="new-courses-inner">
        <p class="new-courses-paragraph">
         Looking for English-speaking classes near you in Delhi or searching for the best English course near me? Oxford School of English is your perfect choice. We have four branches across Delhi—East, West, South, and North—all conveniently located near metro stations, making them easy to reach and trusted by thousands of learners.
</p>
        <span class="span05 xs-hidden" id="hidden-content">
         <p class="new-courses-paragraph">
            <b>Courses Designed for All Levels of Learners</b><br>
         Our English-speaking courses cater to beginners, intermediate, and advanced learners. Whether starting from scratch or wanting to polish your communication, our programs range from 1 to 9 months and cover grammar, vocabulary, conversation, and public speaking skills.
         </p>
         <p class="new-courses-paragraph">
             <b>Build Fluency, Confidence, and Career Skills</b><br>
          At Oxford, we go beyond grammar and vocabulary. Our training boosts your fluency, pronunciation, and confidence through real-life speaking practice and role-play. Join today to improve communication and open doors to better academic, career, and social opportunities.
         </p>
        </span>
        <div class="md-hidden text-right">
         <button class="read-more-btn" id="read-more-btn" type="btn">
          Read More
         </button>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   
   <!--Online english classes Section End-->
  </section>


  <section class="section-14" id="section14">
   <!--students-testimonial-container section Code Start-->
   <div class="students-testimonial-container mt-standard">
    <div class="container-fluid">
     <!--<h6>-->
     <!-- Listen From Our Proud Students-->
     <!--</h6>-->
     <div class="footer-before-container py-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-12">
        <h5 class="text-center"> Listen From Our Proud Students</h5>
       </div>
      </div>
     </div>
    </div>
    
     <!--<h4 class="new-courses-button"> Listen From Our Proud Students </h4>-->
    </div>
    <div class="container-fluid01">
     <div class="owl-carousel owl-theme" id="owl-carousel02">
         
      <!-- item 1 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="expressing satisfaction with spoken English training" class="testimonial-image" src="./assets/section-14-text-review/harsha-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Harsha </p>
         <p class="review-description">
          I really enjoy coming to Oxford because of my teacher, Amanpreet Ma&acirc;&#128;&#153;am, and her amazing teaching. The classroom atmosphere is very good and full of learning.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 1 end -->
      
      <!-- item 2 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Student review of the english-speaking course at oxford school of english in delhi, sharing a." class="testimonial-image" src="./assets/section-14-text-review/abhijai-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Abhijai </p>
         <p class="review-description">
          It has been an amazing journey till now. I have learned many new things, and I am still enjoying the experience of learning something new.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 2 end -->
      
      <!-- item 3 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Paridhi appreciates interactive activities and caring teachers at oxford." class="testimonial-image" src="./assets/section-14-text-review/paridhi-aggarwal.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Paridhi Aggarwal </p>
         <p class="review-description">
            Oxford is the best place to learn English. Activities like role plays, debates, and extempore are helpful. The study material and LMS are great. My faculty is very supportive. Highly recommended!
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 3 end -->
      
      <!-- item 4 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Recommending Oxford after a great learning experience" class="testimonial-image" src="./assets/section-14-text-review/simarjeet-kaur.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Simarjeet Kaur </p>
         <p class="review-description">
            The faculty is very helpful, and activity classes improve our confidence and fluency. I joined at level 2 and am now pursuing level 3 to enhance my skills.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 4 end -->
      
      <!-- item 5 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Shalu highlights useful study material and interactive sessions at oxford." class="testimonial-image" src="./assets/section-14-text-review/shalu-sharma.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Shalu Sharma </p>
         <p class="review-description">
            I&acirc;&#128;&#153;m pursuing Level 2 at Oxford. The faculty is approachable, and activities like GDs, role plays, and discussions are very engaging. Highly recommend for improving English skills!
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 5 end -->
      
      <!-- item 6 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Rashi praises the supportive teachers and engaging classroom methods." class="testimonial-image" src="./assets/section-14-text-review/rashi-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Rashi </p>
         <p class="review-description">
            I love the institute&acirc;&#128;&#153;s environment and activities. Ruby Ma&acirc;&#128;&#153;am&acirc;&#128;&#153;s polite behavior and clear explanations made learning enjoyable. This has been my best learning experience. Thank you, Oxford!
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 6 end -->
      
      <!-- item 7 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Aakash praises oxford for its expert training and great learning experience." class="testimonial-image" src="./assets/section-14-text-review/aakash-patel.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Aakash Patel </p>
         <p class="review-description">
            There is a great mentor and helpful facilities that support students in their careers. This is really good for every learner. My overall experience is good.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 7 end -->
      
      <!-- item 8 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Giving feedback after course completion" class="testimonial-image" src="./assets/section-14-text-review/shweta-kumari.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Shweta Kumari </p>
         <p class="review-description">
            She has taught us many valuable lessons and motivated us to become the best speakers of the language. Her guidance has truly helped us improve.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 8 end -->
      
      <!-- item 9 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Dilshad thanks oxford for improving speaking skills and confidence." class="testimonial-image" src="./assets/section-14-text-review/dilshad-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Dilshad </p>
         <p class="review-description">
            I joined Oxford to improve my English. My speaking, vocabulary, and grammar have improved. Activity classes and Amanpreet Ma&acirc;&#128;&#153;am&acirc;&#128;&#153;s simple teaching method helped me a lot.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 9 end -->
      
      <!-- item 10 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        1<img alt="Gaurav praises the course for improving his speaking and writing skills." class="testimonial-image" src="./assets/section-14-text-review/gaurav-chopra.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Gaurav Chopra </p>
         <p class="review-description">
            I joined Oxford to improve my spoken and written English. The result is clear now. The faculty is great, and I&acirc;&#128;&#153;m grateful to be part of this institute.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 10 end -->
      
      <!-- item 11 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Gulfam praises the teachers and learning environment at oxford." class="testimonial-image" src="./assets/section-14-text-review/gulfam-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Gulfam </p>
         <p class="review-description">
            Oxford is a great institute. I have learned many new things here. The teachers are very supportive, and the atmosphere is good. I really enjoy my time here.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 11 end -->
      
      <!-- item 12 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Shail praises ruby ma’am and the helpful learning experience at oxford." class="testimonial-image" src="./assets/section-14-text-review/shail-mishra.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Shail Mishra </p>
         <p class="review-description">
            It's been an amazing experience with Ruby Ma&acirc;&#128;&#153;am. Oxford is a great platform to learn English, and I highly recommend it.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 12 end -->
      
      <!-- item 13 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Ishaan shares a good learning experience at oxford near his location." class="testimonial-image" src="./assets/section-14-text-review/ishaan-review.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Ishan </p>
         <p class="review-description">
            My journey at Oxford has been amazing. I have learned many new things and gained valuable knowledge. It's been a great experience so far.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 13 end -->
      
      <!-- item 14 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Mukund highlights skill-building and positive learning at oxford." class="testimonial-image" src="./assets/section-14-text-review/mukund-bansal.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Mukund </p>
         <p class="review-description">
            The classes at Oxford are excellent. They help me gain skills, knowledge, and interact with new people. The institute's environment is friendly and peaceful.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 14 end -->
      
      <!-- item 14 start -->
      <div class="item">
       <div class="d-flex flex-row justify-content-center">
        <img alt="Sharing a positive review about English course" class="testimonial-image" src="./assets/section-14-text-review/utkarsh-rana.webp">
       </div>
       <div class="student-testimonial-container p-standard-inner">
        <div class="container-fluid">
         <i class="fa fa-solid fa-quote-left quotes">
         </i>
        </div>
        <div class="">
         <p class="name-heading"> Utkarsh Rana </p>
         <p class="review-description">
            My friend suggested joining Oxford to improve fluency and grammar. The fees are affordable, and the faculty is great. The study materials and vocabulary help a lot.
         </p>
         <div class="d-flex flex-row justify-content-end">
          <i class="fa fa-solid fa-quote-right quotes">
          </i>
         </div>
        </div>
       </div>
      </div>
      <!-- item 14 end -->

     </div>
    </div>
   </div>
   <!--students-testimonial-container section Code End-->
  </section>
  
  

  <section id="section21">
      <div class="d-flex flex-row justify-content-center">
   <h4 class="our-branches-button-container mb-3 mt-standard">
    Learn English Near you   
   </h4>
  </div>
  <section class="branches-section">
   <div class="owl-carousel owl-theme singleItemSlider" id="owl-carousel08">
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-pitampura.webp" alt="Best English Speaking Institute in North Delhi" title="Oxford English Pitampura" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
         Pitampura Branch
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         365 Kohat Enclave, Near Kohat Metro Station Gate No. 3, North Delhi -110034 
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9540127373
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 -45680574
         </p>
        </div>
        <button class="view-more-btn01">
         <a target="_blank" href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6981337,77.1372723,17z/data=!3m1!4b1!4m5!3m4!1s0x390d03da0abc6ac3:0xe4642d10ca8d8fbf!8m2!3d28.698129!4d77.139461?shorturl=1">
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-laxmi-nagar.webp" alt="Best English Speaking Institute in East Delhi" title="Oxford English Laxmi Nagar" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
         Laxmi Nagar
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         E 354, Nirman Vihar, Near Nirman Vihar Metro Station, East Delhi -110092 
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9540127878
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 - 41255104
         </p>
        </div>
        <button class="view-more-btn01">
         <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6372579,77.2865177,17z/data=!4m5!3m4!1s0x390cfb56b6843fff:0xbd5d17737bc80438!8m2!3d28.6372532!4d77.2887064?shorturl=1" target="_blank">
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-south-extension.webp" alt="Best English Speaking Institute in South Delhi" title="Oxford English South Extension" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
         South Extension
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         E 10, Part-I, Near South Extension Metro Station, South Delhi -110049. 
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9810735296
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 -41255102
         </p>
        </div>
        <button class="view-more-btn01">
         <a target="_blank" href="https://www.google.com/maps/place/Oxford+Software+Institute+South+Extention/@28.5706783,77.219955,17z/data=!3m1!4b1!4m6!3m5!1s0x390ce25d0ac35f11:0x3125b97033cf142f!8m2!3d28.5706783!4d77.219955!16s%2Fg%2F1th0wr3f?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D">
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
    <div class="container item">
     <div class="row flex-wrap">
      <img class="company-image" src="./assets/21-centre-images/oxford-school-of-english-rajouri-garden.webp" alt="Best English Speaking Institute in West Delhi" title="Oxford English Rajouri Garden" />
      <div class="d-flex flex-column justify-content-center">
       <div class="mobile-div">
        <h4 class="office-location-heading">
        Rajouri Garden 
        </h4>
        <div class="d-flex flex-row">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/map-icon-orange.webp"/>
         <p class="company-address">
         A 4, Vishal Enclave, opposite Metro Pillar No. 411, West Delhi -110027
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/phone-icon-orange.webp"/>
         <p class="company-address">
         9319608182
         </p>
        </div>
        <div class="d-flex flex-row mb-2">
         <img alt="orange-color-map" class="orange-color-map" src="./assets/icons/classic-telephone-icon.webp"/>
         <p class="company-address pt-1">
         011 -41255104
         </p>
        </div>
        <button class="view-more-btn01">
         <a href="https://www.google.com/maps/place/Oxford+Software+Institute+Rajouri+Garden/@28.6880275,77.1244528,12z/data=!4m6!3m5!1s0x390d0372a62dafe3:0x5e55587ff09b2755!8m2!3d28.6478906!4d77.1190374!16s%2Fg%2F11bxc5l07v?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
         
          View on Map
         </a>
        </button>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  </section>
  
  
  
  <section class="mt-standard new-english-section section-31" id="section31">
   <!--<div class="d-lg-block d-none">-->
   <div class="">
    <div class="footer-before-container py-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-6">
        <h5>
         English Speaking Courses
        </h5>
       </div>
       <div class="col-md-6 text-right">
        <h4> Courses - 1 to 9 Months </h4>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="container">
        <div class="owl-carousel owl-theme threeItemSlider light-icons" id="owl-carousel07">
         <!--item 1 start-->
         <div class="mb-3">
          <div class="final-card-container">
          <div class="image-container">
                <img alt="Top English Speaking Courses in Delhi for All Levels" title="Best English Courses in Delhi NCR" class="last-card-image" src="./assets/section-31/english-speaking-courses-delhi.webp">
            </div>
           <div class="p-standard-inner">
            <h5>
             All English Courses
            </h5>
            <div class="">
             <p>
             Explore our comprehensive English-speaking, IELTS, and PTE coaching programs to help you achieve learning, migration, or career goals.
             </p>
             
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1 to 9 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="english-speaking-course.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 1 end-->
         
         <!--item 2 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
               <img alt="Best Basic English Course in Delhi NCR" title="Top Basic English Speaking Institute in Delhi" class="last-card-image" src="./assets/section-31/basic-english-speaking-course.webp">
            </div>
          
           <div class="p-standard-inner">
            <h5>
             Basic Spoken English Course
            </h5>
            <div class="">
             <p>
             Designed for learners struggling with sentence formation and vocabulary, and prepares you for our English Speaking Course for Beginners.  
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1 Month   </button>
                <button class="know-more-btn01"> <a class="text-white" href="basic-spoken-english-course.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 2 end-->
         
         <!--item 3 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
           <img src="./assets/section-31/beginners-english-course-delhi.webp" alt="Top Beginners English Course in Delhi with Speaking Focus" title="Best English Speaking Classes for Beginners in Delhi" class="last-card-image">
            </div>
    
           <div class="p-standard-inner">
            <h5>
            English Speaking Course for Beginners 
            </h5>
            <div class="">
             <p>
             Helps learners with basic English improve fluency and confidence in social and professional conversations.  
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 3 Months - Level 1   </button>
                <button class="know-more-btn01"> <a class="text-white" href="english-speaking-course-for-beginners.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 3 end-->
         
         <!--item 4 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
            <img src="./assets/section-31/intermediate-english-course.webp" alt="Best Intermediate English Speaking Course in Delhi" title="Top Intermediate English Classes in Delhi" class="last-card-image">    
            </div>
           
           <div class="p-standard-inner">
            <h5>
            Intermediate English Course
            </h5>
            <div class="">
             <p>
             Ideal for learners looking to enhance their communication skills for professional growth, with a strong foundation in English basics and grammar.
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i>  3 Months - Level 2   </button>
                <button class="know-more-btn01"> <a class="text-white" href="intermediate-level-english-speaking-course.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 4 end-->
         
         <!--item 5 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
            <img src="./assets/section-31/advanced-english-course-delhi.webp" alt="Best Advanced English Course in Delhi for Professionals" title="Top Advanced English Speaking Institute in Delhi" class="last-card-image">
          </div>
           <div class="p-standard-inner">
            <h5>
            Advanced English-Speaking Course
            </h5>
            <div class="">
             <p>
             For professionals with good English skills aiming to work abroad or communicate with global clients&Acirc;&nbsp;confidently.
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 3 Months - Level 3   </button>
                <button class="know-more-btn01"> <a class="text-white" href="advance-english-speaking-course.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 5 end-->
         
         
         <!--item 6 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
                <img src="./assets/section-31/english-speaking-course-online.webp" alt="Top IELTS Coaching Institute in Delhi NCR" title="Best IELTS Training Centre in Delhi" class="last-card-image">
            </div>
           <div class="p-standard-inner">
            <h5>
            Spoken English Course Online
            </h5>
            <div class="">
             <p>
             We offer one-on-one and group online English classes tailored to your schedule and specific personal and professional growth needs.
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 2 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="online-english-speaking-course.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 6 end-->
         
         <!--item 7 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
           	<img src="./assets/section-31/ielts-coaching-delhi.webp" alt="Best PTE Coaching Centre in Delhi NCR" title="Top PTE Training Institute in Delhi" class="last-card-image">
            </div>
           <div class="p-standard-inner">
            <h5>
            IELTS Coaching  
            </h5>
            <div class="">
             <p>
             Prepares students to achieve required bands for overseas education, migration, or jobs with expert strategies and practice.  
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1.5 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="ielts-coaching-near-me.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 7 end-->
         
         <!--item 8 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
            <img alt="Top Personality Development and English Speaking Course" title="Best Personality Development Classes in Delhi" class="last-card-image" src="./assets/section-31/online-ielts-coaching.webp">
        </div>
          
           <div class="p-standard-inner">
            <h5>
            IELTS Online Course   
            </h5>
            <div class="">
             <p>
             Prepare for the IELTS exam at your preferred time and place, saving commuting time while ensuring effective learning from the comfort of your home. 
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1.5 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="online-ielts-coaching.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 8 end-->
         
         <!--item 9 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
                <img alt="Top Online English Speaking Course in India" title="Best English Speaking Classes Online" class="last-card-image" src="./assets/section-31/ielts-and-english-course.webp">
            </div>
        
           <div class="p-standard-inner">
            <h5>
            IELTS + English Course   
            </h5>
            <div class="">
             <p>
             Designed for students who want to improve their English while preparing for IELTS, ensuring comprehensive language enhancement.  
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 3 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="english-and-ielts-coaching-classes.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 9 end-->
         
         <!--item 10 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
                <img alt="Top IELTS and English Course in Delhi NCR" title="Best Combined IELTS and English Coaching in Delhi" class="last-card-image" src="./assets/section-31/pte-coaching-centre-delhi.webp">
            </div>
           
           <div class="p-standard-inner">
            <h5>
            PTE Coaching  
            </h5>
            <div class="">
             <p>
             Train with expert strategies and practice to achieve the desired scores for overseas education, migration, or job opportunities.
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1.5 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="pte-coaching-near-me.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 10 end-->
         
         <!--item 11 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
                <img alt="Best IELTS Online Classes in India and Abroad" title="Top Online IELTS Coaching from Delhi" class="last-card-image" src="./assets/section-31/pte-and-english-course.webp">
            </div>
          
           <div class="p-standard-inner">
            <h5>
            PTE + English Course 
            </h5>
            <div class="">
             <p>
             Ideal for students who want to refine their English skills while preparing for PTE, ensuring comprehensive language improvement.
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 3 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="english-and-pte-coaching-classes.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         
         <!--item 11 end-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
                <img alt="Best PTE and English Combined Course in Delhi NCR" title="Top PTE English Coaching Centre Delhi" class="last-card-image" src="./assets/section-31/pte-online-course-india.webp">
            </div>
           
           <div class="p-standard-inner">
            <h5>
            PTE Online Coaching 
            </h5>
            <div class="">
             <p>
             Prepare for the PTE exam at your preferred time and place, saving commuting time while ensuring effective learning from home.
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1.5 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="pte-coaching-online.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 11 end-->

         <!--item 12 start-->
         <div class="">
          <div class="final-card-container">
          <div class="image-container">
                <img alt="Top Online PTE Training Classes from Delhi" title="Best PTE Coaching Online in India" class="last-card-image" src="./assets/section-31/personality-development-classes.webp">
            </div>
          
           <div class="p-standard-inner">
            <h5>
            Personality Development   
            </h5>
            <div class="">
             <p>
             Boost confidence, professional etiquette, and interpersonal skills to excel in personal and career growth.  
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> 1.5 Months   </button>
                <button class="know-more-btn01"> <a class="text-white" href="personality-development-course.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <!--item 12 end-->

         <!--item 13 start-->
         <div class="">
          <div class="final-card-container">
           <img alt="Customized English Language Training Course" title="Top Personalised English Coaching Program" class="last-card-image" src="./assets/section-31/personalised-english-classes.webp">
           <div class="p-standard-inner">
            <h5>
            Personalised English Classes  
            </h5>
            <div class="">
             <p>
             We understand that every learner has unique needs, so we offer one-on-one offline English coaching tailored to your goals for effective learning.  
             </p>
             
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> As per needs   </button>
                <button class="know-more-btn01"> <a class="text-white" href="personalised-english-classes.php">Know More</a> </button>
             </div>

            </div>
           </div>
          </div>
         </div>
         <!--item 13 end-->
         
         <!--item 14 start-->
         <div class="">
          <div class="final-card-container">
           <img alt="English Course in Delhi for Competitive Exam Preparation" title="Top English Classes for Competitive Exams" class="last-card-image" src="./assets/section-31/competitive-exam-english-classes.webp">
           <div class="p-standard-inner">
            <h5>
            Competitive English Classes  
            </h5>
            <div class="">
             <p>
             Enhance grammar, vocabulary, and comprehension for competitive exams and professional success.   
             </p>
             <div class="d-flex flex-row align-items-center justify-content-between flex-wrap">
                <button class="month-button01"> <i class="fa fa-regular fa-clock"></i> As per needs   </button>
                <button class="know-more-btn01"> <a class="text-white" href="competitive-exam-english-classes.php">Know More</a> </button>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
        <!--item 14 end-->
       </div>
   
  </section>
  

  <section id="section8">
   <!--Why Choose Us Section Code Start-->
   <div class="why-choose-us-container mt-standard">
    <div class="container-fluid">
          <h2 class="text-center new-classes-heading">Why Choose Us? </h2>
     <div class="row">
      <div class="col-12 col-md-4 col-lg-3 d-flex  custom-mb">
       <img alt="Join English-Speaking Classes Near Me for Fast Learning" class="why-choose-us-image" src="./assets/areawise-english/english-course-near-me/8-why-us.webp">
      </div>
      <div class="col-12 col-md-8 col-lg-9  custom-mb d-flex flex-column justify-content-center">
       <div class="text-content-container p-standard-inner">
        <div class="">
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Experienced &amp; Qualified Trainers -
           </b>
           Learn from highly trained instructors with years of teaching experience.
          </p>
         </div>
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
           Cambridge Curriculum Standards -
           </b>
           Our courses follow globally recognized Cambridge learning frameworks.
          </p>
         </div>
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Smart Classrooms With AV Tools -
           </b>
           Interactive classes with projectors, audio-visual aids, and activities.
          </p>
         </div>
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Affordable Fees With Quality -
           </b>
           Top-quality English training at pocket-friendly and fair pricing.
          </p>
         </div>
         
         <span class="xs-hidden" id="">
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Customizable Learning Programs -
           </b>
           Beginner to advanced-level plans tailored to your specific goals
          </p>
         </div>
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Proven Track Record Since 1997 -
           </b>
           Over 1 lakh students trained—trusted across Delhi for English coaching.
          </p>
         </div>
          <div class="d-flex flex-row ">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Free Demo Class Available -
           </b>
          Attend a free session and see our unique classroom experience.
          </p>
         </div>
         </span>

         <span class="hidden" id="hidden-content10">
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Customizable Learning Programs -
           </b>
           Beginner to advanced-level plans tailored to your specific goals
          </p>
         </div>
         <div class="d-flex flex-row mb-3">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Proven Track Record Since 1997 -
           </b>
           Over 1 lakh students trained—trusted across Delhi for English coaching.
          </p>
         </div> 
          <div class="d-flex flex-row ">
          <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
          <p class="why-choose-paragraph">
           <b>
            Free Demo Class Available -
           </b>
          Attend a free session and see our unique classroom experience.
          </p>
         </div>
         </span>
        </div>
        <div class="d-flex d-lg-none flex-row justify-content-end">
            <button class="read-more-btn mt-4" id="read-more-btn10" type="btn">
             Read More
            </button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Why Choose Us Section Code End-->
  </section>
  

    <div class="container-fluid">
     <div class="enquiry-form-container mt-standard">
  <div class="drop-us-query-container pt-md-3 pb-md-2 p-standard-inner mb-0">
   <div class="">
    <h6>
     Drop Us a Query
    </h6>
   </div>
  </div>
  <div class="p-standard-inner">
   <div class="container-fluid p-0">
    <div class="row">
     <div class="col-12 col-lg-5 mb-3">
      <img loading="lazy" alt="Enquire about our English course in Delhi" class="query-image" src="./assets/more-images/23enquire-now.webp"/>
     </div>
     <div class="col-12 col-lg-7 mb-3 d-flex flex-column justify-content-center">
      <p class="paragraph04">
       We're happy to assist you in your journey towards a brighter career. Drop your details below, and our team will reach you for further assistance.
      </p>
      <form action="" method="post" name="dropQueryForm">
       <div class="d-flex flex-row justify-content-center mb-3">
        <input class="form-control02" placeholder="Enter your Name" name="studentName" type="text" required />
       </div>
       <div class="d-flex flex-row justify-content-center mb-3">
        <input class="form-control02" placeholder="Enter your Number" name="mobile" type="number" required />
       </div>
       <div class="d-flex flex-row justify-content-center mb-3">
        <input class="form-control02" placeholder="Course" type="text" name="course" required />
       </div>
       <div class="d-flex flex-row justify-content-center mb-3">
           <select class="form-control02" required name="centre">
                <option value="" selected> Select Center</option>
                <option value="Pitampura"> Pitampura</option>
                <option value="Laxmi Nagar"> Laxmi Nagar</option>
                <option value="Rajouri Garden"> Rajouri Garden</option>
                <option value="South Extension"> South Extension</option>
            </select>
        <!--<input class="form-control02" placeholder="Select Center" type="text"/>-->
       </div>
       <div class="form-group form-check">
        <input class="form-check-input" id="exampleCheck1" type="checkbox"/>
        <label class="form-check-label" for="exampleCheck1">
         <b>
          Also I agree to receive infomation from Oxford School of English.
         </b>
        </label>
       </div>
         <div class="d-flex flex-row justify-content-end">
           <!--<button class="form-submit" type="btn">-->
           <!-- SUBMIT-->
           <!--</button>-->
           
           <button class="form-submit" type="submit" name="submitQuick"> Submit </button>
          </div>
      </form>
     </div>
    </div>
   </div>
  </div>
 </div>

<!-- Event snippet for drop us query 14072025 conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-1020246609/TxISCKHdzfAaENH0vuYD'});
</script>
    </div>    
  
  <section id="section30">
   <div class="new-coaching-container classroom-section pt-standard mt-standard mt-standard">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-lg-5 mb-3 d-flex flex-column justify-content-center heading-img-section">
          <img src="./assets/30-class/oxford-classrooms.webp" alt="Students engaged in interactive classroom activities">
       <!--<h4 class="text-center online-coaching-button">-->
       <!-- See Our Classroom <br /> in Action-->
       <!--</h4>-->
      </div>
      <div class="col-12 col-lg-7 mb-3">
       <div class="owl-carousel owl-theme" id="owl-carousel06">
            <!--item 1 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/girls-in-festive-mood.webp" alt="Students celebrate in ethnic wear, enjoying festive learning moments" title="">
              <div class="">
               <p class="online-text"> Group of spoken English female students striking poses in colorful ethnic attire, smiling and celebrating cultural diversity </p>
              </div>
             </div>
            </div>
            <!--item 1 end-->
            
            <!--item 2 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/boys-after-festivel-celebration.webp" alt="English course students posing in colorful ethnic attire, smiling together and celebrating culture" title="">
              <div class="">
               <p class="online-text"> Indian students proudly showcase their cultural heritage in vibrant ethnic attire, celebrating tradition with smiles and unity. </p>
              </div>
             </div>
            </div>
            <!--item 2 end-->
            
            <!--item 3 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/mock-interview-ready.webp" alt="Students prepare confidently for a mock interview to improve spoken english" title="">
              <div class="">
               <p class="online-text">Students dressed in formals gear up for a mock interview, enhancing their confidence and communication skills</p>
              </div>
             </div>
            </div>
            <!--item 3 end-->
            
            <!--item 4 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/cosplay-in-class.webp" alt="Spoken english students striking poses post-performance in a costume play party" title="">
              <div class="">
               <p class="online-text">Excited students showcase their creative costumes, capturing joyful memories after a fantastic costume play party.</p>
              </div>
             </div>
            </div>
            <!--item 4 end-->
            
            <!--item 5 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-classroom.webp" alt="Students pose happily for a group photo after their english class" title="">
              <div class="">
               <p class="online-text">Enthusiastic students showcase their confidence and teamwork after completing a spoken English session.</p>
              </div>
             </div>
            </div>
            <!--item 5 end-->
            
            <!--item 6 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-class-selfie.webp" alt="Students and trainer smile together for a cheerful classroom selfie." title="">
              <div class="">
               <p class="online-text">Happy students and their trainer capture a fun classroom moment, celebrating progress in spoken English.</p>
              </div>
             </div>
            </div>
            <!--item 6 end-->
            
            <!--item 7 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-qa-session.webp" alt="Student leads a q&a session while classmates participate with questions" title="">
              <div class="">
               <p class="online-text">Students engage in an interactive Q&amp;A session, building confidence and communication skills in spoken English.</p>
              </div>
             </div>
            </div>
            <!--item 7 end-->
            
            <!--item 8 end-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-roleplay-fun.webp" alt="Students perform a fun english roleplay as classmates and trainer watch" title="">
              <div class="">
               <p class="online-text">Students bring learning to life with an engaging roleplay, making English practice fun and interactive.</p>
              </div>
             </div>
            </div>
            <!--item 8 end-->
            
            <!--item 9 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-students-celebrations.webp" alt="Students cheer together for a fun group photo after class" title="">
              <div class="">
               <p class="online-text">Excited students come together, celebrating their spoken English journey with energy and enthusiasm.</p>
              </div>
             </div>
            </div>
            <!--item 9 end-->
            
            <!--item 10 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/extra-activity-class.webp" alt="Students perform a hygiene skit to promote good habits and cleanliness" title="">
              <div class="">
               <p class="online-text">Students creatively present a skit emphasizing hygiene, promoting awareness through engaging performances.</p>
              </div>
             </div>
            </div>
            <!--item 10 end-->
            
            <!--item 11 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/formal-english-success.webp" alt="Students in formal wear pose confidently after completing their session" title="">
              <div class="">
               <p class="online-text">Students dressed in formals proudly showcase their confidence and enthusiasm after a spoken English class..</p>
              </div>
             </div>
            </div>
            <!--item 11 end-->
            
            <!--item 12 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/group-discussion.webp" alt="Spoken english students in a group discussion, sharing ideas to improve fluency." title="">
              <div class="">
               <p class="online-text">Students actively participate in a group discussion, enhancing their spoken English fluency and confidence.</p>
              </div>
             </div>
            </div>
            <!--item 12 end-->
            
            <!--item 13 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/mock-presentation-success.webp" alt="Students pose with trainers after a successful mock presentation" title="">
              <div class="">
               <p class="online-text">Confident students and trainers capture a proud moment after a successful mock presentation session.</p>
              </div>
             </div>
            </div>
            <!--item 13 end-->
            
            <!--item 14 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/senior-student-participant.webp" alt="A senior spoken English student reading aloud in class while holding a mic with confidence." title="">
              <div class="">
               <p class="online-text">Confidently reading aloud, a senior student practices spoken English skills in a formal classroom setting.</p>
              </div>
             </div>
            </div>
            <!--item 14 end-->
            
            <!--item 15 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/spoken-english-group.webp" alt="Students pose joyfully at the english center, celebrating their progress" title="">
              <div class="">
               <p class="online-text">Happy students come together for a memorable group photo, showcasing their progress in spoken English.</p>
              </div>
             </div>
            </div>
            <!--item 15 end-->
            
            <!--item 16 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/spoken-english-success.webp" alt="Students celebrate their progress joyfully after english class" title="">
              <div class="">
               <p class="online-text">Happy students express their excitement and achievement after an engaging spoken English session.</p>
              </div>
             </div>
            </div>
            <!--item 16 end-->
            
            <!--item 17 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/english-course-certification.webp" alt="Students proudly show certificates after completing their english course" title="">
              <div class="">
               <p class="online-text">Students showcase their hard-earned certifications, marking their success in spoken English learning.</p>
              </div>
             </div>
            </div>
            <!--item 17 end-->
            
            <!--item 18 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/30-class/class-room.webp" alt="Trainer teaches in a smart classroom while students listen attentively" title="">
              <div class="">
               <p class="online-text">Our dedicated English trainer guiding students through English lessons, making learning interactive and engaging.</p>
              </div>
             </div>
            </div>
            <!--item 18 end-->
            
            <!--item 19 start-->
            <div class="item">
             <div class="new-courses-container p-standard-inner">
              <img class="w-100 mb-3" src="./assets/section-30-classrooms/activity-based-learning-english-speaking-oxford.webp" alt="Students Learning Through Activity-based Methods" title="Deep Dive Lesson">
              <div class="">
               <p class="online-text">Students actively engage in classroom activities, enjoying the learning process through interactive, fun, and effective activity-based methods.</p>
              </div>
             </div>
            </div>
            <!--item 19 end-->
            
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  
  <section class="mt-standard new-english-section" id="section33">
   <!--<div class="d-lg-block d-none">-->
   <div class="">
    <div class="footer-before-container py-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-12">
        <h5 class="text-center"> Beyond Books and Classrooms </h5>
       </div>
      </div>
     </div>
    </div>
   </div>
    <div class="container">
        <div class="owl-carousel owl-theme threeItemSlider light-icons" id="owl-carousel08">
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Welcoming students for alumni meet at our english study center laxmi nagar" class="last-card-image" src="./assets/33-activities/alumni-welcome.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Alumni Welcome
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Diwali Celebration at our English speaking center pitampura" class="last-card-image" src="./assets/33-activities/diwali-celebrations.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Diwali Celebations 
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Talent show participants in full zeal at  english class" class="last-card-image" src="./assets/33-activities/talent-show.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Talent  Show Participants
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Fashion show preparations in full swing" class="last-card-image" src="./assets/33-activities/fashion-show-preparations.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Fashion Show Zeal
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Fashion show by english course students" class="last-card-image" src="./assets/33-activities/fashion-show.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Fashion Festivities Fun
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="English course students showing their acting prowess with macbeth" class="last-card-image" src="./assets/33-activities/scenes-from-macbeth.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Staging Shakespeare's Macbeth
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Face paint and loads of masti" class="last-card-image" src="./assets/33-activities/face-paint-masti.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Face Paint Activity 
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Students organized a blood donation camp with Lions Club to support the society" class="last-card-image" src="./assets/33-activities/blood-donation-camp.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Community Blood Donation 
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt=" Students staging scenes from ramayana " class="last-card-image" src="./assets/33-activities/ramleela-play.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Post Performance Masti
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="English speaking course students ready to give mock interviews" class="last-card-image" src="./assets/33-activities/mock-interviews.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Mock Interviews
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Students enjoying after receving awards" class="last-card-image" src="./assets/33-activities/award-ceremony.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Award Distribution Ceremony
                </h5>
               </div>
              </div>
            </div>
            <div class="mb-3">
              <div class="beyond-card-container">
              <div class="image-container">
                    <img alt="Learning English by outdoor activity" class="last-card-image" src="./assets/33-activities/outdoor-fun-learning.webp">
                </div>
               <div class="p-standard-inner">
                <h5>Outdoor Talk Show
                </h5>
               </div>
              </div>
            </div>
            
        </div>
       </div>
  </section>
  

  <section id="section10">
   <!--Online classes Section Code Start-->
   <div class="">
    <div class="new-classes-container mt-standard">
     <div class="container-fluid">
      <h5>
       Highlights of Our English Course  &ndash;
       <br>
      Best  English Training Institute Near You in Delhi
      </h5>
      <div class="line01">
      </div>
     </div>
     <div class="new-mini-container p-standard-inner">
      <div class="container-fluid p-0">
       <div class="white-content-container p-standard-inner mb-standard-inner custom-mb">
        <div class="row">
         <div class="col-12 col-lg-3 d-flex flex-column justify-content-center">
          <img class="highlight-image" src="./assets/areawise-english/english-course-near-me/10a-class-highlights.webp" alt="Key Features of Our English Classes Near Me">
         </div>
         <div class="col-12 col-lg-9 d-flex flex-column justify-content-center">
          <h3 class="new-classes-heading">
           English Classes Highlights
          </h3>
          <div class="box-description-container p-standard-inner">
           <div class="">
            <div class="d-flex flex-row mb-3 pt-2">
             <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
             <p class="why-choose-paragraph">
              <b>
               Grammar & Vocabulary Skills  -
              </b>
              Build a strong base with essential grammar and rich vocabulary. 
             </p>
            </div>
            <div class="d-flex flex-row mb-3">
             <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
             <p class="why-choose-paragraph">
              <b>
               Pronunciation Practice -
              </b>
              Polish your speech for clarity and confident conversations.
             </p>
            </div>
            
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Listening Comprehension  -
               </b>
               Understand diverse English accents and speaking styles.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Interactive Speaking Sessions  -
               </b>
               Boost fluency with role-plays and real-life conversations.
              </p>
             </div>
             
            <span class="hidden" id="content-part01">
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Cultural Immersion Tasks  -
               </b>
               Learn English via real-world cultural activities and tasks.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Practical Language Use  -
               </b>
               Apply English in everyday scenarios for lasting impact.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Idiomatic Expression Practice  -
               </b>
               Use idioms naturally in spoken English with ease.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
               Public Speaking Workshops  -
               </b>
               Gain confidence in delivering clear and engaging speeches.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Group Discussions & Debatess  -
               </b>
               Sharpen speaking through GDs, JAM, and panel debates.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
               Telephonic Communication Skillss  -
               </b>
               Master professional etiquette for phone conversations.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Interview Preparation Drills  -
               </b>
               Practice mock interviews and get expert improvement tips.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Professional Email Writing  -
               </b>
               Write clear and impactful workplace emails confidently.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
               AI-Based Writing Support  -
               </b>
               Use AI tools to improve tone, grammar, and clarity.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Personalised Feedback System  -
               </b>
               Get individual guidance to track and improve faster.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Home Assignments for Practice  -
               </b>
               Reinforce learning with consistent, practical homework.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
              Multimedia Learning Resources  -
               </b>
               Explore audio, video, and interactive content anytime.
              </p>
             </div>
             <div class="d-flex flex-row mb-3">
              <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
              <p class="why-choose-paragraph">
               <b>
                Oxford LMS Access – Free  -
               </b>
               Practice online anytime using our digital LMS platforms.
              </p>
             </div>
            
             
           </div>
           </span>
           <div class="d-flex d-lg-none flex-row justify-content-end">
            <button class="read-more-btn mt-4" id="read-more-btn01" type="btn">
             Read More
            </button>
           </div>
          </div>
         </div>
        </div>
       </div>
       <div class="white-content-container p-standard-inner">
        <div class="row">
         <div class="col-12 col-lg-3 d-flex flex-column justify-content-center">
          <img alt="Eligibility for Joining English Courses Near Me" class="highlight-image" src="./assets/areawise-english/english-course-near-me/10b-join-english-course.webp">
         </div>
         <div class="col-12 col-lg-9 d-flex flex-column justify-content-center">
          <h4 class="new-classes-heading">
          Who Can Join Our English-Speaking Classes?
          </h4>
          <p class="white-container-paragraph">
           Want to boost your English skills? Join the best English-speaking course in North Delhi. Our training improves communication for jobs, academics, social life, business, and career growth—perfect for anyone who speaks fluently and confidently.
           </b>
          </p>
          <!--</div>-->
          <div class="box-description-container inner pt-3">
           <div class="container-fluid">
            <h4 class="new-classes-heading">
             Our English Classes are ideal for:-
            </h4>
            <div class="row">
             <div class="col-12 col-lg-3">
              <div class="d-flex flex-row align-items-center mb-3">
               <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
               <p class="why-choose-paragraph01">
                Job Aspirants
               </p>
              </div>
             </div>
             <div class="col-12 col-lg-3">
              <div class="d-flex flex-row align-items-center mb-3">
               <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
               <p class="why-choose-paragraph01">
                Working Professionals
               </p>
              </div>
             </div>
             <div class="col-12 col-lg-3">
              <div class="d-flex flex-row align-items-center mb-3">
               <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
               <p class="why-choose-paragraph01">
                Business Owners
               </p>
              </div>
             </div>
             <div class="col-12 col-lg-3">
              <div class="d-flex flex-row align-items-center mb-3">
               <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
               <p class="why-choose-paragraph01">
                School Students
               </p>
              </div>
             </div>
            </div>
            <div class="xs-hidden" id="content-part02">
             <div class="row">
              <div class="col-12 col-lg-3">
               <div class="d-flex flex-row align-items-center mb-3">
                <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
                <p class="why-choose-paragraph01">
                 Undergraduates Students
                </p>
               </div>
              </div>
              <div class="col-12 col-lg-3">
               <div class="d-flex flex-row align-items-center mb-3">
                <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
                <p class="why-choose-paragraph01">
                 Homemakers
                </p>
               </div>
              </div>
              <div class="col-12 col-lg-3">
               <div class="d-flex flex-row align-items-center mb-3">
                <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
                <p class="why-choose-paragraph01">
                 Overseas Job Seekers
                </p>
               </div>
              </div>
              <div class="col-12 col-lg-3">
               <div class="d-flex flex-row align-items-center mb-3">
                <img alt="right-arrow-icon-image" class="right-arrow-icon-image" src="./assets/icons/login-arrow-icon.webp">
                <p class="why-choose-paragraph01">
                 Study abroad Candidates
                </p>
               </div>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="d-flex flex-row justify-content-end">
           <button class="read-more-btn md-hidden" id="read-more-btn02" type="btn">
            Read More
           </button>
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--Online classes Section Code End-->
  </section>
  

  <section id="section11">
   <!--review-container-section Code Start-->
   <div class="review-container mt-standard">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-lg-4">
       <div class="d-flex flex-column justify-content-center pr-md-5 h-100">
        <p class="paragraph02">
         Students Reviews and Fun Learning
        </p>
        <div class="line01">
        </div>
        <p class="paragraph03">
         Watch our students share their experiences and enjoy fun-filled learning moments in our engaging classes!
        </p>
       </div>
      </div>
      <div class="col-12 col-lg-4">
       <div class="card-container p-standard-inner">
        <div class="">
         <h4 class="mt-0">
          Students Reviews
         </h4>
         <div class="image-container">
          <img src="./assets/11-review/video-reviews.webp" title="Students Videos" alt="English course Students sharing their experience at Oxford" />
     
          <button class="video-btn play-video-button" data-video="https://www.youtube.com/embed/v3PtNGKk8Lk?si=FhwzueWeOF6JMGY1">
           <i class="fa fa-solid fa-play">
           </i>
           Play Video
          </button>
          
         </div>
         <p class="list01">
          Who knows the institute, trainers, and courses best? The students! Hear directly from our online students who have experienced one-on-one classes.
         </p>
        </div>
       </div>
      </div>
      <div class="col-12 col-lg-4">
       <div class="card-container p-standard-inner">
        <div class="">
         <h4 class="mt-0">
          Fun Learning
         </h4>
         <div class="image-container">
          <img src="./assets/11-review/fun-activities.webp" alt="Learning English at Oxford is a Fun" title="Masti and Learning" />   
        
          
          <button class="video-btn play-video-button" data-video="https://www.youtube.com/embed/Felt0avSaxo?si=z5zbFfBlhqzwk7aG">
           <i class="fa fa-solid fa-play">
           </i>
           Play Video
          </button>
         </div>
         <p class="list01">
          Experience fun learning with interactive games, group discussions, role-plays, and more making English engaging and effective!
         </p>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--review-container-section Code End-->
  </section>


  <section id="section12">
   <!--online-english-coaching-outcome-section Code Start-->
   <div class="new-courses-section-container mt-standard py-standard mt-standard">
    <div class="container-fluid">
     <div class="row">
      <div class="col-12 col-lg-5 mb-3 mb-md-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
       <h3 class="text-center h4">
         Outcome of English Coaching
       </h3>
       <div class="white-text-container pt-3 pb-1">
        <div class="container-fluid">
         <p class="coaching-outcome-description">
          Through this course, you&rsquo;ll develop fluency, refine grammar, and enhance communication skills for social and professional scenarios. With personalised and interactive sessions, you&rsquo;ll excel in interviews, public speaking, and real-world interactions, achieving personal and professional growth.
         </p>
        </div>
       </div>
      </div>
      <div class="col-12 col-lg-7 mb-3 mb-md-0 order-1 order-lg-2">
       <img alt="Boost Your Career with Spoken English Classes Near Me" src="./assets/areawise-english/english-course-near-me/12-outcome.webp"/>
      </div>
     </div>
    </div>
   </div>
   <!--online-english-coaching-outcome-section Code Start-->
  </section>
  
 
  <section id="section16">
  <div class="d-flex flex-row justify-content-center">
   <h4 class="best-english-blogs-button text-center mt-standard">
    Best English Blogs by the Oxford School of English Team
   </h4>
  </div>
  <!--new-blog-container section Code Start-->
   <div class="new-blog-container pt-5 pb-3">
    <div class="container-fluid">
     <div class="owl-carousel owl-theme" id="owl-carousel03">
      <div class="item">
       <div class="blog-card-container p-standard-inner">
        <div class="">
         <div class="image-container02">
          <img alt="New Words Added in English in 2024" class="blog-image" src="./assets/16-blogs/new-gems-of-english.webp"/>
         </div>
         <p class="blog-heading">
          Master the 7 C’s of Communication
         </p>
         <p class="blog-description m-0">
          Learn how clarity, coherence, and courtesy can transform your communication. Master all 7 C’s for personal and professional success.
         </p>
          <button class="know-more-btn01 mt-3"><a href="7c-of-communication.php" class="text-white"><b>Read More</b></a></button>
        </div>
       </div>
      </div>
      <div class="item">
       <div class="blog-card-container p-standard-inner">
        <div class="">
         <div class="image-container02">
          <img alt="Phrasal Verbs" class="blog-image" src="./assets/16-blogs/harnessing-happiness-phrasal-verbs.webp"/>
         </div>
         <p class="blog-heading">
          Fun & Strange Facts About English
         </p>
         <p class="blog-description m-0">
          Explore bizarre spellings, rare trivia, and quirky grammar rules. Discover what makes English one of the most fascinating languages!
         </p>
         <button class="know-more-btn01 mt-3"><a href="english-some-interesting-facts.php" class="text-white"><b>Read More</b></a></button>
        </div>
       </div>
      </div>
      <div class="item">
       <div class="blog-card-container p-standard-inner">
        <div class="">
         <div class="image-container02">
          <img alt="Mnemonic Magic " class="blog-image" src="./assets/16-blogs/mnemonic-magic.webp"/>
         </div>
         <p class="blog-heading">
          10 Types of Liars You Should Know
         </p>
         <p class="blog-description m-0">
          From glib to pathological, discover 10 types of liars and learn how to spot their unique patterns of deception in everyday life, conversations, and relationships.
         </p>
         <button class="know-more-btn01 mt-3"><a href="10-ways-to-describe-liars.php" class="text-white"><b>Read More</b></a></button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  
     <!--section 19 start-->

  <div class="hear-student-container">
   <div class="container-fluid">
    <h4 class="hear-student-container-heading">
     <span class="span06"> H</span>ear It from Our Students
    </h4>
    <p class="hear-student-container-description">
     Listen to our students share their learning experiences, growth, and feedback about our courses!
    </p>
   </div>
  </div>
  <section id="section19">
   <!--hear-it-student-container-section Code Start-->
   <div class="hear-it-student-container-section pb-standard pt-5">
    <div class="container-fluid01">
     <div class="owl-carousel owl-theme pt-2" id="owl-carousel04">
        <!--item 1 start-->
        <div class="item">
       <div class="hear-it-box-container py-standard-inner">
        <div class="container-fluid">
         <div class="d-flex flex-row justify-content-center">
          <img alt="Ganjeena from Afghanistan shares feedback on her English course experience" class="student-image" src="./assets/19-video-review/ganjeena-video-review.webp"/>
         </div>
         <h6 class="student-name-heading">
          Ganjeena
         </h6>
         <div class="d-flex flex-row justify-content-center">
          <button class="play-video-button" data-video="https://www.youtube.com/embed/WuzDMDcmhis">
           <i class="fa fa-solid fa-play">
           </i>
           Play Video
          </button>
         </div>
        </div>
       </div>
      </div>
        <!--item 1 end-->
        
        <!--item 2 start-->
        <div class="item">
       <div class="hear-it-box-container py-standard-inner">
        <div class="container-fluid">
         <div class="d-flex flex-row justify-content-center">
          <img alt="Jaspreet is a happy students of our English classes" class="student-image" src="./assets/19-video-review/jaspreet-video-review.webp"/>
         </div>
         <h6 class="student-name-heading">
          Jaspreet
         </h6>
         <div class="d-flex flex-row justify-content-center">
          <button class="play-video-button" data-video="https://www.youtube.com/embed/HDIBe2SOLE4">
           <i class="fa fa-solid fa-play">
           </i>
           Play Video
          </button>
         </div>
        </div>
       </div>
      </div>
        <!--item 2 end-->
        
        <!--item 3 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Sarpreet confidently presenting during an English speaking class at Oxford" class="student-image" src="./assets/19-video-review/sarpreet-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Sarpreet
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/jpzTZZvGbnw">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 3 end-->
        
        <!--item 4 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Kanika shares her positive review of english coaching at oxford." class="student-image" src="./assets/19-video-review/kanika-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Kanika
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/iLi3GhptGo8">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 4 end-->
        
        <!--item 5 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Deepak giving a student review of Oxford’s English coaching in Delhi" class="student-image" src="./assets/19-video-review/deepak-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Deepak
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/Avjbj6BZUGk">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 5 end-->
        
        <!--item 6 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
                  <img alt="Aanchal explains how English coaching helped build her confidence" class="student-image" src="./assets/19-video-review/anchal-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Aanchal
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/NrVEyg8JVZA">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 6 end-->
        
        <!--item 7 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Geetika explains how English coaching helped build her confidence" class="student-image" src="./assets/19-video-review/geetika-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Geetika
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/6DmCIO-aEDg?feature=share">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 7 end-->
        
        
        <!--item 8 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Mukund sharing feedback about his English speaking course at Oxford School of English in Delhi" class="student-image" src="./assets/19-video-review/mukund-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Mukund
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/S7Uf4iaammE?feature=shareA">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 8 end-->
        
        <!--item 9 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Isha reflects on her beginner journey through English speaking classes" class="student-image" src="./assets/19-video-review/isha-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Isha
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/DHfFvVUoFAY">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 9 end-->
        
        <!--item 10 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Priyanshu talks about learning English at Oxford’s English speaking course" class="student-image" src="./assets/19-video-review/priyanshu-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Priyanshu
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/eEpa4Hj7Rzk?feature=share">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 10 end-->
        
        <!--item 11 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Sumaira from Afghanistan shares feedback on her English course experience" class="student-image" src="./assets/19-video-review/sumaira-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Sumaira
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/bpTHNAShsmM">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 11 end-->
        
        <!--item 12 start-->
        <div class="item">
           <div class="hear-it-box-container py-standard-inner">
            <div class="container-fluid">
             <div class="d-flex flex-row justify-content-center">
              <img alt="Shail shares her journey of improving communication with Oxford’s English course" class="student-image" src="./assets/19-video-review/shail-video-review.webp"/>
             </div>
             <h6 class="student-name-heading">
              Shail
             </h6>
             <div class="d-flex flex-row justify-content-center">
              <button class="play-video-button" data-video="https://www.youtube.com/embed/P_MSqh0xtGM">
               <i class="fa fa-solid fa-play">
               </i>
               Play Video
              </button>
             </div>
            </div>
           </div>
          </div>
        <!--item 12 end-->
        
     </div>
    </div>
   </div>
   <!--hear-it-student-container-section Code End-->
  </section>
  <!--section 19 end-->

      <section id="section35" class="mt-standard">
    <!-- Adib 2 -->
    <div class="bg-overlay">
      <div class="container p-0">
        <div class="bg-banner banner2 m-0 row align-items-center text-center text-xl-left text-xl-start ">
          <!-- Text Section -->
          <div class="col-xl-6 mb-md-0 pl-text pr-40">
            <h2>
              Best English
              <br>
              Classes in Delhi
              <br>
              Since 1997
            </h2>
            <div class="direction grid grid-cols-4 grid-cols-2 mt-3">
              <a href="contact-us-pitampura.php">North Delhi</a> 
              <a href="contact-us-south-extension.php">South Delhi</a> 
              <a href="contact-us-laxmi-nagar.php">East Delhi</a> 
              <a href="contact-us-rajouri-garden.php">West Delhi</a> 
            </div>
          </div>

          <div class="col-xl-6 pl-40">
            <div class="enquiry">
    <h3>QUICK ENQUIRY</h3>
    <form method="post">
        <input type="text" name="studentName" required placeholder="Enter your Name">
        <input type="tel" name="mobile" maxlength="10" required placeholder="Enter your Number">
        <input type="text" name="course" placeholder="Course">
        <select name="centre" name="centre" required>
            <option value="Select a Center">Select a Center *</option>
            <option value="Center 1">Laxmi Nagar </option>
            <option value="Center 2">Pitampura </option>
            <option value="Center 2">Rajouri Garden </option>
            <option value="Center 2">South Extension </option>
        </select>
    
        <input class="d-none" type="hidden" name="form_submitted" value="1"> 
        <button class="btn-red" type="submit" name="submitQuick">Submit</button>
    </form>
        
</div>          </div>

           <div class="d-flex flex-row justify-content-center w-100 mt-4">
              <a href="./assets/oxford-english-brochure.pdf" target="_blank" class="download-brochure-button01 btn-brocher mt-3 mb-0 brochure-35" type="button">
                <img loading="lazy" width="30" height="30" src="./assets/icons/download.webp" alt="email" style="margin-right: 5px;">
                Download Brochure
              </a>
            </div>
        </div>
      </div>
    </div>
  </section>

  

    <link href="./css/bootstrap.css" rel="stylesheet"/>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/adib-css/adib-common.css">

<!--<h3 class="text-center">-->
<!--     Section 17-->
<!--  </h3>-->
  <section class="oxford-branches mt-standard" id="section17">
    <div class="d-flex flex-row justify-content-center">
    <h3 class="new-abc-button mb-0">
      Oxford School of English Branches
    </h3>
    </div>
       <!--english-speaking-classes-section Code Start-->
       <div class="new-branches-container pt-5 py-standard">
        <div class="container-fluid">
         <div class="grid grid-cols-3 grid-cols-2-17 g-gap card-scroll">
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Pitampura Branch </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  365 Kohat Enclave, Near Kohat Metro Station Gate No. 3, North Delhi -110034 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127373"> 9540127373</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:45680574"> 011 - 45680574</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-pitampura.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6981337,77.1372723,17z/data=!3m1!4b1!4m5!3m4!1s0x390d03da0abc6ac3:0xe4642d10ca8d8fbf!8m2!3d28.698129!4d77.139461?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Laxmi Nagar</h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  E 354, Nirman Vihar, Adjacent to Nirman Vihar Metro Station Gate Number 2, East Delhi -110092 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127878"> 9540127878</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 40159334</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-laxmi-nagar.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6372579,77.2865177,17z/data=!4m5!3m4!1s0x390cfb56b6843fff:0xbd5d17737bc80438!8m2!3d28.6372532!4d77.2887064?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> South Extension </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> E 10, Part-I, Near South Extension Metro Station, South Extension, South Delhi -110049 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9810735296"> 9810735296 </a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255102"> 011 - 41255102</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-south-extension.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute+South+Extention/@28.5706783,77.219955,17z/data=!3m1!4b1!4m6!3m5!1s0x390ce25d0ac35f11:0x3125b97033cf142f!8m2!3d28.5706783!4d77.219955!16s%2Fg%2F1th0wr3f?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Rajouri Garden </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> A 4, Vishal Enclave, opposite Metro Pillar No. 411, West Delhi -110027 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9319608182"> 9319608182</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 41255104 </a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-rajouri-garden.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute+Rajouri+Garden/@28.6880275,77.1244528,12z/data=!4m6!3m5!1s0x390d0372a62dafe3:0x5e55587ff09b2755!8m2!3d28.6478906!4d77.1190374!16s%2Fg%2F11bxc5l07v?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <!--english-speaking-classes-section Code End-->
  </section>
  
  
  <footer>
   <div class="">
    <div class="mobile-footer-container px-3 py-standard">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Quick Links
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="/">
           Home
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="about.php">
           About 
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-blogs.php">
           English Blogs
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="gallery-fun-learning.php">
           Gallery
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="hire-fresher.php">
           Placement Employer
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="job-for-freshers-in-delhi.php">
           Placement Student
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="contact-us.php">
           Contact Us
          </a>
         </li>
          <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms/inquiry.php">
           Enquiry Form
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms">
           LMS
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-course-faqs.php">
           English Course FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-exam-faqs.php">
           IELTS Exam FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-exam-faqs.php">
           PTE Exam FAQ
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="spoken-english-classes-near-me.php">
           English Classes Near Me
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Courses
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon01">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks01" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course.php">
           All Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course-for-beginners.php">
           Interchange Beginners Level-1
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="intermediate-level-english-speaking-course.php">
           Interchange Intermediate Level-2
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="advance-english-speaking-course.php">
           Interchange Advance Level-3
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-coaching-near-me.php">
           IELTS Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="basic-spoken-english-course.php">
           Basic Spoken English Course
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-english-speaking-course.php">
           Online English Classes
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-ielts-coaching.php">
           IELTS Online Coaching
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-coaching-near-me.php">
           PTE Course
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="pte-coaching-online.php">
           PTE Online Coaching
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         About 
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <p class="footer-about-us-description">
         Oxford School of English, with four branches since 1997, stands as Delhi’s leading English-speaking Institute and offers the best English-speaking course (also called English talking course by many) from basic to advanced levels. If you are searching for English-speaking classes near me, Oxford is the best choice, with branches in all directions of Delhi, having trained over one lakh students as an NSDC training partner.
        </p>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         Course Enquiry
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <form action="" method="post" name="frm">
            <!--<input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />-->
            <input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />
            <input class="footer-form-control" name="mobile" placeholder="Enter your Number" type="text" required />
            <input class="footer-form-control" name="course" placeholder="Course" type="text" required />
            <select class="footer-form-control" name="centre" required>
                <option value="" selected> Select Center</option>
                <option value="Pitampura"> Pitampura</option>
                <option value="Laxmi Nagar"> Laxmi Nagar</option>
                <option value="Rajouri Garden"> Rajouri Garden</option>
                <option value="South Extension"> South Extension</option>
            </select>
         <!--<input class="footer-form-control" placeholder="Enter Your Name" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Enter Your Number" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Select Center" type="text"/>-->
         <div class="d-flex flex-row justify-content-center">
          <button class="footer-form-submit-btn" type="submit" name="submitQuick">
           Submit
          </button>
         </div>
        </form>
       </div>
      </div>
     </div>
    </div>
    <div class="footer-border-bottom-line">
    </div>
    <div class="mobile-footer-container pt-4 pb-4 px-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Proud Associations
        </p>
        <div class="row">
         <div class="col-7 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/oxford-nsdc-partner.webp" alt="Oxford is a Proud Partner of NSDC" />
         </div>
         <div class="col-5 col-lg-2 mb-3">
          <img loading="lazy" class="partner-image" src="./assets/footer/skill-courses.webp" alt="We Offer Skill Courses for Better Employment" />
         </div>
         <div class="col-12 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/cambridge-partner.webp" alt="Oxford School of English Offers Cambridge University Press Courses" />
         </div>
        </div>
       </div>
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Connect with Us
        </p>
        <div class="d-flex flex-row justify-content-between justify-content-md-start">
         <a href="https://www.facebook.com/delhioxfordenglish">
          <img loading="lazy" alt="Facebook Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-facebook.webp"/>
         </a>
         <a href="#">
          <img loading="lazy" alt="x-icon" class="social-icon" src="./assets/footer/x-oxford-english.webp"/>
         </a>
         <a href="https://www.instagram.com/oxfordschoolofenglish.in">
          <img loading="lazy" alt="Instagram Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-instagram.webp"/>
         </a>
         <a href="https://www.youtube.com/channel/UC50IGGpwAuCGcVzP6Tx2TPg">
          <img loading="lazy" alt="YouTube Channel of Oxford School of India" class="social-icon" src="./assets/footer/oxford-english-youtube.webp"/>
         </a>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      English Speaking Institute Near You
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Kohat Enclave
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near nangloi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Paschim Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Shalimar Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Punjabi Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Rani Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rohini.php">
          English Speaking Course in Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Narela
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Bawana
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Uttam Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Shahdara
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Preet Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Nirman Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Krishna Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Geeta Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Patparganj
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Vaishali
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Kaushambi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in Kotla
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Defence Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Kalkaji
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Green Park
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Hauz Khas
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="spoken-english-classes-near-me.php">
          English Classes Near Me
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-classes-delhi.php">
          English Speaking Course in Delhi
         </a>
        </li>
       </ul>
      </div>
     </div>
    </div>
   </div>

   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      IELTS Coaching Institute Near You In Delhi
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-pitampura.php">
          IELTS Coaching in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rohini.php">
         IELTS Coaching near  Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching   in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching   in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching  near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>

     </div>
    </div>
   </div>

   <div class="copyright-container pt-4 pb-2">
    <div class="container-fluid">
     <h5 class="copyright-heading">
      Copyright &copy; 1997 - 2025 Hindustan Soft Education Limited, New Delhi || All the logos and images are the copyright of their respective owners
     </h5>
     <div class="d-flex flex-row justify-content-center">
      <p class="copyright-paragraph">
       *Privacy Policy : We do not distribute your email or contact information to other websites or sources and will be kept confidential. We do not accept or host any advertisement on this website. We do collect visitor data and asses the user traffic on our website and various pages which helps us to improvise. We do not collect any personal information on visitors. Any information which is considered to have ethnic or gender bias, derogatory or lewd will be removed by owner of this website at their discretion without any notice. By using our website, you agree to our privacy policy as mentioned above. Our privacy policy may get updated without any notice, hence users are suggested to review it before they plan to submit any personal information to our website.
      </p>
     </div>
    </div>
   </div>
  </footer>
  <div class="popup" id="videoPopup">
   <div class="popup-content">
    <span class="close-btn" onclick="hidePopup()">
     &times;
    </span>
    <video controls="" id="popupVideo">
     <source src="" type="video/mp4"/>
     Your browser does not support the video tag.
    </video>
   </div>
  </div>
  <div class="video-overlay" id="videoOverlay">
   <div class="video-container">
    <div class="embed-responsive embed-responsive-16by9">
     <iframe allowfullscreen="" class="embed-responsive-item" id="videoIframe" src="">
     </iframe>
    </div>
    <span class="close-btn01" id="closeBtn01">
     <img loading="lazy" src="./assets/icons/cross.webp" width="40" height="40" alt="cross">
    </span>
   </div>
  </div>
  <!-- <script src="banners/js/aos.js"></script> -->
  <script>
  
  </script>
  <script src="js/common.js" defer></script>

  <script src="js/custom-carousel.js" defer></script> 

  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" defer ></script>

  <script  src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" defer ></script>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" defer></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"  defer></script>

  <script src="./js/adib-script.js" defer></script>

  <!-- Ashutosh's code start - 16-04-2025
     Code to reload images that did not load the first time -->

  <script>
//     $(document).ready(function() {
//       $('img').each(function () {
//         if (!this.complete || typeof this.naturalWidth === "undefined" || this.naturalWidth === 0) {
//           var src = $(this).attr('src');
//           $(this).attr('src', src); // Force reload
//         }
//       });
//     });
 </script>
  <!-- Ashutosh's code end -->
  <!--banner script-->
  
 </body>
</html>