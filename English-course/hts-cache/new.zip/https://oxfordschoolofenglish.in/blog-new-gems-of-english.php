<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn the latest English words reflecting modern life, tech, and culture. Boost your vocabulary with these valuable and current terms to stay updated.">
    <title>New English Words: Trending Vocab</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"/>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

<link href="css/style.css" rel="stylesheet" />

<link href="css/css190425/header.css" rel="stylesheet"/>
<link href="css/css190425/common.css" rel="stylesheet"/>
<link href="css/css190425/default-banner.css" rel="stylesheet"/>

<link href="css/combined-global.css" rel="stylesheet" />

<link href="css/adib-css/adib4.css" rel="stylesheet"/>
<link href="css/adib-css/adib5.css" rel="stylesheet"/>
<link href="css/adib-css/adib6.css" rel="stylesheet"/>
<link href="css/adib-css/adib9.css" rel="stylesheet"/>
<link href="css/adib-css/adib10.css" rel="stylesheet"/>
<link href="css/adib-css/adib11.css" rel="stylesheet"/>
<link href="css/css190425/section41.css" rel="stylesheet"/>

 <link href="./banners/css/home-banner03.css" rel="stylesheet" />
<link href="css/css190425/footer.css" rel="stylesheet"/>


<link href="css/floating-buttons.css" rel="stylesheet"/>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"/>

   <link rel="stylesheet" type="text/css"
  href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet" />

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"  rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  rel="stylesheet"/>

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '489625390408393');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=489625390408393&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->


<!-- Fallback Open Graph (OG) Tags -->
<meta property="og:title" content="Oxford School of English – Best English Speaking Courses in Delhi" />
<meta property="og:description" content="Join Oxford School of English. English Speaking Courses in Pitampura, Rajouri Garden, South Extension and Laxmi Nagar since 1997." />
<meta property="og:image"content="https://www.oxfordschoolofenglish.in/images/og/english-course.jpg" />
<meta property="og:url" content="https://www.oxfordschoolofenglish.in/" />
<meta property="og:type" content="website" />


<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="/oxford-school-of-english-icon.png">
<link rel="apple-touch-icon" href="/oxford-english-apple-icon.png">

<!-- Google tag (gtag.js) for GA4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6VXK325WCQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-6VXK325WCQ');
</script>
    <link rel="canonical" href="https://oxfordschoolofenglish.in/blog-new-gems-of-english.php" />
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"
      integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link
      rel="stylesheet"
      type="text/css"
      href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"
    />

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />

    <link href="./blog/blog-css/blog.css" rel="stylesheet" />
</head>
<body>



<header>
   <!--Desktop Navbar Header Code Start-->
   <div class="d-lg-block d-none">
    <div class="desktop-navbar">
     <nav class="navbar navbar-expand-lg navbar-light fixed-top">
         <a href="/">
            <img loading="lazy" class="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp" alt="oxford school of english delhi logo"/>
         </a>
      <button aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbar" data-toggle="collapse" type="button">
       <span class="navbar-toggler-icon">
       </span>
      </button>
      <div class="collapse navbar-collapse" id="navbar">
       <ul class="navbar-nav m-auto">
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Home
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="index.php">
           Home
          </a>
          <a class="dropdown-item" href="about.php">
           About
          </a>
          <a class="dropdown-item" href="gallery-fun-learning.php">
           Gallery
          </a>
          <a class="dropdown-item" href="english-blogs.php">
          English Blogs
          </a>
          <a class="dropdown-item" target="_blank" href="lms">
           LMS
          </a>
          <a class="dropdown-item" href="franchise-opportunity.php">
           Franchise
          </a>
         </div>
        </li>
        <li class="nav-item dropdown megamenu-li large-li">
         <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
          Courses
         </a>
         <div aria-labelledby="dropdown01" class="dropdown-menu megamenu">
          <div class="row">
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course.php">
             All Courses
            </a>
            <a class="dropdown-item" href="advance-english-speaking-course.php">
             Interchange  Advance Level-3
            </a>
            <a class="dropdown-item" href="online-english-speaking-course.php">
             Online English Classes
            </a>
            <a class="dropdown-item" href="pte-coaching-online.php">
             PTE Online Coaching
            </a>
            <a class="dropdown-item" href="personalised-english-classes.php">
             Personalised Classes
            </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="english-speaking-course-for-beginners.php">
             Interchange  Beginners 
            </a>
            <a class="dropdown-item" href="ielts-coaching-near-me.php">
             IELTS Course
            </a>
            <a class="dropdown-item" href="online-ielts-coaching.php">
             IELTS Online Coaching
            </a>
            <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">
             IELTS and English
            </a>
            <a class="dropdown-item" href="personality-development-course.php"> Personality Development </a>
           </div>
           <div class="col-sm-6 col-lg-4">
            <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">
             Interchange  Intermediate Level-2
            </a>
            <a class="dropdown-item" href="basic-spoken-english-course.php">
             Basic Spoken English Course
            </a>
            <a class="dropdown-item" href="pte-coaching-near-me.php">
             PTE Course
            </a>
            <a class="dropdown-item" href="english-and-pte-coaching-classes.php"> PTE and English </a>
            <a class="dropdown-item" href="competitive-exam-english-classes.php"> Competitive Exams </a>
           </div>
          </div>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Placement
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="hire-fresher.php">
           Employer
          </a>
          <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
           Student
          </a>
         </div>
        </li>
        <li class="nav-item dropdown">
         <a aria-expanded="false" class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" role="button">
          Contact
         </a>
         <div class="dropdown-menu">
          <a class="dropdown-item" href="contact-us.php"> All Centers </a>
          <a class="dropdown-item" href="contact-us-pitampura.php"> Pitampura </a>
          <a class="dropdown-item" href="contact-us-laxmi-nagar.php"> Laxmi Nagar </a>
          <a class="dropdown-item" href="contact-us-rajouri-garden.php"> Rajouri Garden </a>
          <a class="dropdown-item" href="contact-us-south-extension.php"> South Extension </a>
         </div>
        </li>
       </ul>
      </div>
      <div class="d-flex flex-row justify-content-end">
       <button class="pay-online-button"> <a href="https://rzp.io/l/OSEDELHI" target="_blank"> Pay Online </a> </button>
       
       <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      
      </div>
     </nav>
    </div>
    <div class="top-navbar d-lg-block d-none">
     <div class="container-fluid">
      <div class="d-flex flex-row justify-content-between">
       <button class="btn-year" type="btn">
        Since 1997 | 4 Branches
       </button>
       <div class="d-flex flex-row justify-content-center">
        <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           LEARN
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SPEAK
          </p>
         </div>
        </div>
        <div class="button-container">
         <div class="d-flex flex-row justify-content-center">
          <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
          <p>
           SUCCEED
          </p>
         </div>
        </div>
       </div>
       <button class="btn-year" type="btn">
        One Lakh Students Trained
       </button>
      </div>
     </div>
    </div>
   </div>
   <!--Desktop Navbar Header Code End-->
   <!--Mobile Navbar Header Code Start-->
   <div class="d-block d-lg-none">
    <div class="top-navbar">
     <div class="d-flex flex-row justify-content-center">
      <div class="d-flex flex-row m-auto">
          <a href="index.php">
              <img loading="lazy" alt="logo-image" class="logo-image" src="./assets/oxford-logo/oxford-english-icon.webp"/>
          </a>

       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          LEARN
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SPEAK
         </p>
        </div>
       </div>
       <div class="button-container">
        <div class="d-flex flex-row">
         <img loading="lazy" alt="frame-image" class="frame-image" src="./assets/icons/lightning-icon.webp"/>
         <p>
          SUCCEED
         </p>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div class="mobile-navbar">
     <div class="d-flex flex-row justify-content-between">
      <!--<button class="call-us-button" type="btn">-->
      <!-- <i class="fa fa-solid fa-phone mr-1">-->
      <!-- </i>-->
      <!-- Call Us-->
      <!--</button>-->
      <button class="call-us-button nav-item dropdown megamenu-li">
           <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" id="dropdown01">
            <i class="fa fa-solid fa-phone mr-1"></i> Call Us
           </a>
           <div class="dropdown-menu">
                <a class="dropdown-item" href="tel:9540127373">Pitampura : 9540127373</a>
                <a class="dropdown-item" href="tel:9540127878">Laxmi Nagar : 9540127878</a>
                <a class="dropdown-item" href="tel:9319608182">Rajouri Garden : 9319608182</a>
                <a class="dropdown-item" href="tel:9810735296">South Extension : 9810735296</a>
            </div>
      </button>
      <a href="index.php">
          <img loading="lazy" alt="main-logo" src="./assets/oxford-logo/oxford-school-of-english-delhi-logo.webp"/>
      </a>
      <button class="call-us-button" type="button" onclick="openSidebar()">
       Menu
       <i class="fa fa-solid fa-bars ml-1" >
       </i>
      </button>
      <div id="backdrop-sidebar"></div>
      <div class="sidebar" id="sidebar">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="navbar-collapse collapse show" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="menu-nav">
                    <a  class="nav-link mobile-navlink01">
                        MENU
                    </a>
                    <i class="fa fa-solid fa-circle-xmark close-icon" onclick="closeSidebar()">
                    </i>
            </li>
          <li class="nav-item dropdown">
            <a  class="nav-link mobile-navlink01" href="index.php">
             HOME
            </a>
           </li>
            <li>
                <a class="nav-link mobile-navlink01" href="about.php">
                    About 
                </a>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                English Courses
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="english-speaking-course.php">All English Courses</a>
                        <a class="dropdown-item" href="basic-spoken-english-course.php">Basic English Course</a>
                        <a class="dropdown-item" href="english-speaking-course-for-beginners.php">English Speaking Course for <br> Beginners - Level 1</a>
                        <a class="dropdown-item" href="intermediate-level-english-speaking-course.php">Intermediate English Course - Level 2</a>
                        <a class="dropdown-item" href="advance-english-speaking-course.php">Advanced English Course - Level 3</a>
                        <a class="dropdown-item" href="online-english-speaking-course.php">Online English Speaking Course </a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                IELTS
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="ielts-coaching-near-me.php">IELTS Coaching</a>
                        <a class="dropdown-item" href="online-ielts-coaching.php">IELTS Online One-on-One</a>
                        <a class="dropdown-item" href="english-and-ielts-coaching-classes.php">IELTS & English Course</a>
                </div>
            </li>
             <li class="nav-item dropdown">
                <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PTE
                </a>

                <div class="dropdown-menu">
                    <a class="dropdown-item" href="pte-coaching-near-me.php">PTE Coaching</a>
                        <a class="dropdown-item" href="english-and-pte-coaching-classes.php">PTE & English Course</a>
                        <a class="dropdown-item" href="pte-coaching-online.php">PTE Online One-on-One</a>
                </div>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personality-development-course.php">
                    Personality Development
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="competitive-exam-english-classes.php">
                    Competitive Exam Classes
                </a>
            </li>
             <li>
                <a class="nav-link mobile-navlink01" href="personalised-english-classes.php">
                    Personalised English Classes
                </a>
            </li>
            <li class="nav-item dropdown megamenu-li">
                <a aria-expanded="false" aria-haspopup="true" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" id="dropdown01">
                    CONTACT US
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="contact-us.php">
                    All Centers
                    </a>
                    <a class="dropdown-item" href="contact-us-south-extension.php">
                    South Extension
                    </a>
                    <a class="dropdown-item" href="contact-us-rajouri-garden.php">
                    Rajouri Garden
                    </a>
                    <a class="dropdown-item" href="contact-us-pitampura.php">
                    Pitampura
                    </a>
                    <a class="dropdown-item" href="contact-us-laxmi-nagar.php">
                    Laxmi Nagar
                    </a>
                </div>
            </li>
            <li>
                <a class="nav-link mobile-navlink01" href="gallery-fun-learning.php">
                    Gallery
                </a>
            </li>
              <li>
                <a class="nav-link mobile-navlink01" href="english-blogs.php">
                    English Blogs
                </a>
            </li>
            <li class="nav-item dropdown">
            <a aria-expanded="false" class="nav-link dropdown-toggle mobile-navlink01" data-toggle="dropdown" href="javascript:void(0)" role="button">
                PLACEMENT
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="hire-fresher.php">
                Employer
                </a>
                <a class="dropdown-item" href="job-for-freshers-in-delhi.php">
                Student
                </a>
            </div>
            </li>
         </ul>
        </div>
       </nav>
      </div>
     </div>
    </div>

    <div class="top-navbar d-lg-none d-block">
      <div class="d-flex flex-row justify-content-center">
        <button class="navbar-button">Since 1997 | 4 Branches | One Lakh Students Trained</button>
      </div>
    </div>
   </div>
   <!--Mobile Navbar Header Code End-->
  </header>
  
  
<!--floating buttons start-->

    <a class="fa-brands fa-whatsapp fa-beat fa-xl m-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"></a>
    <div class="w-numbers m-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
            
    <a class="fa-brands fa-whatsapp fa-beat fa-xl d-flex d-md-none" style="color: #27a725; font-size: 4em;" id="whatsapp-button"> <span> Whatsapp</span></a>

    <div class="w-numbers web-d-none" id="whatsapp-numbers">
          
          <table>
            <thead>
                <tr>
                    <th colspan="2">WhatsApp your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Pitampura : 8287299204</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Laxmi Nagar : 8287299204</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="w-number" href="https://wa.me/9810735296?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="w-number" href="https://wa.me/8287299204?text=Please%20send%20me%20more%20information" target="_blank"><strong>Chat with Yamuna Vihar : 8287299204</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
            </div>
      
    <a class="floatingss fa fa-phone-volume fa-beat d-md-block d-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
      
    <a class="floatingss fa fa-phone-volume fa-beat d-flex d-md-none" style="color: #00aee0; font-size: 3em; line-height:1.2;" id="floating-button"><span> Phone</span></a>
     
    <div class="phone-numbers" id="phone-numbers">
        <table>
            <thead>
                <tr>
                    <th colspan="2">Call your nearest Branch</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                 <td><a class="phone-number" href="tel:9540127373"><strong>Pitampura : 9540127373</strong></a></td>
                </tr>
                <tr>
                    
                    <td><a class="phone-number" href="tel:9540127878"><strong>Laxmi Nagar : 9540127878</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>Rajouri Garden : 9810735296</strong></a></td>
                </tr>
                <tr>
                   
                    <td><a class="phone-number" href="tel:9810735296"><strong>South Extension : 9810735296</strong></a></td>
                </tr>
                <!--<tr>-->
                    
                <!--    <td><a class="phone-number" href="tel:9667462832"><strong>Yamuna Vihar : 9667462832</strong></a></td>-->
                <!--</tr>-->
            </tbody>
        </table>
      </div>
      
<!--floating buttons end-->
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/">Home</a></li>
    <li class="breadcrumb-item" aria-current="page"><a href="english-blogs.php">English Blogs</a></li>
    <li class="breadcrumb-item active" aria-current="page">New English Words</li>
  </ol>
</nav>
    

<section>
  <div class="home-banner03">
    <div class="row m-0">
      <div class="col-12 p-0 col-lg-7 mb-3 order-2 order-lg-1 d-flex flex-column justify-content-center" >
        <div class="text-box-home-banner03">
          <h1 class="home-banner03-heading">New English Words<span class="home-banner03-grey-color-span01"> 2025</span></h1>

          <div class="d-flex flex-row justify-content-center">
            <img loading="lazy" src="./blog/assets/blog-mobile.webp" class="mobile-home-banner03-image d-lg-none d-block" alt="New English words in 2025 with icons of tech, work, and climate change." title="New English Words 2025" >
          </div>

          <!-- <div class="home-banner03-mini-container">
          <div class="home-banner03-text-container d-flex flex-column justify-content-center">
            <p class="home-banner03-list-paragraph">Explore fascinating insights and expert tips on English learning at the Oxford School of English. Enhance your skills with our informative and practical blogs</p>
          </div>
        </div> -->
      </div>
        </div>

        <div class="col-12 pr-0 col-lg-5 order-1 order-lg-2 flex-column justify-content-center d-none d-lg-flex">
          <div class="d-flex flex-row justify-content-end">
            <img loading="lazy" src="./blog/assets/blog.webp" class="home-banner03-image" alt="Explore thought-provoking English learning blogs" title="English Learning Blogs" >
          </div>

        
        </div>
      </div>
    </div>
  </div>
</section>


 <section id="section15">
   <!--best-speaking-in-delhi-container section Code Start-->
   <div class="best-speaking-in-delhi-container py-standard mt-standard">
    <div class="container text-center">
     <h4 class="best-speaking-in-delhi-container-button">
        New Words You Should Know 
     </h4>
     <div class="d-flex flex-row justify-content-center">
      <div class="best-speaking-in-delhi-description-container text-justify p-standard-inner">
       <div class="d-lg-block d-none">
        <p class="m-0">
         Language is evolving faster than ever. In 2025, dozens of new English words have entered everyday use, reflecting our changing habits, technologies, and concerns. From remote work culture to climate change, these words show what matters to us today. Learning them can boost your vocabulary and help you stay updated with modern communication. Knowing your trending terms will help you express your ideas more accurately and confidently, whether you're a student, professional, or English enthusiast.
        </p>
       </div>
       <div class="d-block d-lg-none">
        <p class="m-0">
       Language is evolving faster than ever. In 2025, dozens of new English words have entered everyday use, reflecting our changing habits, technologies, and concerns. From remote work culture to climate change, these words show what matters to us today. Learning them can boost your vocabulary and help you stay updated with modern communication.
         <span class="span05 hidden" id="hidden-content10">
             Knowing your trending terms will help you express your ideas more accurately and confidently, whether you're a student, professional, or English enthusiast.
         </span>
        </p>
       </div>
       <div class="d-block d-lg-none">
        <div class="d-flex flex-row justify-content-end">
         <button class="read-more-btn" id="read-more-btn10" type="btn">
          Read More
         </button>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <!--best-speaking-in-delhi-container section Code End-->
  </section>

    <section class="blog1 container p-0 mt-standard">
        <h2 class="blog-head1">New English Words 2025</h2>

        <button class="btn-blog">
            <img loading="lazy" src="./blog/assets/other-blogs/calendar-clock.webp" width="20" height="20" alt="clock">
            Published on 20-Apr-2025
        </button>

        <h2 class="blog-head2">Table of Contents</h2>

        <div class="m-0 row align-items-center">
            <div class="col-md-6 mb-md-0">
              <ul class="blogBox">
                <li>
                    <span>
                        <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                    </span>
                    <p>Tech buzzwords that define innovations </p>
                </li>
                <li>
                    <span>
                        <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                    </span>
                    <p>Eco-trends and mental health words shaping 2025</p>
                </li>
                <li>
                    <span>
                        <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                    </span>
                    <p>Post-pandemic social shifts and work-life changes</p>
                </li>
                <li>
                    <span>
                        <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                    </span>
                    <p>Finance and lifestyle words reflecting new choices</p>
                </li>
            </ul>
            </div>

            <div class="col-md-6">
                <ul class="blogBox">
                   
                    <li>
                        <span>
                            <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                        </span>
                        <p>Internet behaviour and information overload terms</p>
                    </li>
                    <li>
                        <span>
                            <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                        </span>
                        <p>Culture, courage, and youth-driven social shifts</p>
                    </li>
                     <li class="mb-0">
                        <span>
                            <img loading="lazy" src="./blog/assets/other-blogs/minus.webp" alt="minus">
                        </span>
                        <p>Food, farming, and sustainable living expressionsn</p>
                    </li>
                </ul>
            </div>
        </div>

    </section>

     <section class="blog2">
        <div class="bg-blog red">
            <div class="blog-container">
                <div class="blog-card">
                    <h3>
                        Tech Buzzwords Defining Innovation
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Techlash –</b> Growing criticism of big tech over privacy and control
                                <br>
                                <b>Sentence:</b> Sarah joined the debate on social media's role in the techlash movement.
                            </p>       
                            </div>
                        </li>
                       <span class="mb-0 xs-hidden" id="content-part02">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Biofacturing –</b> Using living organisms to produce materials or goods.
                                <br>
                                <b>Sentence:</b> Biofacturing now creates eco-friendly alternatives to plastics
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b> Cryptocurrency –</b> Places where cryptocurrency is the primary mode of payment.
                                <br>
                                <b>Sentence:</b> Sarah joined the debate on social media's role in the techlash movement.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Phygital –</b> A blend of digital and physical experiences.
                                <br>
                                <b>Sentence:</b> The phygital store allowed shopping online and offline seamlessly.
                            </p>       
                            </div>
                        </li>
                       </span>
                    </ul>

                    <div class="d-flex justify-content-end">
                        <div class="d-lg-none text-right">
                            <button class="read-more-btn" id="read-more-btn02" type="btn">
                            Read More
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

         <div class="bg-blog green">
            <div class="blog-container">
                <div class="blog-card">
                    <h3>
                        Eco & Wellness Terms of Today
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>	Eco-anxiety –</b> Stress caused by fears about climate change.
                                <br>
                                <b>Sentence:</b> Ruby feels eco-anxiety whenever she reads environmental news.
                            </p>       
                            </div>
                        </li>
                        <span class="mb-0 xs-hidden" id="content-part01">
                       
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Greenflation –</b> Price hikes due to eco-friendly policies or products.
                                <br>
                                <b>Sentence:</b> Max noticed greenflation while shopping for sustainable items.
                            </p>       
                            </div>
                        </li>
                        
                         <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Digital Detox –</b> Taking a break from screens to reduce mental fatigue.
                                <br>
                                <b>Sentence:</b> Sarah went on a digital detox to feel more comfortable.
                            </p>       
                            </div>
                        </li>
                        
                         <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Healthprint –</b> Personalized health data from apps or wearables.
                                <br>
                                <b>Sentence:</b> She checked her healthprint after syncing her smart band.
                            </p>       
                            </div>
                        </li>
                        </span>
                    </ul>
                    <div class="d-flex justify-content-end">
                        <div class="d-lg-none text-right">
                            <button class="read-more-btn" id="read-more-btn01" type="btn">
                            Read More
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

        <div class="bg-blog orange">
            <div class="blog-container">
                <div class="blog-card">
                    <h3>
                        Life After Lockdown: Social Changes
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Quaranteam –</b>  A group of close contacts during the lockdown.
                                <br>
                                <b>Sentence:</b> Mia stayed connected with her quaranteam through virtual calls.
                            </p>       
                            </div>
                        </li>
                       <span class="mb-0 xs-hidden" id="content12">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Zoom town –</b> Small towns gaining popularity due to remote work.
                                <br>
                                <b>Sentence:</b> Max moved to a Zoom town to escape the city and work remotely.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Telemedicine –</b> Accessing healthcare through online platforms.
                                <br>
                                <b>Sentence:</b>Sarah booked a telemedicine consultation for her flu symptoms.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Infodemic –</b> Excess information causing confusion and misinformation.
                                <br>
                                <b>Sentence:</b> The COVID-19 infodemic overwhelmed people on social media.
                            </p>       
                            </div>
                        </li>
                       </span>
                    </ul>
                    <div class="d-flex justify-content-end">
                        <div class="d-lg-none text-right">
                            <button class="read-more-btn" id="read-more-btn12" type="btn">
                            Read More
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

        <div class="bg-blog green">
            <div class="blog-container">
                <div class="blog-card">
                    <h3>
                        Money, Market & Lifestyle Shifts
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Recommerce –</b> Reselling pre-owned items online for sustainability.
                                <br>
                                <b>Sentence:</b> Sara joined a recommerce site to sell her barely used clothes.
                            </p>       
                            </div>
                        </li>
                        <span class="mb-0 xs-hidden" id="content03">
                       
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Upcycling –</b> Repurposing old items creatively into something useful.
                                <br>
                                <b>Sentence:</b> Ruby made handbags from old jeans by upcycling them.
                            </p>       
                            </div>
                        </li>
                        
                         <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Veganomics –</b> Economic impact of plant-based diets and lifestyles.
                                <br>
                                <b>Sentence:</b> Veganomics showed how demand for vegan food reshapes markets.
                            </p>       
                            </div>
                        </li>
                        
                         <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Workcation –</b> Working remotely while vacationing.
                                <br>
                                <b>Sentence:</b> Sam enjoyed a peaceful workcation in the hills last month.
                            </p>       
                            </div>
                        </li>
                        </span>
                    </ul>
                  

                    <div class="d-flex justify-content-end">
                        <div class="d-lg-none text-right">
                            <button class="read-more-btn" id="read-more-btn13" type="btn">
                            Read More
                            </button>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>

        <br>

        <div class="bg-blog red">
           <div class="blog-container">
               <div class="blog-card">
                   <h3>
                        Online Behaviour & Language Use
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Infobesity –</b> Difficulty managing excessive information intake.
                                <br>
                                <b>Sentence:</b> Too much Browse gave Ruby a sense of infobesity.
                            </p>       
                            </div>
                        </li>
                       <span class="mb-0 xs-hidden" id="content04">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Netiquette –</b> Good manners and behaviour online.
                                <br>
                                <b>Sentence:</b> Our teacher stressed netiquette before our online seminar.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Silence Breaker –</b> Someone who bravely speaks against injustice.
                                <br>
                                <b>Sentence:</b>Jack was hailed as a silence breaker for exposing misconduct.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Mindful Travel –</b> Traveling with cultural and environmental awareness.
                                <br>
                                <b>Sentence:</b> Ruby planned a mindful travel trip with eco-friendly stays.
                            </p>       
                            </div>
                        </li>
                       </span>
                        </li>
                    </ul>

                   <div  class="blogtxt1 mt-4">
                  
                            </div>

                            <div class="d-flex justify-content-end mt-4">
                                    <div class="d-lg-none text-right">
                                        <button class="read-more-btn" id="read-more-btn14" type="btn">
                                        Read More
                                        </button>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
        
        <br>        
        <div class="bg-blog orange">
            <div class="blog-container">
                <div class="blog-card">
                     <h3>
                        Culture, Courage & Youth Influence
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Youthquake –</b> Major shifts driven by youth in society or politics.
                                <br>
                                <b>Sentence:</b> A youthquake energized the climate march in the city center.
                            </p>       
                            </div>
                        </li>
                        <span class="mb-0 xs-hidden" id="content05">
                       
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Urban Farming –</b> Growing food in city spaces for local consumption.
                                <br>
                                <b>Sentence:</b> Ruby practices urban farming on her rooftop with great success.
                            </p>       
                            </div>
                        </li>
                        
                         <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Silence Breaker –</b> A person who speaks out against wrongs despite fear.
                                <br>
                                <b>Sentence:</b> Jack stood up as a silence breaker in a brutal school incident.
                            </p>       
                            </div>
                        </li>
                        
                         <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blogred4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Mindful Living –</b> A thoughtful, conscious approach to everyday actions.
                                <br>
                                <b>Sentence:</b> Sara embraced mindful living by shopping locally and ethically.
                            </p>       
                            </div>
                        </li>
                        <li>This section reflects how young voices, urban innovation, and conscious lifestyles are becoming central to social progress and change.</li>
                        </span>
                    </ul>
                    <div class="d-flex justify-content-end">
                        <div class="d-lg-none text-right">
                            <button class="read-more-btn" id="read-more-btn15" type="btn">
                            Read More
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
                <br>

<div class="bg-blog red">
           <div class="blog-container">
               <div class="blog-card">
                   <h3>
                        Food, Farming & Sustainable Living
                    </h3>
                    <ul class="mt-4">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog2.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Climatarian –</b> Someone who chooses food with low environmental impact.
                                <br>
                                <b>Sentence:</b> Sara became a climatarian to reduce her carbon footprint.
                            </p>       
                            </div>
                        </li>
                       <span class="mb-0 xs-hidden" id="content06">
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog1.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Regenerative Farming –</b> Agriculture that restores soil health and biodiversity.
                                <br>
                                <b>Sentence:</b> Max joined a project promoting regenerative farming techniques.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog3.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Flexitarian –</b> A mostly plant-based diet with occasional meat consumption.
                                <br>
                                <b>Sentence:</b>Ruby switched to a flexitarian lifestyle for better health and sustainability.
                            </p>       
                            </div>
                        </li>
                        
                        <li class="mb-5">
                            <div class="flexitem">
                            <span>
                                <img loading="lazy" src="./blog/assets/other-blogs/blog4.webp" alt="blog">
                            </span>
                            <p> 
                               	<b>Foodprint – </b> The environmental impact of the food we consume.
                                <br>
                                <b>Sentence:</b> Sarah calculated her foodprint before planning her weekly meals.
                            </p>       
                            </div>
                        </li>
                       </span>
                        </li>
                    </ul>

                   <div  class="blogtxt1 mt-4">
                  
                            </div>

                            <div class="d-flex justify-content-end mt-4">
                                    <div class="d-lg-none text-right">
                                        <button class="read-more-btn" id="read-more-btn16" type="btn">
                                        Read More
                                        </button>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
<br>
        <div class="bg-blog green">
            <div class="blog-container">
                <div class="blog-card">
                    <h3>Closing Takeaways</h3>
                    <div class="flexitem">
                    <ul class="mt-4">
                        <li class="mb-0 blogtxt1">
                           - <b>Speak Modern:</b> Use trending terms to sound confident and aware.
                        </li>
                        <li class="blogtxt1">
                            - <b>Understand Society:</b> Each word reflects a real social or cultural change.
                        </li>
                        
                        <li class="blogtxt1">
                           - <b>Think Critically:</b> Language shows what people care about deeply.
                        </li>
                    <span class="mb-3 xs-hidden" id="content07">
                        
                        <li class="blogtxt1">
                            - <b>Act Responsibly:</b> Terms like mindful travel inspire positive behaviour.
                        </li>
                        
                        <li class="blogtxt1"> 
                           - <b>Adapt Quickly:</b> New vocabulary prepares you for thoughtful conversations.
                        </li>
                        <br>
                       <li>Stay updated with evolving words and speak the language of the present. Your vocabulary should grow as the world around you does.</li>
                    </span>
                    </ul>
                  
                    <div>
                    <div class="d-flex justify-content-end">
                        <div class="d-lg-none text-right">
                            <button class="read-more-btn" id="read-more-btn17" type="btn">
                            Read More
                            </button>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        
        <br>
        
        

    </section>
    
    
           <br>

   <section class="color-cards container p-0">
        <div class=" color-cards-gap grid-res owl-carousel owl-theme" id="blog-slider">
            <div class="colorBox p-3">
                <div class="bgColor blue">
                    <img loading="lazy" width="60" height="60" src="./blog/assets/other-blogs/read-leaf-small.webp" alt="color1" style="width: fit-content">
                    <p class="colorImgDesc">New English Words You Must Know in 2025 </p>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Explore trending 2025 words shaping modern English. </p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="blog-new-gems-of-english.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
            <div class="colorBox p-3">
                <div class="bgColor green">
                    <p class="colorImgDesc green black">Master Future Perfect Continuous Tense  </p>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Learn how to use Future Perfect Continuous tense easily.</p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="blog-future-perfect-continuous-tense.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
            <div class="colorBox p-3">
                <div class="bgColor orange">
                    <div class="d-flex justify-content-end" style="align-items: baseline;gap: 2px">
                            <img loading="lazy" width="43" height="43" src="./blog/assets/other-blogs/green-leaf-small.webp" alt="color1" class="small-leaf" style="width: fit-content">
                            <img loading="lazy" width="66" height="66" src="./blog/assets/other-blogs/green-leaf-large.webp" alt="color1"  style="width: fit-content">
                    </div>
                    <p class="colorImgDesc black ">Master All English Tenses Easily </p>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Understand all English tenses with simple explanations</p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="blog-mastering-english-tenses.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class=" color-cards-gap grid-res owl-carousel owl-theme" id="blog-slider2">
            <div class="colorBox p-3">
                <div class="bgColor p-0 grid grid-cols-2">
                    <div class="p-3 d-flex align-items-center yellow">
                        <p class="colorImgDesc black">Amazing English Facts  </p>
                    </div>
                    <div class="p-3 d-flex align-items-center justify-content-end green">
                        <img loading="lazy" width="110" height="110" src="./blog/assets/other-blogs/2-red-leaf.webp" alt="color1" style="width: fit-content">
                    </div>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Curious and Fun Facts You Never Knew About English </p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="english-some-interesting-facts.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
            <div class="colorBox p-3">
                <div class="bgColor red">
                    <div class="d-flex justify-content-end">
                        <img loading="lazy" width="80" height="80" src="./blog/assets/other-blogs/blue-leaf-large.webp" alt="color1" style="width: fit-content">
                    </div>
                    <p class="colorImgDesc text-right">Using ‘Has’ and ‘Have’ Correctly</p>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Master ‘has’ and ‘have’ in all types of sentences.</p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="blog-use-of-has-have.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
            <div class="colorBox p-3">
                <div class="bgColor blue">
                    <p class="colorImgDesc orange black">Make Many Sentences from One Phrase </p>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc ">Learn how one phrase can build many sentences. </p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="blog-make-sentences-one-phrase.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class=" color-cards-gap grid-res owl-carousel owl-theme" id="blog-slider3">
            <div class="colorBox p-3">
                <div class="bgColor green grid grid-cols-2">
                    <div class=" d-flex align-items-center">
                        <p class="colorImgDesc">Master the 7 C’s of Communication  </p>
                    </div>
                    <div class=" d-flex align-items-center justify-content-center">
                        <img loading="lazy"  width="120" height="120" src="./blog/assets/other-blogs/message.webp" alt="color1" style="width: fit-content">
                    </div>
                </div>
                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Learn 7 key rules to steer clear, effective talks. </p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="7c-of-communication.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
            <div class="colorBox p-3">
                <div class="bgColor blue grid grid-cols-2">
                    <div class=" d-flex align-items-center justify-content-start">
                        <img loading="lazy" width="110" height="120" src="./blog/assets/other-blogs/cube.webp" alt="color1" style="width: fit-content">
                    </div>
                    <div class=" d-flex align-items-center">
                        <p class="colorImgDesc">Use of Is, Are, Am, Was, Were, Has, Have  </p>
                    </div>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Learn where to use key helping verbs in sentences. </p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="use-of-is-are-am-was-were.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
            <div class="colorBox p-3">
                <div class="bgColor black d-flex" style="gap: 15px">
                    <div class=" d-flex align-items-center justify-content-start" style="flex-shrink: 0;">
                        <img loading="lazy" src="./blog/assets/other-blogs/red-leaf-large.webp" alt="color1">
                    </div>
                    <div class=" d-flex align-items-center">
                        <p class="colorImgDesc">10 Smart Words to Describe a Liar </p>
                    </div>
                </div>

                <div class="colorDesc pt-3">
                    <p class="colorTitleDesc">Discover unique words to talk about liars smartly. </p>

                     <div class="d-flex flex-row justify-content-end mt-3">
                        <button class="read-more-btn" type="btn">
                        <a href="10-ways-to-describe-liars.php" class="text-white"><b>Read More</b></a>
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <br>
    
    
    
  

    <link href="./css/bootstrap.css" rel="stylesheet"/>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/adib-css/adib-common.css">

<!--<h3 class="text-center">-->
<!--     Section 17-->
<!--  </h3>-->
  <section class="oxford-branches mt-standard" id="section17">
    <div class="d-flex flex-row justify-content-center">
    <h3 class="new-abc-button mb-0">
      Oxford School of English Branches
    </h3>
    </div>
       <!--english-speaking-classes-section Code Start-->
       <div class="new-branches-container pt-5 py-standard">
        <div class="container-fluid">
         <div class="grid grid-cols-3 grid-cols-2-17 g-gap card-scroll">
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Pitampura Branch </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  365 Kohat Enclave, Near Kohat Metro Station Gate No. 3, North Delhi -110034 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127373"> 9540127373</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:45680574"> 011 - 45680574</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-pitampura.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6981337,77.1372723,17z/data=!3m1!4b1!4m5!3m4!1s0x390d03da0abc6ac3:0xe4642d10ca8d8fbf!8m2!3d28.698129!4d77.139461?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Laxmi Nagar</h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description">  E 354, Nirman Vihar, Adjacent to Nirman Vihar Metro Station Gate Number 2, East Delhi -110092 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9540127878"> 9540127878</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 40159334</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-laxmi-nagar.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute/@28.6372579,77.2865177,17z/data=!4m5!3m4!1s0x390cfb56b6843fff:0xbd5d17737bc80438!8m2!3d28.6372532!4d77.2887064?shorturl=1" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> South Extension </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> E 10, Part-I, Near South Extension Metro Station, South Extension, South Delhi -110049 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9810735296"> 9810735296 </a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255102"> 011 - 41255102</a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-south-extension.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
                   <a href="https://www.google.com/maps/place/Oxford+Software+Institute+South+Extention/@28.5706783,77.219955,17z/data=!3m1!4b1!4m6!3m5!1s0x390ce25d0ac35f11:0x3125b97033cf142f!8m2!3d28.5706783!4d77.219955!16s%2Fg%2F1th0wr3f?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
          <div class="card-17">
           <div class="card-container p-standard-inner">
            <div class="container-fluid p-0">
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image" class="map-image" src="./assets/icons/location-marker-red-icon.webp"/>
              <h5 class="area-name-heading"> Rajouri Garden </h5>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/map-icon-black.webp"/>
              <p class="map-description"> A 4, Vishal Enclave, opposite Metro Pillar No. 411, West Delhi -110027 </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon" src="./assets/icons/phone.webp"/>
              <p class="map-description">
                  <a href="tel:9319608182"> 9319608182</a>
              </p>
             </div>
             <div class="d-flex flex-row mb-standard-inner align-items-center">
              <img loading="lazy" alt="map-image-icon" class="map-image-icon01" src="./assets/icons/black-phone-icon.webp"/>
              <p class="map-description">
                  <a href="tel:41255104"> 011 - 41255104 </a>
              </p>
             </div>
             <div class="row">
              <div class="col-6 col-lg-6">
               <button class="know-more-btn">
                   <a href="contact-us-rajouri-garden.php"> Know More</a>
               </button>
              </div>
              <div class="col-6 col-lg-6">
               <button class="view-more-btn">
               <a href="https://www.google.com/maps/place/Oxford+Software+Institute+Rajouri+Garden/@28.6880275,77.1244528,12z/data=!4m6!3m5!1s0x390d0372a62dafe3:0x5e55587ff09b2755!8m2!3d28.6478906!4d77.1190374!16s%2Fg%2F11bxc5l07v?entry=ttu&amp;g_ep=EgoyMDI1MDMxOC4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                      View on Map
                     </a>
               </button>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <!--english-speaking-classes-section Code End-->
  </section>
  
  
  <footer>
   <div class="">
    <div class="mobile-footer-container px-3 py-standard">
     <div class="container-fluid">
      <div class="row">
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Quick Links
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="/">
           Home
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="about.php">
           About 
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-blogs.php">
           English Blogs
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="gallery-fun-learning.php">
           Gallery
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="hire-fresher.php">
           Placement Employer
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="job-for-freshers-in-delhi.php">
           Placement Student
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="contact-us.php">
           Contact Us
          </a>
         </li>
          <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms/inquiry.php">
           Enquiry Form
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" target="_blank" href="lms">
           LMS
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-course-faqs.php">
           English Course FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-exam-faqs.php">
           IELTS Exam FAQ
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-exam-faqs.php">
           PTE Exam FAQ
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="spoken-english-classes-near-me.php">
           English Classes Near Me
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <div class="d-flex flex-row justify-content-between align-items-center">
         <h5 class="footer-list-heading">
          Courses
         </h5>
         <i class="fa fa-solid fa-plus font-icon" id="toggleIcon01">
         </i>
        </div>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <ul class="footer-links" id="footerLinks01" style="list-style-type: none !important;">
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course.php">
           All Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="english-speaking-course-for-beginners.php">
           Interchange Beginners Level-1
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="intermediate-level-english-speaking-course.php">
           Interchange Intermediate Level-2
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="advance-english-speaking-course.php">
           Interchange Advance Level-3
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="ielts-coaching-near-me.php">
           IELTS Courses
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="basic-spoken-english-course.php">
           Basic Spoken English Course
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-english-speaking-course.php">
           Online English Classes
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="online-ielts-coaching.php">
           IELTS Online Coaching
          </a>
         </li>
         <li class="mb-2">
          <a class="footer-list" href="pte-coaching-near-me.php">
           PTE Course
          </a>
         </li>
         <li class="mb-3">
          <a class="footer-list" href="pte-coaching-online.php">
           PTE Online Coaching
          </a>
         </li>
        </ul>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         About 
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <p class="footer-about-us-description">
         Oxford School of English, with four branches since 1997, stands as Delhi’s leading English-speaking Institute and offers the best English-speaking course (also called English talking course by many) from basic to advanced levels. If you are searching for English-speaking classes near me, Oxford is the best choice, with branches in all directions of Delhi, having trained over one lakh students as an NSDC training partner.
        </p>
       </div>
       <div class="col-md-3">
        <h5 class="footer-list-heading">
         Course Enquiry
        </h5>
        <img loading="lazy" alt="line-image" class="line-image" src="./assets/icons/line-image.webp"/>
        <form action="" method="post" name="frm">
            <!--<input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />-->
            <input class="footer-form-control" name="studentName" placeholder="Enter your Name" type="text" required />
            <input class="footer-form-control" name="mobile" placeholder="Enter your Number" type="text" required />
            <input class="footer-form-control" name="course" placeholder="Course" type="text" required />
            <select class="footer-form-control" name="centre" required>
                <option value="" selected> Select Center</option>
                <option value="Pitampura"> Pitampura</option>
                <option value="Laxmi Nagar"> Laxmi Nagar</option>
                <option value="Rajouri Garden"> Rajouri Garden</option>
                <option value="South Extension"> South Extension</option>
            </select>
         <!--<input class="footer-form-control" placeholder="Enter Your Name" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Enter Your Number" type="text"/>-->
         <!--<input class="footer-form-control" placeholder="Select Center" type="text"/>-->
         <div class="d-flex flex-row justify-content-center">
          <button class="footer-form-submit-btn" type="submit" name="submitQuick">
           Submit
          </button>
         </div>
        </form>
       </div>
      </div>
     </div>
    </div>
    <div class="footer-border-bottom-line">
    </div>
    <div class="mobile-footer-container pt-4 pb-4 px-3">
     <div class="container-fluid">
      <div class="row">
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Proud Associations
        </p>
        <div class="row">
         <div class="col-7 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/oxford-nsdc-partner.webp" alt="Oxford is a Proud Partner of NSDC" />
         </div>
         <div class="col-5 col-lg-2 mb-3">
          <img loading="lazy" class="partner-image" src="./assets/footer/skill-courses.webp" alt="We Offer Skill Courses for Better Employment" />
         </div>
         <div class="col-12 col-lg-3 mb-3 text-lg-left text-center">
          <img loading="lazy" class="partner-image" src="./assets/footer/cambridge-partner.webp" alt="Oxford School of English Offers Cambridge University Press Courses" />
         </div>
        </div>
       </div>
       <div class="col-12 col-lg-6 mb-3">
        <p class="proud-association-heading">
         Connect with Us
        </p>
        <div class="d-flex flex-row justify-content-between justify-content-md-start">
         <a href="https://www.facebook.com/delhioxfordenglish">
          <img loading="lazy" alt="Facebook Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-facebook.webp"/>
         </a>
         <a href="#">
          <img loading="lazy" alt="x-icon" class="social-icon" src="./assets/footer/x-oxford-english.webp"/>
         </a>
         <a href="https://www.instagram.com/oxfordschoolofenglish.in">
          <img loading="lazy" alt="Instagram Page of Oxford School of English" class="social-icon" src="./assets/footer/oxford-english-instagram.webp"/>
         </a>
         <a href="https://www.youtube.com/channel/UC50IGGpwAuCGcVzP6Tx2TPg">
          <img loading="lazy" alt="YouTube Channel of Oxford School of India" class="social-icon" src="./assets/footer/oxford-english-youtube.webp"/>
         </a>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      English Speaking Institute Near You
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course in Kohat Enclave
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near nangloi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Paschim Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Shalimar Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Punjabi Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Rani Bagh
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rohini.php">
          English Speaking Course in Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Narela
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-pitampura.php">
          English Speaking Course near Bawana
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Uttam Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-rajouri-garden.php">
          English Speaking Course in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Shahdara
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Preet Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Nirman Vihar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Krishna Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Geeta Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Patparganj
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Vaishali
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-laxmi-nagar.php">
          English Speaking Course near Kaushambi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course in Kotla
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Defence Colony
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Kalkaji
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Green Park
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-course-south-extension.php">
          English Speaking Course near Hauz Khas
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="spoken-english-classes-near-me.php">
          English Classes Near Me
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="english-speaking-classes-delhi.php">
          English Speaking Course in Delhi
         </a>
        </li>
       </ul>
      </div>
     </div>
    </div>
   </div>

   <div class="braches-container py-standard">
    <div class="container-fluid">
     <h5 class="footer-list-heading pb-3">
      IELTS Coaching Institute Near You In Delhi
     </h5>
     <div class="row">
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-pitampura.php">
          IELTS Coaching in Pitampura
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rohini.php">
         IELTS Coaching near  Rohini
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Tilak Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Vikaspuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching  near Janakpuri
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-rajouri-garden.php">
         IELTS Coaching   in Rajouri Garden
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in Laxmi Nagar
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-laxmi-nagar.php">
         IELTS Coaching   in East Delhi
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching   in South Extension
         </a>
        </li>
       </ul>
      </div>
      <div class="col-12 col-lg-3 mb-3 cols01">
       <ul style="list-style-type: none !important;">
        <li>
         <a class="branch-name" href="ielts-coaching-in-south-extension.php">
         IELTS Coaching  near Lajpat Nagar
         </a>
        </li>
       </ul>
      </div>

     </div>
    </div>
   </div>

   <div class="copyright-container pt-4 pb-2">
    <div class="container-fluid">
     <h5 class="copyright-heading">
      Copyright &copy; 1997 - 2025 Hindustan Soft Education Limited, New Delhi || All the logos and images are the copyright of their respective owners
     </h5>
     <div class="d-flex flex-row justify-content-center">
      <p class="copyright-paragraph">
       *Privacy Policy : We do not distribute your email or contact information to other websites or sources and will be kept confidential. We do not accept or host any advertisement on this website. We do collect visitor data and asses the user traffic on our website and various pages which helps us to improvise. We do not collect any personal information on visitors. Any information which is considered to have ethnic or gender bias, derogatory or lewd will be removed by owner of this website at their discretion without any notice. By using our website, you agree to our privacy policy as mentioned above. Our privacy policy may get updated without any notice, hence users are suggested to review it before they plan to submit any personal information to our website.
      </p>
     </div>
    </div>
   </div>
  </footer>
  <div class="popup" id="videoPopup">
   <div class="popup-content">
    <span class="close-btn" onclick="hidePopup()">
     &times;
    </span>
    <video controls="" id="popupVideo">
     <source src="" type="video/mp4"/>
     Your browser does not support the video tag.
    </video>
   </div>
  </div>
  <div class="video-overlay" id="videoOverlay">
   <div class="video-container">
    <div class="embed-responsive embed-responsive-16by9">
     <iframe allowfullscreen="" class="embed-responsive-item" id="videoIframe" src="">
     </iframe>
    </div>
    <span class="close-btn01" id="closeBtn01">
     <img loading="lazy" src="./assets/icons/cross.webp" width="40" height="40" alt="cross">
    </span>
   </div>
  </div>
  <!-- <script src="banners/js/aos.js"></script> -->
  <script>
  
  </script>
  <script src="js/common.js" defer></script>

  <script src="js/custom-carousel.js" defer></script> 

  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" defer ></script>

  <script  src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" defer ></script>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" defer></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"  defer></script>

  <script src="./js/adib-script.js" defer></script>

  <!-- Ashutosh's code start - 16-04-2025
     Code to reload images that did not load the first time -->

  <script>
//     $(document).ready(function() {
//       $('img').each(function () {
//         if (!this.complete || typeof this.naturalWidth === "undefined" || this.naturalWidth === 0) {
//           var src = $(this).attr('src');
//           $(this).attr('src', src); // Force reload
//         }
//       });
//     });
 </script>
  <!-- Ashutosh's code end -->
  <!--banner script-->
  
 </body>
</html>
    <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
    crossorigin="anonymous"
  />
  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"
  ></script>

</body>
</html>